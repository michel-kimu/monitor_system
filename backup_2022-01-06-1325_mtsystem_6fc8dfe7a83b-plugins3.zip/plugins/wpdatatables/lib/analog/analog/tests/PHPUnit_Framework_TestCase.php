<?php

use PHPUnit\Framework\TestCase;

class PHPUnit_Framework_TestCase extends TestCase {}
