### Git
https://github.com/greenlion/PHP-SQL-Parser

### Subversion
https://code.google.com/p/php-sql-parser/source/checkout

### Google Drive (.zip)
http://tinyurl.com/mg8bh9p

### Packagist
https://packagist.org/packages/greenlion/php-sql-parser

### GoogleCode (only old versions)
https://code.google.com/p/php-sql-parser/downloads/list