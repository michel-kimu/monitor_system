<?php die(); ?><!DOCTYPE html>
<html class="html" lang="ko-KR">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>menu &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.2' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-9-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-9.css?ver=1637748092' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.2' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.2' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/9" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.2" />
<link rel="canonical" href="http://hyodolms.com/menu/" />
<link rel='shortlink' href='http://hyodolms.com/?p=9' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fmenu%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fmenu%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style></head>

<body class="page-template-default page page-id-9 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled has-breadcrumbs elementor-default elementor-kit-10 elementor-page elementor-page-9" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
			
			<main id="main" class="site-main clr"  role="main">

				
	
	<div id="content-wrap" class="container clr">

		
		<div id="primary" class="content-area clr">

			
			<div id="content" class="site-content clr">

				
				
<article class="single-page-article clr">

	
<div class="entry clr" itemprop="text">

	
	<script>	var appendAgencyState 	= 'false';
					var dollEnvState		= 'false';
			</script>		<div data-elementor-type="wp-page" data-elementor-id="9" class="elementor elementor-9" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-d10eb99 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="d10eb99" data-element_type="section" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-7ac03db" data-id="7ac03db" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c66f9dd elementor-widget elementor-widget-image" data-id="c66f9dd" data-element_type="widget" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
											<a href="/login">
							<img src="http://hyodolms.com/wp-content/uploads/2021/04/hyodoltitle.png" title="hyodoltitle" alt="hyodoltitle" />								</a>
											</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-2afdfad" data-id="2afdfad" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-aa2fbcc elementor-widget elementor-widget-html" data-id="aa2fbcc" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			
<label class="label-disp" id="agencyTotalNum"></label>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>

<script type='text/javascript'>
jQuery(function () {
    var lastId = 'child1'; //default : 첫번째id 선택
    
    //-----------------------------------
    //선택한 lastId의 함수 자동실행
    //-----------------------------------
    //상위기관으로 로그인한 경우
    var menuElem = document.getElementById(lastId);
    if(menuElem == null){
         //하위기관으로 로그인한 경우
         lastId = 'sub1'; 
         menuElem = document.getElementById(lastId);
    }
    
    if(menuElem != null){
        if(menuElem.hasChildNodes()){
            var child = menuElem.childNodes;
            if(child[0].nodeName =='A'){
                child[0].click();  //lastId태그의 onClick 함수 실행
            }
        }
    }else{
        console.log("left menu error");
    }

    //-----------------------------------    
  
    elementColorProc(lastId); //메뉴 선택 상태로 전환
    
    jQuery("#accordion > li > a").click(function () {
        var click = jQuery(this).parent();
        var id = jQuery(click).attr('id');
        elementColorProc(id);

        //선택한 메뉴 오픈
        click.children('ul').slideDown('fast', function () {
            jQuery("#accordion ul").not(click.children('ul')).slideUp('fast');
            //예전 메뉴 닫기
            
        });
    });

    jQuery("#accordion > li > ul > li > a").click(function () {
        var click = jQuery(this).parent();
        var id = jQuery(click).attr('id');
        elementColorProc(id);
    });

    //선택한 요소의 색을 바꾸고 바로 전에 눌렸던 요소의 색을 원래색으로 되돌림
    function elementColorProc(id) {
        if (lastId.length) {
            if (~lastId.indexOf('child')) {
                //console.log('>' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#3F5160';//'#1b1b1b1b'; //Child~ id 의 원래색
            } else {
                //console.log('->' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#969EA4';//'#4f4f4f'; //서브 메뉴의 원래색
            }
        }
        //console.log('id:->' + id);
        document.getElementById(id).style.backgroundColor =  "#E37660";//"#d4a534"; //현재 선택 색(오랜지)
        lastId = id;
    }




    function resetSideMenu(){
        console.log('reset!');
         if (lastId.length) {
            if (~lastId.indexOf('child')) {
                //console.log('>' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#1b1b1b1b'; //Child~ id 의 원래색
            } else {
                //console.log('->' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#4f4f4f'; //서브 메뉴의 원래색
            }
        }
        jQuery("#accordion ul").slideUp('fast');
    }

});




/*
//메인 페이지에 기관코드 전송
function page(val_){
    //console.log('>page:' + val_);
    var iframe = document.getElementById("main_view_frame");
    //iframe.src = '/main?agc='+val_;
    var url = '/main?agc='+val_+'&dmy='+getCurrentTime() ;
    console.log('---->url:' + url);
    iframe.contentDocument.location.replace(url); //ifrmae의 페이지 이력을 남기지 않기(돌아가기 누르면 로그인 화면으로 감)
   // iframe.src = url; //ifrmae의 페이지 이력 남기기 (iframe은 과거의 페이지를 보여주지만 왼쪽의 사이드메뉴는 변하지 않으므로 사용하지 말것)
    return false;
}
*/




</script> 


<!--dummy menu
<div>
    
    <ul id="accordion">
        <li id="child1"><a href="/?id=000000000000">전체</a>
            <ul>
                <li><a href="/?id=000000000001">개인사용자</a></li>
                <li><a href="/?id=000000000002">SCC테스트</a></li>
            </ul>
        </li>
        <li id="child2"><a>춘천시청</a>
            <ul>
                <li><a>춘천시청장애인종합복지관</a></li>
                <li><a>춘천시개인</a></li>
                <li><a>동부노인복지관</a></li>
                <li><a>별빛마을</a></li>
                <li><a>남부노인복지관</a></li>
                <li><a>북부노인복지관</a></li>
            </ul>
        </li>
        <li id="child3"><a>양산시청</a>
            <ul>
                <li><a onClick="">양산시청 사회복지과</a></li>
            </ul>
        </li>
        <li id="child3"><a>청도군 스마트시티</a>
            <ul>
                <li><a onClick="">신도1리</a></li>
            </ul>
            <ul>
                <li><a onClick="">신도2리</a></li>
            </ul>
        </li>
        <li id="child4"><a href="" onClick="run('a')">광양시청</a>
            <ul>
                <li><a onClick="">광양시 노인전문 요양원</a></li>
                <li><a onClick="run('3a3')">광양시 재가 </a></li>
            </ul>
        </li>
    </ul>
</div>
-->		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-0cbda4e" data-id="0cbda4e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a5feaa5 elementor-widget elementor-widget-html" data-id="a5feaa5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			

<button class="appendAgencyBtn" type="button" id="adminControl" onclick="showAdminControl()">통합관리</button>
<button class="appendAgencyBtn" type="button" id="appendAgencyButton" onclick="sendSms()">기관등록</button>

<!--
<button class="appendAgencyBtn" id="showEnvLink"  onclick="showDollEnvironmentLink()">인형 환경정보</button>
-->

<button class="appendAgencyBtn" id="grafanaLink"  onclick="showGrafanaLink()">Dash Board</button>

<div id="table_div" ></div>

<div id="newAgencyModal" class="agency-modal">
  <div class="agency-modal-content">
    <div class="agency-modal-title">기관등록</div>
       <button class="agency-modal-close-btn" id = "closeBtn" onclick="closeAgencyModalWindow()">&times;</button>
        <div class="agency-modal-phone-title">
            <p>기관명</p>
         </div>    
            <input class="agency-modal-code-area" id="agency-name-number" placeholder=""  type="text" maxlength="30" >
         <div class="agency-modal-message-title">
            <p>기관코드</p>    
        </div>
            <input class="agency-modal-code-area" id="agency-code-number" placeholder=""  type="text" maxlength="30" >
        <div></div>
            <button class="agency-modal-cancel-btn" id = "agency_cancelBtn" onclick="closeAgencyModalWindow()">취소</button>
            <button class="agency-modal-save-btn" id = "agency_saveBtn" onclick="appendAgency()">추가</button>
  </div>
</div>


<script>

//기관입력 표시 상태 
if(appendAgencyState=="false"){ 
document.getElementById("adminControl").style.display = "none";
document.getElementById("appendAgencyButton").style.display = "none";
document.getElementById("grafanaLink").style.display = "none";
}

if(dollEnvState == "false")
 document.getElementById("showEnvLink").style.display = "none";
   
function showDollEnvironmentLink(){
    //var url = "http://13.125.170.204/env/wmainlist";
    var url = '/doll_env_info?dmy='+getCurrentTime();
    window.open(url, "_blank");
}    

function showGrafanaLink(){
    //var url = "http://106.254.228.130:23001/d/V7XU8dXGk/scc-dashboard?orgId=1";
    let url = "http://15.164.89.157:3000/d/i2fKmVeMz/hyodol-dashboard?orgId=1&refresh=15m";
    window.open(url, "_blank");
}  

function appendAgency(){
    var agency_name  = document.getElementById('agency-name-number').value;
    var agency_code  = document.getElementById('agency-code-number').value;
    
    if(agency_name ==''){
        swal("입력오류", "기관명을 입력하세요", "warning");
        return;
    }

    if(agency_code == ''){
        swal("입력오류", "기관코드를 입력하세요", "warning");
        return;
    }   
    if(agency_code.length < 12)
    {
        swal("입력오류", "코드형식이 다릅니다. 다시 확인하세요.", "warning");
        return;
    }
    
    console.log('code:'+agency_code+',name:'+agency_name);
    
     jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'        :'append_new_agency',
            'agencyName'    : agency_name,
            'agencyCode'    : agency_code
        },
        success: function( response ){
           swal("기관추가 완료", "", "success");
        },
        error: function( response,status,error){
           swal("기관추가 실패", error, "error");
        }
    });
    
    document.getElementById('agency-name-number').value = '';
    document.getElementById('agency-code-number').value = '';
    
    closeAgencyModalWindow();
    return false; 
}



var agency_modal = document.getElementById("newAgencyModal");

function closeAgencyModalWindow(){
    
    document.getElementById("agency-name-number").value ='';
    document.getElementById("agency-code-number").value ='';
    
    agency_modal.style.display = "none";
}


function sendSms(){
    agency_modal.style.display = "block";
}

// 모달윈도우 밖을 클릭했을때
window.onclick = function(event) {
  if (event.target == agency_modal) {
   closeAgencyModalWindow();
  }
}

//통합관리 
function showAdminControl(){
   var url =  '/admin_page?dmy='+getCurrentTime();
   window.open(url, "_blank");
                            //서버 갱신을 위해서 더미(현재시간)를 추가
}

//현재시간취득（yyyymmddhhmmss）
function getCurrentTime() {
    var now = new Date();
    var res = "" + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) + 
        padZero(now.getMinutes()) + padZero(now.getSeconds());
    return res;
}

//선두 제로 붙힘
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}
</script>
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-070355a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="070355a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3dfe6d7" data-id="3dfe6d7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-855af17 elementor-widget elementor-widget-html" data-id="855af17" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="form_radio_btn1" id="searchAreaRadio">

        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_1" autocomplete="off" checked="checked"
                onclick="selectArea('-99')">
            <label for="radio_1">전체</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_2" autocomplete="off" onclick="selectArea('11')">
            <label for="radio_2">서울시</label>
        </div>
        
      <!--  <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_3" autocomplete="off" onclick="selectArea('33')">
            <label for="radio_3">세종시</label>
        </div>
        -->
        
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_4" autocomplete="off" onclick="selectArea('28')">
            <label for="radio_4">인천시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_5" autocomplete="off" onclick="selectArea('30')">
            <label for="radio_5">대전시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_6" autocomplete="off" onclick="selectArea('31')">
            <label for="radio_6">울산시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_7" autocomplete="off" onclick="selectArea('29')">
            <label for="radio_7">광주시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_8" autocomplete="off" onclick="selectArea('27')">
            <label for="radio_8">대구시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_9" autocomplete="off" onclick="selectArea('26')">
            <label for="radio_9">부산시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_10" autocomplete="off" onclick="selectArea('41')">
            <label for="radio_10">경기도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_11" autocomplete="off" onclick="selectArea('42')">
            <label for="radio_11">강원도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_12" autocomplete="off" onclick="selectArea('43')">
            <label for="radio_12">충북도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_13" autocomplete="off" onclick="selectArea('44')">
            <label for="radio_13">충남도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_14" autocomplete="off" onclick="selectArea('45')">
            <label for="radio_14">전북도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_15" autocomplete="off" onclick="selectArea('46')">
            <label for="radio_15">전남도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_16" autocomplete="off" onclick="selectArea('47')">
            <label for="radio_16">경북도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_17" autocomplete="off" onclick="selectArea('48')">
            <label for="radio_17">경남도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_18" autocomplete="off" onclick="selectArea('50')">
            <label for="radio_18">제주도</label>
        </div>
    </div>


<script>
if(appendAgencyState=="false"){
 document.getElementById("searchAreaRadio").style.display = "none";
 document.getElementById("agencyTotalNum").style.display = "none";
}
 
function selectArea(selectID) {
    
    console.log('selectID:'+selectID);
    var menuElem = document.getElementById('accordion');
    var c = menuElem.children;
    var searchResult = new Array();
    var parentName = '';

    var agencyTotalCnt = 0; //상위기관 총수
    //
    jQuery("#accordion ul").slideUp('fast'); //열린 서브 메뉴 닫기
    //
    for (var u = 0; u < c.length; u++) {
        var t = c.item(u).childNodes;
        var pId = c.item(u).id;
            for (var i = 0; i < t.length; i++) {
               if (t[i].nodeName == 'A') { //1차메뉴의 이름
                parentName = t[i].innerText;
                var id = t[i].id;

                if (selectID == -99) {
                    document.getElementById(pId).style.display = "block"; //전체표시
                    agencyTotalCnt++;
                }else{
                    if (selectID == (t[i].id).slice(2, 4)) {
                        document.getElementById(pId).style.display = "block"; //해당기관표시
                        agencyTotalCnt++;
                    } else {
                        document.getElementById(pId).style.display = "none"; //비해당기관 비표시
                    }
                }
            }
           document.getElementById(pId).style.backgroundColor = '#1b1b1b1b';//메뉴 컬러를 원래대로. 서브메뉴 컬러는 변경않함(메뉴를 닫으므로)
        }
    }
    console.log('agencyTotalCnt:'+agencyTotalCnt);
    document.getElementById('agencyTotalNum').innerText = "상위기관수 : "+agencyTotalCnt;
    
   if(selectID == -99)selectID = '000000000000';
   page(selectID);
}



//메인 페이지에 기관코드 전송
function page(val_){
   
    var iframe = document.getElementById("main_view_frame");
 
    //var url = '/main?agc='+val_;
    var url = '/main?agc='+val_+'&dmy='+getCurrentTime() ;
    console.log(url);
    iframe.contentDocument.location.replace(url); //ifrmae의 페이지 이력을 남기지 않기(돌아가기 누르면 로그인 화면으로 감)
   // iframe.src = url; //ifrmae의 페이지 이력 남기기 (iframe은 과거의 페이지를 보여주지만 왼쪽의 사이드메뉴는 변하지 않으므로 사용하지 말것)
    return false;
}

//현재시간취득（yyyymmddhhmmss）
function getCurrentTime() {
    var now = new Date();
    var res = "" + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) + 
        padZero(now.getMinutes()) + padZero(now.getSeconds());
    return res;
}

//선두 제로 붙힘
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}

</script>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-bc737da" data-id="bc737da" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-115fef5" data-id="115fef5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-be8d566 elementor-widget elementor-widget-html" data-id="be8d566" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<div class="agencySearch" id="searchUnderAgency">
    <label class="label-disp" for="name">하위기관명 </label>
    <input class="agency_search" id ="agencysearch" type="text">
    <button class="searchBtn" type="button" onclick="findAgencyName()">검색</button>
</div>

<script type='text/javascript'>
if(appendAgencyState=="false")
 document.getElementById("searchUnderAgency").style.display = "none";


function findAgencyName(){
    
    var menuElem = document.getElementById('accordion');
        var c = menuElem.children;
        var searchResult = new Array();
        var parentName = '';
        var serchWord =  document.getElementById('agencysearch').value;

        for (var u = 0; u < c.length; u++) {
            var t = c.item(u).childNodes;
            for (var i = 0; i < t.length; i++) {
                if (t[i].nodeName == 'A') { //1차메뉴의 이름
                    parentName = t[i].innerText;
                }
                if (t[i].nodeName == 'UL') {
                    var t = t[i].childNodes;

                    for (var j = 0; j < t.length; j++) {
                        if (t[j].nodeName == 'LI') {
                            var t1 = t[j].hasChildNodes();
                            var subMenuName = t[j].innerText;
                            if(serchWord){ //비공백문자
                                if (subMenuName.match(serchWord)) {
                                    if (!searchResult.includes(parentName)) searchResult.push(parentName);//검색 단어의 상위기관명 추가
                                }
                            }
                        }
                    }
                }
            }
        }
        console.log('parentName:' + searchResult);
        console.log('parentName:' + searchResult.length); 
        if(searchResult.length>0){
           var str = searchResult.join(',');
           var title = "검색완료 ("+searchResult.length +"건)";
           swal(title, str, "success"); 
        }else{
           swal("검색완료", "결과 없음", "error");
        }
}
</script>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-ed076eb elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ed076eb" data-element_type="section" id="body_main" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-21ddc49" data-id="21ddc49" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ae6b4ba elementor-widget elementor-widget-text-editor" data-id="ae6b4ba" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-7930e8f elementor-widget elementor-widget-text-editor" data-id="7930e8f" data-element_type="widget" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<ul id="accordion"><li id="sub1"><a onclick="page('081165002001')";>방배노인종합복지관</a></li></ul></li></ul><script type='text/javascript'>jQuery(function () {  jQuery('#accordion li ul').show();  });</script>		<div class="elementor-text-editor elementor-clearfix"><p></p></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-170f397 elementor-widget elementor-widget-spacer" data-id="170f397" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-944f63a elementor-widget elementor-widget-spacer" data-id="944f63a" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-9ce544a" data-id="9ce544a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-02ba05b elementor-widget elementor-widget-html" data-id="02ba05b" data-element_type="widget" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="iframe-container">
    <iframe name="mainViewFrame" id="main_view_frame" frameborder="0" src="" >
            <p>Your browser does not support iframes.</p>
        </iframe>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4260221 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4260221" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2bfd3e2" data-id="2bfd3e2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-94848a9 elementor-widget elementor-widget-html" data-id="94848a9" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<a id ="svsort1"></a>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-6a7e93a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6a7e93a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-70bd07e" data-id="70bd07e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1fe170d elementor-widget elementor-widget-html" data-id="1fe170d" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<a id ="svsort1"></a>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		
	
</div>

</article>

				
			</div><!-- #content -->

			
		</div><!-- #primary -->

		
	</div><!-- #content-wrap -->

	

	</main><!-- #main -->

	
	
	
		
	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a id="scroll-top" class="scroll-top-right" href="#"><span class="fa fa-angle-up" aria-label="Scroll to the top of the page"></span></a>




<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.2' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"97cb914f92","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":9,"title":"menu%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
</body>
</html>

<!-- Dynamic page generated in 0.124 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-06 13:24:32 -->
