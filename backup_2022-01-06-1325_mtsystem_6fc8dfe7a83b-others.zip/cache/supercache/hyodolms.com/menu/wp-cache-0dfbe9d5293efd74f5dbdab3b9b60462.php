<?php die(); ?><!DOCTYPE html>
<html class="html" lang="ko-KR">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>menu &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.2' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-9-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-9.css?ver=1637748092' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.2' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.2' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/9" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.2" />
<link rel="canonical" href="http://hyodolms.com/menu/" />
<link rel='shortlink' href='http://hyodolms.com/?p=9' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fmenu%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fmenu%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style></head>

<body class="page-template-default page page-id-9 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled has-breadcrumbs elementor-default elementor-kit-10 elementor-page elementor-page-9" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
			
			<main id="main" class="site-main clr"  role="main">

				
	
	<div id="content-wrap" class="container clr">

		
		<div id="primary" class="content-area clr">

			
			<div id="content" class="site-content clr">

				
				
<article class="single-page-article clr">

	
<div class="entry clr" itemprop="text">

	
	<script>	var appendAgencyState 	= 'true';
					var dollEnvState		= 'true';
			</script>		<div data-elementor-type="wp-page" data-elementor-id="9" class="elementor elementor-9" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-d10eb99 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="d10eb99" data-element_type="section" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-7ac03db" data-id="7ac03db" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c66f9dd elementor-widget elementor-widget-image" data-id="c66f9dd" data-element_type="widget" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
											<a href="/login">
							<img src="http://hyodolms.com/wp-content/uploads/2021/04/hyodoltitle.png" title="hyodoltitle" alt="hyodoltitle" />								</a>
											</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-2afdfad" data-id="2afdfad" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-aa2fbcc elementor-widget elementor-widget-html" data-id="aa2fbcc" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			
<label class="label-disp" id="agencyTotalNum"></label>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>

<script type='text/javascript'>
jQuery(function () {
    var lastId = 'child1'; //default : 첫번째id 선택
    
    //-----------------------------------
    //선택한 lastId의 함수 자동실행
    //-----------------------------------
    //상위기관으로 로그인한 경우
    var menuElem = document.getElementById(lastId);
    if(menuElem == null){
         //하위기관으로 로그인한 경우
         lastId = 'sub1'; 
         menuElem = document.getElementById(lastId);
    }
    
    if(menuElem != null){
        if(menuElem.hasChildNodes()){
            var child = menuElem.childNodes;
            if(child[0].nodeName =='A'){
                child[0].click();  //lastId태그의 onClick 함수 실행
            }
        }
    }else{
        console.log("left menu error");
    }

    //-----------------------------------    
  
    elementColorProc(lastId); //메뉴 선택 상태로 전환
    
    jQuery("#accordion > li > a").click(function () {
        var click = jQuery(this).parent();
        var id = jQuery(click).attr('id');
        elementColorProc(id);

        //선택한 메뉴 오픈
        click.children('ul').slideDown('fast', function () {
            jQuery("#accordion ul").not(click.children('ul')).slideUp('fast');
            //예전 메뉴 닫기
            
        });
    });

    jQuery("#accordion > li > ul > li > a").click(function () {
        var click = jQuery(this).parent();
        var id = jQuery(click).attr('id');
        elementColorProc(id);
    });

    //선택한 요소의 색을 바꾸고 바로 전에 눌렸던 요소의 색을 원래색으로 되돌림
    function elementColorProc(id) {
        if (lastId.length) {
            if (~lastId.indexOf('child')) {
                //console.log('>' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#3F5160';//'#1b1b1b1b'; //Child~ id 의 원래색
            } else {
                //console.log('->' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#969EA4';//'#4f4f4f'; //서브 메뉴의 원래색
            }
        }
        //console.log('id:->' + id);
        document.getElementById(id).style.backgroundColor =  "#E37660";//"#d4a534"; //현재 선택 색(오랜지)
        lastId = id;
    }




    function resetSideMenu(){
        console.log('reset!');
         if (lastId.length) {
            if (~lastId.indexOf('child')) {
                //console.log('>' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#1b1b1b1b'; //Child~ id 의 원래색
            } else {
                //console.log('->' + lastId);
                document.getElementById(lastId).style.backgroundColor = '#4f4f4f'; //서브 메뉴의 원래색
            }
        }
        jQuery("#accordion ul").slideUp('fast');
    }

});




/*
//메인 페이지에 기관코드 전송
function page(val_){
    //console.log('>page:' + val_);
    var iframe = document.getElementById("main_view_frame");
    //iframe.src = '/main?agc='+val_;
    var url = '/main?agc='+val_+'&dmy='+getCurrentTime() ;
    console.log('---->url:' + url);
    iframe.contentDocument.location.replace(url); //ifrmae의 페이지 이력을 남기지 않기(돌아가기 누르면 로그인 화면으로 감)
   // iframe.src = url; //ifrmae의 페이지 이력 남기기 (iframe은 과거의 페이지를 보여주지만 왼쪽의 사이드메뉴는 변하지 않으므로 사용하지 말것)
    return false;
}
*/




</script> 


<!--dummy menu
<div>
    
    <ul id="accordion">
        <li id="child1"><a href="/?id=000000000000">전체</a>
            <ul>
                <li><a href="/?id=000000000001">개인사용자</a></li>
                <li><a href="/?id=000000000002">SCC테스트</a></li>
            </ul>
        </li>
        <li id="child2"><a>춘천시청</a>
            <ul>
                <li><a>춘천시청장애인종합복지관</a></li>
                <li><a>춘천시개인</a></li>
                <li><a>동부노인복지관</a></li>
                <li><a>별빛마을</a></li>
                <li><a>남부노인복지관</a></li>
                <li><a>북부노인복지관</a></li>
            </ul>
        </li>
        <li id="child3"><a>양산시청</a>
            <ul>
                <li><a onClick="">양산시청 사회복지과</a></li>
            </ul>
        </li>
        <li id="child3"><a>청도군 스마트시티</a>
            <ul>
                <li><a onClick="">신도1리</a></li>
            </ul>
            <ul>
                <li><a onClick="">신도2리</a></li>
            </ul>
        </li>
        <li id="child4"><a href="" onClick="run('a')">광양시청</a>
            <ul>
                <li><a onClick="">광양시 노인전문 요양원</a></li>
                <li><a onClick="run('3a3')">광양시 재가 </a></li>
            </ul>
        </li>
    </ul>
</div>
-->		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-0cbda4e" data-id="0cbda4e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a5feaa5 elementor-widget elementor-widget-html" data-id="a5feaa5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			

<button class="appendAgencyBtn" type="button" id="adminControl" onclick="showAdminControl()">통합관리</button>
<button class="appendAgencyBtn" type="button" id="appendAgencyButton" onclick="sendSms()">기관등록</button>

<!--
<button class="appendAgencyBtn" id="showEnvLink"  onclick="showDollEnvironmentLink()">인형 환경정보</button>
-->

<button class="appendAgencyBtn" id="grafanaLink"  onclick="showGrafanaLink()">Dash Board</button>

<div id="table_div" ></div>

<div id="newAgencyModal" class="agency-modal">
  <div class="agency-modal-content">
    <div class="agency-modal-title">기관등록</div>
       <button class="agency-modal-close-btn" id = "closeBtn" onclick="closeAgencyModalWindow()">&times;</button>
        <div class="agency-modal-phone-title">
            <p>기관명</p>
         </div>    
            <input class="agency-modal-code-area" id="agency-name-number" placeholder=""  type="text" maxlength="30" >
         <div class="agency-modal-message-title">
            <p>기관코드</p>    
        </div>
            <input class="agency-modal-code-area" id="agency-code-number" placeholder=""  type="text" maxlength="30" >
        <div></div>
            <button class="agency-modal-cancel-btn" id = "agency_cancelBtn" onclick="closeAgencyModalWindow()">취소</button>
            <button class="agency-modal-save-btn" id = "agency_saveBtn" onclick="appendAgency()">추가</button>
  </div>
</div>


<script>

//기관입력 표시 상태 
if(appendAgencyState=="false"){ 
document.getElementById("adminControl").style.display = "none";
document.getElementById("appendAgencyButton").style.display = "none";
document.getElementById("grafanaLink").style.display = "none";
}

if(dollEnvState == "false")
 document.getElementById("showEnvLink").style.display = "none";
   
function showDollEnvironmentLink(){
    //var url = "http://13.125.170.204/env/wmainlist";
    var url = '/doll_env_info?dmy='+getCurrentTime();
    window.open(url, "_blank");
}    

function showGrafanaLink(){
    //var url = "http://106.254.228.130:23001/d/V7XU8dXGk/scc-dashboard?orgId=1";
    let url = "http://15.164.89.157:3000/d/i2fKmVeMz/hyodol-dashboard?orgId=1&refresh=15m";
    window.open(url, "_blank");
}  

function appendAgency(){
    var agency_name  = document.getElementById('agency-name-number').value;
    var agency_code  = document.getElementById('agency-code-number').value;
    
    if(agency_name ==''){
        swal("입력오류", "기관명을 입력하세요", "warning");
        return;
    }

    if(agency_code == ''){
        swal("입력오류", "기관코드를 입력하세요", "warning");
        return;
    }   
    if(agency_code.length < 12)
    {
        swal("입력오류", "코드형식이 다릅니다. 다시 확인하세요.", "warning");
        return;
    }
    
    console.log('code:'+agency_code+',name:'+agency_name);
    
     jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'        :'append_new_agency',
            'agencyName'    : agency_name,
            'agencyCode'    : agency_code
        },
        success: function( response ){
           swal("기관추가 완료", "", "success");
        },
        error: function( response,status,error){
           swal("기관추가 실패", error, "error");
        }
    });
    
    document.getElementById('agency-name-number').value = '';
    document.getElementById('agency-code-number').value = '';
    
    closeAgencyModalWindow();
    return false; 
}



var agency_modal = document.getElementById("newAgencyModal");

function closeAgencyModalWindow(){
    
    document.getElementById("agency-name-number").value ='';
    document.getElementById("agency-code-number").value ='';
    
    agency_modal.style.display = "none";
}


function sendSms(){
    agency_modal.style.display = "block";
}

// 모달윈도우 밖을 클릭했을때
window.onclick = function(event) {
  if (event.target == agency_modal) {
   closeAgencyModalWindow();
  }
}

//통합관리 
function showAdminControl(){
   var url =  '/admin_page?dmy='+getCurrentTime();
   window.open(url, "_blank");
                            //서버 갱신을 위해서 더미(현재시간)를 추가
}

//현재시간취득（yyyymmddhhmmss）
function getCurrentTime() {
    var now = new Date();
    var res = "" + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) + 
        padZero(now.getMinutes()) + padZero(now.getSeconds());
    return res;
}

//선두 제로 붙힘
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}
</script>
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-070355a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="070355a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3dfe6d7" data-id="3dfe6d7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-855af17 elementor-widget elementor-widget-html" data-id="855af17" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="form_radio_btn1" id="searchAreaRadio">

        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_1" autocomplete="off" checked="checked"
                onclick="selectArea('-99')">
            <label for="radio_1">전체</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_2" autocomplete="off" onclick="selectArea('11')">
            <label for="radio_2">서울시</label>
        </div>
        
      <!--  <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_3" autocomplete="off" onclick="selectArea('33')">
            <label for="radio_3">세종시</label>
        </div>
        -->
        
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_4" autocomplete="off" onclick="selectArea('28')">
            <label for="radio_4">인천시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_5" autocomplete="off" onclick="selectArea('30')">
            <label for="radio_5">대전시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_6" autocomplete="off" onclick="selectArea('31')">
            <label for="radio_6">울산시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_7" autocomplete="off" onclick="selectArea('29')">
            <label for="radio_7">광주시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_8" autocomplete="off" onclick="selectArea('27')">
            <label for="radio_8">대구시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_9" autocomplete="off" onclick="selectArea('26')">
            <label for="radio_9">부산시</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_10" autocomplete="off" onclick="selectArea('41')">
            <label for="radio_10">경기도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_11" autocomplete="off" onclick="selectArea('42')">
            <label for="radio_11">강원도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_12" autocomplete="off" onclick="selectArea('43')">
            <label for="radio_12">충북도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_13" autocomplete="off" onclick="selectArea('44')">
            <label for="radio_13">충남도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_14" autocomplete="off" onclick="selectArea('45')">
            <label for="radio_14">전북도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_15" autocomplete="off" onclick="selectArea('46')">
            <label for="radio_15">전남도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_16" autocomplete="off" onclick="selectArea('47')">
            <label for="radio_16">경북도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_17" autocomplete="off" onclick="selectArea('48')">
            <label for="radio_17">경남도</label>
        </div>
        <div class="form_radio_btn">
            <input type="radio" name="options" id="radio_18" autocomplete="off" onclick="selectArea('50')">
            <label for="radio_18">제주도</label>
        </div>
    </div>


<script>
if(appendAgencyState=="false"){
 document.getElementById("searchAreaRadio").style.display = "none";
 document.getElementById("agencyTotalNum").style.display = "none";
}
 
function selectArea(selectID) {
    
    console.log('selectID:'+selectID);
    var menuElem = document.getElementById('accordion');
    var c = menuElem.children;
    var searchResult = new Array();
    var parentName = '';

    var agencyTotalCnt = 0; //상위기관 총수
    //
    jQuery("#accordion ul").slideUp('fast'); //열린 서브 메뉴 닫기
    //
    for (var u = 0; u < c.length; u++) {
        var t = c.item(u).childNodes;
        var pId = c.item(u).id;
            for (var i = 0; i < t.length; i++) {
               if (t[i].nodeName == 'A') { //1차메뉴의 이름
                parentName = t[i].innerText;
                var id = t[i].id;

                if (selectID == -99) {
                    document.getElementById(pId).style.display = "block"; //전체표시
                    agencyTotalCnt++;
                }else{
                    if (selectID == (t[i].id).slice(2, 4)) {
                        document.getElementById(pId).style.display = "block"; //해당기관표시
                        agencyTotalCnt++;
                    } else {
                        document.getElementById(pId).style.display = "none"; //비해당기관 비표시
                    }
                }
            }
           document.getElementById(pId).style.backgroundColor = '#1b1b1b1b';//메뉴 컬러를 원래대로. 서브메뉴 컬러는 변경않함(메뉴를 닫으므로)
        }
    }
    console.log('agencyTotalCnt:'+agencyTotalCnt);
    document.getElementById('agencyTotalNum').innerText = "상위기관수 : "+agencyTotalCnt;
    
   if(selectID == -99)selectID = '000000000000';
   page(selectID);
}



//메인 페이지에 기관코드 전송
function page(val_){
   
    var iframe = document.getElementById("main_view_frame");
 
    //var url = '/main?agc='+val_;
    var url = '/main?agc='+val_+'&dmy='+getCurrentTime() ;
    console.log(url);
    iframe.contentDocument.location.replace(url); //ifrmae의 페이지 이력을 남기지 않기(돌아가기 누르면 로그인 화면으로 감)
   // iframe.src = url; //ifrmae의 페이지 이력 남기기 (iframe은 과거의 페이지를 보여주지만 왼쪽의 사이드메뉴는 변하지 않으므로 사용하지 말것)
    return false;
}

//현재시간취득（yyyymmddhhmmss）
function getCurrentTime() {
    var now = new Date();
    var res = "" + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) + 
        padZero(now.getMinutes()) + padZero(now.getSeconds());
    return res;
}

//선두 제로 붙힘
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}

</script>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-bc737da" data-id="bc737da" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-115fef5" data-id="115fef5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-be8d566 elementor-widget elementor-widget-html" data-id="be8d566" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<div class="agencySearch" id="searchUnderAgency">
    <label class="label-disp" for="name">하위기관명 </label>
    <input class="agency_search" id ="agencysearch" type="text">
    <button class="searchBtn" type="button" onclick="findAgencyName()">검색</button>
</div>

<script type='text/javascript'>
if(appendAgencyState=="false")
 document.getElementById("searchUnderAgency").style.display = "none";


function findAgencyName(){
    
    var menuElem = document.getElementById('accordion');
        var c = menuElem.children;
        var searchResult = new Array();
        var parentName = '';
        var serchWord =  document.getElementById('agencysearch').value;

        for (var u = 0; u < c.length; u++) {
            var t = c.item(u).childNodes;
            for (var i = 0; i < t.length; i++) {
                if (t[i].nodeName == 'A') { //1차메뉴의 이름
                    parentName = t[i].innerText;
                }
                if (t[i].nodeName == 'UL') {
                    var t = t[i].childNodes;

                    for (var j = 0; j < t.length; j++) {
                        if (t[j].nodeName == 'LI') {
                            var t1 = t[j].hasChildNodes();
                            var subMenuName = t[j].innerText;
                            if(serchWord){ //비공백문자
                                if (subMenuName.match(serchWord)) {
                                    if (!searchResult.includes(parentName)) searchResult.push(parentName);//검색 단어의 상위기관명 추가
                                }
                            }
                        }
                    }
                }
            }
        }
        console.log('parentName:' + searchResult);
        console.log('parentName:' + searchResult.length); 
        if(searchResult.length>0){
           var str = searchResult.join(',');
           var title = "검색완료 ("+searchResult.length +"건)";
           swal(title, str, "success"); 
        }else{
           swal("검색완료", "결과 없음", "error");
        }
}
</script>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-ed076eb elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ed076eb" data-element_type="section" id="body_main" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-21ddc49" data-id="21ddc49" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ae6b4ba elementor-widget elementor-widget-text-editor" data-id="ae6b4ba" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-7930e8f elementor-widget elementor-widget-text-editor" data-id="7930e8f" data-element_type="widget" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<ul id="accordion"><li id="child1"><a id='000000000000' onclick="page('000000000000')";>전체</a><ul><li id="sub1"><a onclick="page('000000000001')";>개인 사용자</a></li><li id="sub2"><a onclick="page('000000000002')";>SCC 테스트</a></li></ul></li><li id="child2"><a id='014211001000' onclick="page('014211001000')";>춘천시청</a><ul><li id="sub3"><a onclick="page('014211001001')";>춘천시장애인종합복지관</a></li><li id="sub4"><a onclick="page('014211001002')";>춘천시개인</a></li><li id="sub5"><a onclick="page('014211001003')";>동부노인복지관</a></li><li id="sub6"><a onclick="page('014211001004')";>별빛마을</a></li><li id="sub7"><a onclick="page('014211001005')";>남부노인복지관</a></li><li id="sub8"><a onclick="page('014211001006')";>북부노인복지관</a></li></ul></li><li id="child3"><a id='014518001000' onclick="page('014518001000')";>정읍시 치매안심센터</a><ul><li id="sub9"><a onclick="page('014518001001')";>정읍시 치매안심센터</a></li></ul></li><li id="child4"><a id='014833001000' onclick="page('014833001000')";>양산시청</a><ul><li id="sub10"><a onclick="page('014833001001')";>양산시청 사회복지과</a></li></ul></li><li id="child5"><a id='024623001000' onclick="page('024623001000')";>광양시청</a><ul><li id="sub11"><a onclick="page('024623001002')";>광양시 노인 전문 요양원</a></li><li id="sub12"><a onclick="page('024623001901')";>광양시 재가</a></li></ul></li><li id="child6"><a id='024782001000' onclick="page('024782001000')";>청도군 스마트시티</a><ul><li id="sub13"><a onclick="page('024782001001')";>신도1리</a></li><li id="sub14"><a onclick="page('024782001002')";>신도2리</a></li></ul></li><li id="child7"><a id='031153002000' onclick="page('031153002000')";>구로구청</a><ul><li id="sub15"><a onclick="page('031153002001')";>궁동종합사회복지관</a></li><li id="sub16"><a onclick="page('031153002002')";>구로어르신돌봄통합센터</a></li><li id="sub17"><a onclick="page('031153002007')";>구로종합사회복지관</a></li><li id="sub18"><a onclick="page('031153002008')";>구로노인종합복지관</a></li><li id="sub19"><a onclick="page('031153002009')";>구로구청 스마트시티과</a></li></ul></li><li id="child8"><a id='031154502000' onclick="page('031154502000')";>금천구청</a><ul><li id="sub20"><a onclick="page('031154502001')";>금천구노인복지관</a></li></ul></li><li id="child9"><a id='031159002000' onclick="page('031159002000')";>동작구청</a><ul><li id="sub21"><a onclick="page('031159002001')";>노량진1동주민센터</a></li></ul></li><li id="child10"><a id='032729002000' onclick="page('032729002000')";>대구 수성구청</a><ul><li id="sub22"><a onclick="page('032729002001')";>황금 복지관</a></li><li id="sub23"><a onclick="page('032729002002')";>범물복지관</a></li><li id="sub24"><a onclick="page('032729002003')";>지산복지관</a></li><li id="sub25"><a onclick="page('032729002004')";>홀트대구종합사회복지관</a></li><li id="sub26"><a onclick="page('032729002005')";>청곡종합사회복지관</a></li></ul></li><li id="child11"><a id='034420001000' onclick="page('034420001000')";>아산시청</a><ul><li id="sub27"><a onclick="page('034420001001')";>아산시노인종합복지관</a></li><li id="sub28"><a onclick="page('034420001002')";>아산시노인종합복지관체온</a></li><li id="sub29"><a onclick="page('034420001003')";>아산시종합사회복지관</a></li><li id="sub30"><a onclick="page('034420001004')";>온양노인복지센터</a></li></ul></li><li id="child12"><a id='034684001000' onclick="page('034684001000')";>성장동력</a><ul><li id="sub31"><a onclick="page('034684001001')";>하당노인복지관</a></li><li id="sub32"><a onclick="page('034684001002')";>목포시노인복지관</a></li><li id="sub33"><a onclick="page('034684001003')";>여수시노인복지관</a></li><li id="sub34"><a onclick="page('034684001004')";>미평종합사회복지관</a></li><li id="sub35"><a onclick="page('034684001005')";>(사)월드비전커뮤니티</a></li><li id="sub36"><a onclick="page('034684001006')";>고구려대학교 노인복지센터</a></li></ul></li><li id="child13"><a id='043011002000' onclick="page('043011002000')";>대전 동구청</a><ul><li id="sub37"><a onclick="page('043011002001')";>행복한 복지관</a></li><li id="sub38"><a onclick="page('043011002002')";>정다운 복지관</a></li><li id="sub39"><a onclick="page('043011002003')";>금성노인복지센터</a></li><li id="sub40"><a onclick="page('043011002004')";>선우노인복지센터</a></li><li id="sub41"><a onclick="page('043011002005')";>대전동구청2020</a></li><li id="sub42"><a onclick="page('043011002090')";>지사-04</a></li></ul></li><li id="child14"><a id='044159001000' onclick="page('044159001000')";>화성시</a><ul><li id="sub43"><a onclick="page('044159001001')";>화성시자살예방센터</a></li></ul></li><li id="child15"><a id='053000001000' onclick="page('053000001000')";>대전시</a><ul><li id="sub44"><a onclick="page('053000001001')";>유성구노인복지관</a></li><li id="sub45"><a onclick="page('053000001002')";>대덕종합사회복지관</a></li><li id="sub46"><a onclick="page('053000001003')";>대전시노인복지관</a></li><li id="sub47"><a onclick="page('053000001004')";>서구노인복지관</a></li><li id="sub48"><a onclick="page('053000001005')";>대전지방보훈청</a></li></ul></li><li id="child16"><a id='074413001000' onclick="page('074413001000')";>천안시청</a><ul><li id="sub49"><a onclick="page('074413001001')";>천안시청</a></li></ul></li><li id="child17"><a id='074678002000' onclick="page('074678002000')";>보성군청</a><ul><li id="sub50"><a onclick="page('074678002001')";>보성종합사회복지관</a></li><li id="sub51"><a onclick="page('074678002002')";>사회적협동조합 보성지역자활센터</a></li><li id="sub52"><a onclick="page('074678002003')";>보성군 노인복지관</a></li></ul></li><li id="child18"><a id='081165002000' onclick="page('081165002000')";>서초구청</a><ul><li id="sub53"><a onclick="page('081165002001')";>방배노인종합복지관</a></li><li id="sub54"><a onclick="page('081165002002')";>서초어르신행복이음센터</a></li></ul></li><li id="child19"><a id='084477002000' onclick="page('084477002000')";>서천군청</a><ul><li id="sub55"><a onclick="page('084477002001')";>서천읍 행정복지센터</a></li></ul></li><li id="child20"><a id='091111001000' onclick="page('091111001000')";>종로구청</a><ul><li id="sub56"><a onclick="page('091111001001')";>삼청동 주민센터</a></li><li id="sub57"><a onclick="page('091111001002')";>부암동 주민센터</a></li><li id="sub58"><a onclick="page('091111001003')";>평창동 주민센터</a></li><li id="sub59"><a onclick="page('091111001004')";>무악동 주민센터</a></li><li id="sub60"><a onclick="page('091111001005')";>가회동 주민센터</a></li><li id="sub61"><a onclick="page('091111001006')";>종로1,2,3,4가동 주민센터</a></li><li id="sub62"><a onclick="page('091111001007')";>종로5,6가동 주민센터</a></li><li id="sub63"><a onclick="page('091111001008')";>이화동 주민센터</a></li><li id="sub64"><a onclick="page('091111001009')";>혜화동 주민센터</a></li><li id="sub65"><a onclick="page('091111001010')";>창신1동 주민센터</a></li><li id="sub66"><a onclick="page('091111001011')";>창신2동 주민센터</a></li><li id="sub67"><a onclick="page('091111001012')";>창신3동 주민센터</a></li><li id="sub68"><a onclick="page('091111001013')";>숭인1동 주민센터</a></li><li id="sub69"><a onclick="page('091111001014')";>숭인2동 주민센터</a></li></ul></li><li id="child21"><a id='091135001000' onclick="page('091135001000')";>시립노원노인종합복지관</a><ul><li id="sub70"><a onclick="page('091135001001')";>시립노원노인종합복지관</a></li></ul></li><li id="child22"><a id='102823702000' onclick="page('102823702000')";>인천 부평구청</a><ul><li id="sub71"><a onclick="page('102823702001')";>갈산종합사회복지관</a></li><li id="sub72"><a onclick="page('102823702002')";>부개3동</a></li><li id="sub73"><a onclick="page('102823702003')";>부평4동</a></li><li id="sub74"><a onclick="page('102823702004')";>부평6동</a></li><li id="sub75"><a onclick="page('102823702005')";>부평구노인복지관</a></li><li id="sub76"><a onclick="page('102823702006')";>부평재가노인지원서비스센터</a></li><li id="sub77"><a onclick="page('102823702007')";>부평중부종합사회복지관</a></li><li id="sub78"><a onclick="page('102823702008')";>사회보장과</a></li><li id="sub79"><a onclick="page('102823702009')";>삼산1동</a></li><li id="sub80"><a onclick="page('102823702010')";>삼산2동</a></li><li id="sub81"><a onclick="page('102823702011')";>삼산종합사회복지관</a></li><li id="sub82"><a onclick="page('102823702012')";>인천부평남부지역자활센터</a></li><li id="sub83"><a onclick="page('102823702013')";>인천평화의료복지 사회적협동조합</a></li><li id="sub84"><a onclick="page('102823702014')";>정다운노인요양센터</a></li><li id="sub85"><a onclick="page('102823702015')";>청천1동</a></li><li id="sub86"><a onclick="page('102823702016')";>청천2동</a></li><li id="sub87"><a onclick="page('102823702017')";>치매정신건강과</a></li><li id="sub88"><a onclick="page('102823702018')";>십정1동</a></li><li id="sub89"><a onclick="page('102823702019')";>부개1동</a></li></ul></li><li id="child23"><a id='111162002000' onclick="page('111162002000')";>관악구청 </a><ul><li id="sub90"><a onclick="page('111162002001')";>관악구청</a></li></ul></li><li id="child24"><a id='124719001000' onclick="page('124719001000')";>구미시청</a><ul><li id="sub91"><a onclick="page('124719001001')";>강동재가노인통합지원센터</a></li><li id="sub92"><a onclick="page('124719001002')";>구미재가노인통합지원센터</a></li><li id="sub93"><a onclick="page('124719001003')";>금오재가노인통합지원센터</a></li><li id="sub94"><a onclick="page('124719001004')";>성심재가노인통합지원센터</a></li></ul></li><li id="child25"><a id='191220123000' onclick="page('191220123000')";>팜월드상급기관</a><ul><li id="sub95"><a onclick="page('191220123001')";>팜월드하급기관</a></li><li id="sub96"><a onclick="page('191220123002')";>파주시 치매안심센터</a></li><li id="sub97"><a onclick="page('191220123003')";>계양구 치매안심센터</a></li><li id="sub98"><a onclick="page('191220123004')";>강릉시 치매안심센터</a></li><li id="sub99"><a onclick="page('191220123005')";>일산동구 치매안심센터</a></li><li id="sub100"><a onclick="page('191220123006')";>대구북구 치매안심센터</a></li><li id="sub101"><a onclick="page('191220123007')";>용인시 처인구 치매안심센터</a></li><li id="sub102"><a onclick="page('191220123008')";>부산 금정구 치매안심센터</a></li><li id="sub103"><a onclick="page('191220123009')";>안성시 치매안심센터</a></li><li id="sub104"><a onclick="page('191220123010')";>경기도 가평군 치매안심센터</a></li><li id="sub105"><a onclick="page('191220123011')";>경기도 광주 치매안심센터</a></li><li id="sub106"><a onclick="page('191220123012')";>노원구 보건소</a></li><li id="sub107"><a onclick="page('191220123013')";>함양군 보건소 치매안심센터</a></li><li id="sub108"><a onclick="page('191220123014')";>양양군 치매안심센터</a></li><li id="sub109"><a onclick="page('191220123015')";>강화군 치매안심센터</a></li><li id="sub110"><a onclick="page('191220123017')";>강화군정신건강증진센터</a></li></ul></li><li id="child26"><a id='204211001000' onclick="page('204211001000')";>강원대프로젝트</a><ul><li id="sub111"><a onclick="page('204211001001')";>강원대환경센서인형</a></li></ul></li><li id="child27"><a id='211117003000' onclick="page('211117003000')";>용산구치매안심센터</a><ul><li id="sub112"><a onclick="page('211117003001')";>용산구치매안심센터</a></li></ul></li><li id="child28"><a id='211126003000' onclick="page('211126003000')";>서울 의료원</a><ul><li id="sub113"><a onclick="page('211126003001')";>서울 의료원</a></li><li id="sub114"><a onclick="page('211126003002')";>성동구 보건소</a></li></ul></li><li id="child29"><a id='211138001000' onclick="page('211138001000')";>서울시 은평구</a><ul><li id="sub115"><a onclick="page('211138001001')";>갈현1동주민센터</a></li></ul></li><li id="child30"><a id='211156001000' onclick="page('211156001000')";>영등포구</a><ul><li id="sub116"><a onclick="page('211156001002')";>신길3동 주민센터</a></li></ul></li><li id="child31"><a id='212911003000' onclick="page('212911003000')";>광주 동구</a><ul><li id="sub117"><a onclick="page('212911003001')";>광주동구보건소</a></li></ul></li><li id="child32"><a id='214136003000' onclick="page('214136003000')";>남양주 치매안심센터</a><ul><li id="sub118"><a onclick="page('214136003001')";>남양주 치매안심센터</a></li></ul></li><li id="child33"><a id='214423003000' onclick="page('214423003000')";>논산시 보건소</a><ul><li id="sub119"><a onclick="page('214423003001')";>논산시 보건소</a></li></ul></li><li id="child34"><a id='222826002000' onclick="page('222826002000')";>인천 서구 검단</a><ul><li id="sub120"><a onclick="page('222826002001')";>검단노인복지관</a></li></ul></li><li id="child35"><a id='224480004000' onclick="page('224480004000')";>홍성군 구항면행정복지센터</a><ul><li id="sub121"><a onclick="page('224480004001')";>홍성군 구항면행정복지센터</a></li></ul></li><li id="child36"><a id='224481003000' onclick="page('224481003000')";>충남 예산군</a><ul><li id="sub122"><a onclick="page('224481003001')";>충남 예산군보건소</a></li></ul></li><li id="child37"><a id='234280003000' onclick="page('234280003000')";>양구군 정신건강복지센터</a><ul><li id="sub123"><a onclick="page('234280003001')";>양구군 정신건강복지센터</a></li></ul></li><li id="child38"><a id='234377003000' onclick="page('234377003000')";>충북 음성군 보건소</a><ul><li id="sub124"><a onclick="page('234377003001')";>충북 음성군 보건소</a></li></ul></li><li id="child39"><a id='234388003000' onclick="page('234388003000')";>충북 단양군 보건소</a><ul><li id="sub125"><a onclick="page('234388003001')";>충북 단양군 보건소</a></li></ul></li><li id="child40"><a id='234480003000' onclick="page('234480003000')";>홍성군 보건소</a><ul><li id="sub126"><a onclick="page('234480003001')";>홍성군 보건소</a></li></ul></li><li id="child41"><a id='244713003000' onclick="page('244713003000')";>경주시 정신건강복지센터</a><ul><li id="sub127"><a onclick="page('244713003001')";>경주시 정신건강복지센터</a></li></ul></li><li id="child42"><a id='254182002000' onclick="page('254182002000')";>가평군 설악면행정복지센터</a><ul><li id="sub128"><a onclick="page('254182002001')";>설악면행정복지센터</a></li></ul></li><li id="child43"><a id='264121003000' onclick="page('264121003000')";>광명시 보건소</a><ul><li id="sub129"><a onclick="page('264121003001')";>광명시 보건소</a></li></ul></li><li id="child44"><a id='411121504000' onclick="page('411121504000')";>정립회관</a><ul><li id="sub130"><a onclick="page('411121504001')";>정립회관</a></li></ul></li><li id="child45"><a id='412915504000' onclick="page('412915504000')";>광주 남구</a><ul><li id="sub131"><a onclick="page('412915504001')";>광주남구 장애인종합복지관</a></li></ul></li><li id="child46"><a id='414122004000' onclick="page('414122004000')";>평택북부노인복지관</a><ul><li id="sub132"><a onclick="page('414122004001')";>평택북부노인복지관</a></li></ul></li><li id="child47"><a id='414127104000' onclick="page('414127104000')";>안산시 상록재가노인지원서비스센터</a><ul><li id="sub133"><a onclick="page('414127104001')";>상록재가노인지원서비스센터</a></li></ul></li><li id="child48"><a id='414128101000' onclick="page('414128101000')";>사회복지법인효샘</a><ul><li id="sub134"><a onclick="page('414128101001')";>효심재가노인지원</a></li></ul></li><li id="child49"><a id='414148001000' onclick="page('414148001000')";>파주시청</a><ul><li id="sub135"><a onclick="page('414148001001')";>파주시노인복지관</a></li></ul></li><li id="child50"><a id='414211004000' onclick="page('414211004000')";>춘천효자종합복지관</a><ul><li id="sub136"><a onclick="page('414211004001')";>춘천효자종합복지관</a></li></ul></li><li id="child51"><a id='414219004000' onclick="page('414219004000')";>강원도 태백시</a><ul><li id="sub137"><a onclick="page('414219004001')";>태백노인복지센터</a></li></ul></li><li id="child52"><a id='414617004000' onclick="page('414617004000')";>나주시노인복지관</a><ul><li id="sub138"><a onclick="page('414617004001')";>나주시노인복지관</a></li></ul></li><li id="child53"><a id='414812504000' onclick="page('414812504000')";>경상남도 창원시</a><ul><li id="sub139"><a onclick="page('414812504001')";>금강노인종합복지관</a></li></ul></li><li id="child54"><a id='415011004000' onclick="page('415011004000')";>제주시</a><ul><li id="sub140"><a onclick="page('415011004001')";>제주시홀로사는노인지원센터</a></li></ul></li><li id="child55"><a id='415013004000' onclick="page('415013004000')";>서귀포시</a><ul><li id="sub141"><a onclick="page('415013004001')";>서귀포시홀로사는노인지원센터</a></li></ul></li><li id="child56"><a id='424128104000' onclick="page('424128104000')";>고양시 덕양구</a><ul><li id="sub142"><a onclick="page('424128104001')";>덕양노인복지관</a></li></ul></li><li id="child57"><a id='424128704000' onclick="page('424128704000')";>고양시 일산서구</a><ul><li id="sub143"><a onclick="page('424128704001')";>대화종합노인복지관</a></li></ul></li><li id="child58"><a id='434111104000' onclick="page('434111104000')";>수원시</a><ul><li id="sub144"><a onclick="page('434111104001')";>밤밭노인복지관</a></li></ul></li><li id="child59"><a id='434111704000' onclick="page('434111704000')";>수원시 영통구</a><ul><li id="sub145"><a onclick="page('434111704002')";>광교종합사회복지관</a></li></ul></li><li id="child60"><a id='434163004000' onclick="page('434163004000')";>양주시</a><ul><li id="sub146"><a onclick="page('434163004001')";>양주시장애인복지관</a></li></ul></li><li id="child61"><a id='444113504000' onclick="page('444113504000')";>성남시 분당구</a><ul><li id="sub147"><a onclick="page('444113504001')";>성남고령친화체험관(19.09)</a></li></ul></li><li id="child62"><a id='451114004000' onclick="page('451114004000')";>서울시 중구</a><ul><li id="sub148"><a onclick="page('451114004001')";>약수노인종합복지관</a></li></ul></li><li id="child63"><a id='451168004000' onclick="page('451168004000')";>수서 종합사회복지관</a><ul><li id="sub149"><a onclick="page('451168004001')";>수서 종합사회복지관</a></li></ul></li><li id="child64"><a id='452826004000' onclick="page('452826004000')";>인천 서구 노인</a><ul><li id="sub150"><a onclick="page('452826004001')";>인천 서구 노인복지관</a></li></ul></li><li id="child65"><a id='454113504000' onclick="page('454113504000')";>분당노인복지관</a><ul><li id="sub151"><a onclick="page('454113504001')";>분당노인복지관</a></li></ul></li><li id="child66"><a id='454213004000' onclick="page('454213004000')";>강원도 원주시 밥상공동체</a><ul><li id="sub152"><a onclick="page('454213004001')";>원주 밥상공동체종합복지관</a></li></ul></li><li id="child67"><a id='464213004000' onclick="page('464213004000')";>강원도 원주시 명륜</a><ul><li id="sub153"><a onclick="page('464213004001')";>명륜종합사회복지관</a></li></ul></li><li id="child68"><a id='471144004000' onclick="page('471144004000')";>서울시노인종합복지관협회</a><ul><li id="sub154"><a onclick="page('471144004001')";>강북노인종합복지관</a></li><li id="sub155"><a onclick="page('471144004002')";>강서노인종합복지관</a></li><li id="sub156"><a onclick="page('471144004003')";>광진노인종합복지관</a></li><li id="sub157"><a onclick="page('471144004004')";>금천호암노인종합복지관</a></li><li id="sub158"><a onclick="page('471144004005')";>도봉노인종합복지관</a></li><li id="sub159"><a onclick="page('471144004006')";>동대문노인종합복지관</a></li><li id="sub160"><a onclick="page('471144004007')";>성가정노인종합복지관</a></li><li id="sub161"><a onclick="page('471144004008')";>성동노인종합복지관</a></li><li id="sub162"><a onclick="page('471144004009')";>성북노인종합복지관</a></li><li id="sub163"><a onclick="page('471144004010')";>송파노인종합복지관</a></li><li id="sub164"><a onclick="page('471144004011')";>양천어르신종합복지관</a></li><li id="sub165"><a onclick="page('471144004012')";>용산노인종합복지관</a></li><li id="sub166"><a onclick="page('471144004013')";>은평노인종합복지관</a></li><li id="sub167"><a onclick="page('471144004014')";>종로노인종합복지관</a></li><li id="sub168"><a onclick="page('471144004015')";>중랑노인종합복지관</a></li><li id="sub169"><a onclick="page('471144004016')";>강남노인종합복지관</a></li><li id="sub170"><a onclick="page('471144004017')";>강남시니어플라자</a></li><li id="sub171"><a onclick="page('471144004018')";>강동노인종합복지관</a></li><li id="sub172"><a onclick="page('471144004019')";>관악노인종합복지관</a></li><li id="sub173"><a onclick="page('471144004020')";>금천노인종합복지관</a></li><li id="sub174"><a onclick="page('471144004021')";>노원노인종합복지관</a></li><li id="sub175"><a onclick="page('471144004022')";>동작노인종합복지관</a></li><li id="sub176"><a onclick="page('471144004023')";>목동실버복지 문화센터</a></li><li id="sub177"><a onclick="page('471144004024')";>사당어르신 종합복지관</a></li><li id="sub178"><a onclick="page('471144004025')";>서울노인복지센터</a></li><li id="sub179"><a onclick="page('471144004026')";>서초구립중앙노인종합복지관</a></li><li id="sub180"><a onclick="page('471144004027')";>신내노인종합복지관</a></li><li id="sub181"><a onclick="page('471144004028')";>구립약수노인종합복지관</a></li><li id="sub182"><a onclick="page('471144004029')";>양재노인종합복지관</a></li><li id="sub183"><a onclick="page('471144004030')";>우리마포복지관</a></li></ul></li><li id="child69"><a id='484113104000' onclick="page('484113104000')";>성남시 수정노인복지관</a><ul><li id="sub184"><a onclick="page('484113104001')";>수정노인종합복지관</a></li></ul></li><li id="child70"><a id='494272004000' onclick="page('494272004000')";>강원도 홍천군노인복지관</a><ul><li id="sub185"><a onclick="page('494272004001')";>홍천군노인복지관</a></li></ul></li><li id="child71"><a id='504121004000' onclick="page('504121004000')";>광명시 광명종합사회복지관</a><ul><li id="sub186"><a onclick="page('504121004001')";>광명종합사회복지관</a></li></ul></li><li id="child72"><a id='511168004000' onclick="page('511168004000')";>시니어케어24</a><ul><li id="sub187"><a onclick="page('511168004001')";>시니어케어24</a></li></ul></li><li id="child73"><a id='512771004000' onclick="page('512771004000')";>효경복지공동체</a><ul><li id="sub188"><a onclick="page('512771004001')";>효경복지공동체</a></li></ul></li><li id="child74"><a id='512817007000' onclick="page('512817007000')";>인천시</a><ul><li id="sub189"><a onclick="page('512817007001')";>두뇌톡톡뇌건강학교</a></li></ul></li><li id="child75"><a id='514111501000' onclick="page('514111501000')";>경기복지재단</a><ul><li id="sub190"><a onclick="page('514111501001')";>부천재가센터</a></li><li id="sub191"><a onclick="page('514111501002')";>남양주재가센터</a></li></ul></li><li id="child76"><a id='514136004000' onclick="page('514136004000')";>경기 남양주</a><ul><li id="sub192"><a onclick="page('514136004001')";>남양주서부희망케어센터</a></li></ul></li><li id="child77"><a id='514145004000' onclick="page('514145004000')";>경기도 하남시</a><ul><li id="sub193"><a onclick="page('514145004001')";>하남요양방문가정센터</a></li></ul></li><li id="child78"><a id='514211001000' onclick="page('514211001000')";>춘천시</a><ul><li id="sub194"><a onclick="page('514211001022')";>별빛마을 리빙랩</a></li><li id="sub195"><a onclick="page('514211001029')";>개인</a></li><li id="sub196"><a onclick="page('514211001030')";>춘천시 정신건강복지센터</a></li></ul></li><li id="child79"><a id='514217004000' onclick="page('514217004000')";>동해지역자활센터</a><ul><li id="sub197"><a onclick="page('514217004001')";>동해지역자활센터</a></li></ul></li><li id="child80"><a id='524719004000' onclick="page('524719004000')";>은빛재가노인통합지원센터</a><ul><li id="sub198"><a onclick="page('524719004001')";>은빛재가노인통합지원센터</a></li></ul></li><li id="child81"><a id='531141007000' onclick="page('531141007000')";>산돌재가노인복지센터</a><ul><li id="sub199"><a onclick="page('531141007001')";>산돌재가노인복지센터</a></li></ul></li><li id="child82"><a id='711141001000' onclick="page('711141001000')";>타임뱅크코리아</a><ul><li id="sub200"><a onclick="page('711141001001')";>타임뱅크코리아</a></li></ul></li><li id="child83"><a id='712105060000' onclick="page('712105060000')";>애드에이블</a><ul><li id="sub201"><a onclick="page('712105060001')";>충주시치매안심센터</a></li></ul></li><li id="child84"><a id='712105140000' onclick="page('712105140000')";>서울남부보훈지청관리</a><ul><li id="sub202"><a onclick="page('712105140001')";>서울남부보훈지청</a></li></ul></li><li id="child85"><a id='714623007000' onclick="page('714623007000')";>포스코</a><ul><li id="sub203"><a onclick="page('714623007001')";>포스코 광양</a></li></ul></li><li id="child86"><a id='724213007000' onclick="page('724213007000')";>대구 서구 적십자사</a><ul><li id="sub204"><a onclick="page('724213007001')";>적십자사 대구광역지사</a></li></ul></li><li id="child87"><a id='804103001000' onclick="page('804103001000')";>의정부 치매 안심 센터</a><ul><li id="sub205"><a onclick="page('804103001001')";>의정부 치매 안심 센터 설치</a></li></ul></li><li id="child88"><a id='814115003000' onclick="page('814115003000')";>의정부시 장암동주민센터</a><ul><li id="sub206"><a onclick="page('814115003001')";>의정부시 장암동주민센터</a></li></ul></li><li id="child89"><a id='901234501000' onclick="page('901234501000')";>SCC B2C</a><ul><li id="sub207"><a onclick="page('901234501001')";>네이버팜</a></li><li id="sub208"><a onclick="page('901234501002')";>오더스테이션</a></li></ul></li><li id="child90"><a id='992009231000' onclick="page('992009231000')";>임베디드센터</a><ul><li id="sub209"><a onclick="page('992009231001')";>임베디드센터연구소</a></li></ul></li></ul>		<div class="elementor-text-editor elementor-clearfix"><p></p></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-170f397 elementor-widget elementor-widget-spacer" data-id="170f397" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-944f63a elementor-widget elementor-widget-spacer" data-id="944f63a" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-9ce544a" data-id="9ce544a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-02ba05b elementor-widget elementor-widget-html" data-id="02ba05b" data-element_type="widget" data-settings="{&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="iframe-container">
    <iframe name="mainViewFrame" id="main_view_frame" frameborder="0" src="" >
            <p>Your browser does not support iframes.</p>
        </iframe>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4260221 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4260221" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2bfd3e2" data-id="2bfd3e2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-94848a9 elementor-widget elementor-widget-html" data-id="94848a9" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<a id ="svsort1"></a>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-6a7e93a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6a7e93a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-70bd07e" data-id="70bd07e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1fe170d elementor-widget elementor-widget-html" data-id="1fe170d" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<a id ="svsort1"></a>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		
	
</div>

</article>

				
			</div><!-- #content -->

			
		</div><!-- #primary -->

		
	</div><!-- #content-wrap -->

	

	</main><!-- #main -->

	
	
	
		
	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a id="scroll-top" class="scroll-top-right" href="#"><span class="fa fa-angle-up" aria-label="Scroll to the top of the page"></span></a>




<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.2' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"97cb914f92","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":9,"title":"menu%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
</body>
</html>

<!-- Dynamic page generated in 0.131 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-06 13:24:49 -->
