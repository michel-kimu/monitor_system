<?php die(); ?><!DOCTYPE html>
<html class="html" lang="ko-KR">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>scc_survey_2st &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-12819-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-12819.css?ver=1626077817' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/12819" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/scc_survey_2st/" />
<link rel='shortlink' href='http://hyodolms.com/?p=12819' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fscc_survey_2st%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fscc_survey_2st%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style></head>

<body class="page-template page-template-elementor_header_footer page page-id-12819 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-template-full-width elementor-kit-10 elementor-page elementor-page-12819" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
			
			<main id="main" class="site-main clr"  role="main">

				<script>var firstSurveyArray = {"id":"138759","name":"\ub098\ucc44\ub780","phone_num":"01045035305","reg_date":"2022-01-18 06:06:04"};</script><script>var secondSurveyArray = {"id":"138759","name":"\ub098\ucc44\ub780","phone_num":"01045035305","reg_date":"2022-01-18 06:06:04"};</script>		<div data-elementor-type="wp-page" data-elementor-id="12819" class="elementor elementor-12819" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-5f02a29 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5f02a29" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-54cca1f" data-id="54cca1f" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-972b26f elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="972b26f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-06153c5" data-id="06153c5" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-0586c72" data-id="0586c72" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-eafe11d elementor-widget elementor-widget-spacer" data-id="eafe11d" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-d956826 elementor-widget elementor-widget-heading" data-id="d956826" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-large">부모사랑 효돌 사용 후 설문</h1>		</div>
				</div>
				<div class="elementor-element elementor-element-8c43b84 elementor-widget elementor-widget-html" data-id="8c43b84" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="score_table">
  <colgroup>
    <col width="80%" />
    <col width="10%" />
     <col width="10%" />
  </colgroup>
 
    
   <tbody>
        <tr>
            <td class='att_txt'>
                <div id='att_title'>-
                </div>
            </td>
            
            <td style="line-height:24px; text-align: center; font-size:16px; font-weight:bold;">
               <label> <input type="radio" id="rdo_possible" name="rdo_possible"  checked="checked" onclick="elementVisible(false)" /> 불가능</label>
            </td>
            
             <td style="line-height:24px;text-align: center; font-size:16px; font-weight:bold;">
                <label> <input type="radio" id="rdo_possible" name="rdo_possible"  onclick="elementVisible(true)" /> 가능</label>
               
            </td>
        </tr>
   </tbody>
</table>


        		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-8ce3473 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="8ce3473" data-element_type="section" id="person_info">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-79c4e0d" data-id="79c4e0d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2dc01f6 elementor-widget elementor-widget-heading" data-id="2dc01f6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h3 class="elementor-heading-title elementor-size-default">▎개인정보</h3>		</div>
				</div>
				<div class="elementor-element elementor-element-9567054 elementor-widget elementor-widget-html" data-id="9567054" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="basic_table center" style="width: 100%;">
    <tbody>
        <tr>
            <td class="title" style="width: 20%; vertical-align: middle;"><strong>이름</strong></td>
            <td style="width: 30%;">
                <input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%;"
                    id="user_name2" type="text" value="-" disabled>
            </td>
            <td class="title" style="width: 20%; vertical-align: middle;"><strong>작성일자</strong></td>
            <td style="width: 30%;">
                <input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%;"
                    id="today2" type="text" value="-" disabled>
            </td>
        </tr>
        <tr>
            <td class="title" style="vertical-align: middle;"><strong>전화번호</strong></td>
            <td style="vertical-align: middle;">
                <input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%; "
                    id="user_phone2" type="text" value="-" disabled>
            </td>
            <td class="title"  style="vertical-align: middle;"><strong>인형성별</strong></td>
            <td style="line-height:24px;">
                <label> <input type="radio" class="chkValue" name="toy_type" id="toy_type1" checked="checked" /> 남아</label>
                <br>
                <label> <input type="radio" class="chkValue" name="toy_type" id="toy_type2"/> 여아</label>
            </td>
        </tr>
    </tbody>
</table>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-07a6f73 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="07a6f73" data-element_type="section" id="depression_info">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-7efb179" data-id="7efb179" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1f876aa elementor-widget elementor-widget-heading" data-id="1f876aa" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h3 class="elementor-heading-title elementor-size-default">▎시니어 우울척도</h3>		</div>
				</div>
				<div class="elementor-element elementor-element-9bc1a42 elementor-widget elementor-widget-heading" data-id="9bc1a42" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">지난 일주일간(오늘을 포함하여) 당신이 느껴 온 기분 상태를 응답해 주시기 바랍니다. </h6>		</div>
				</div>
				<div class="elementor-element elementor-element-170bdd2 elementor-widget elementor-widget-html" data-id="170bdd2" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="basic_table center">

    <colgroup>
        <col width="5%" />
        <col width="65%" />
        <col width="15%" />
        <col width="15%" />
    </colgroup>
    <thead>
        <tr>
            <th scope="col">번호</th>
            <th scope="col">문항</th>
            <th scope="col">예</th>
            <th scope="col">아니오</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class='idnum'>1</td>
            <td>현재의 생활에 대체적으로 만족하십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_1" id="sgds_after_q1_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_1" id="sgds_after_q1_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>2</td>
            <td> 요즈음 들어 활동량이나 의욕이 많이 떨어지셨습니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_2" id="sgds_after_q2_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_2" id="sgds_after_q2_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>3</td>
            <td> 자신이 헛되이 살고 있다고 느끼십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_3" id="sgds_after_q3_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_3" id="sgds_after_q3_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>4</td>
            <td>생활이 지루하게 느껴질 때가 많습니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_4" id="sgds_after_q4_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_4" id="sgds_after_q4_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>5</td>
            <td>평소에 기분은 상쾌한 편이십니까? </td>
            <td class='yes_'><input type="radio" name="rdo_after_q_5" id="sgds_after_q5_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_5" id="sgds_after_q5_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>6</td>
            <td> 자신에게 불길한 일이 닥칠 것 같아 불안하십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_6" id="sgds_after_q6_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_6" id="sgds_after_q6_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>7</td>
            <td>대체로 마음이 즐거운 편이십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_7" id="sgds_after_q7_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_7" id="sgds_after_q7_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>8</td>
            <td>절망적이라는 느낌이 자주 드십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_8" id="sgds_after_q8_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_8" id="sgds_after_q8_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>9</td>
            <td>바깥에 나가기가 싫고 집에만 있고 싶습니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_9" id="sgds_after_q9_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_9" id="sgds_after_q9_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>10</td>
            <td> 비슷한 나이의 다른 노인들보다 기억력이 더 나쁘다고 느끼 십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_10" id="sgds_after_q10_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_10" id="sgds_after_q10_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>11</td>
            <td> 현재 살아 있다는 것이 즐겁게 생각되십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_11" id="sgds_after_q11_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_11" id="sgds_after_q11_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>12</td>
            <td> 지금의 내 자신이 아무 쓸모없는 사람이라고 느끼십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_12" id="sgds_after_q12_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_12" id="sgds_after_q12_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>13</td>
            <td> 기력이 좋으신 편이십니까? </td>
            <td class='yes_'><input type="radio" name="rdo_after_q_13" id="sgds_after_q13_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_13" id="sgds_after_q13_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>14</td>
            <td>지금 자신의 처지가 아무런 희망도 없다고 느끼십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_14" id="sgds_after_q14_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_14" id="sgds_after_q14_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
        <tr>
            <td class='idnum'>15</td>
            <td> 자신이 다른 사람들의 처지보다 더 못하다고 느끼십니까?</td>
            <td class='yes_'><input type="radio" name="rdo_after_q_15" id="sgds_after_q15_yes" checked="checked" onclick="updateSGDSscore('after')"/></td>
            <td class='no_'><input type="radio" name="rdo_after_q_15" id="sgds_after_q15_no" onclick="updateSGDSscore('after')"/></td>
        </tr>
    </tbody>
</table>
		</div>
				</div>
				<div class="elementor-element elementor-element-e09d02d elementor-widget elementor-widget-html" data-id="e09d02d" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="score_table">
  <colgroup>
    <col width="20%" />
    <col width="40%" />
    <col width="40%" />
  </colgroup>
 
    
   <tbody>
        <tr>
            <td class='score_txt'>점수</td>
            <td><input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%;"
                    id="after_sgds_score" type="text" value="-" disabled></td>
            <td>
                <input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%;"
                    id="after_sgds_rslt" type="text" value="-" disabled> 
            </td>
        </tr>
   </tbody>
</table>
        		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-b5f4649 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b5f4649" data-element_type="section" id="life_info">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-0b226aa" data-id="0b226aa" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-79db2b1 elementor-widget elementor-widget-heading" data-id="79db2b1" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h3 class="elementor-heading-title elementor-size-default">▎한국 시니어 생활관리 활동</h3>		</div>
				</div>
				<div class="elementor-element elementor-element-ecad2ce elementor-widget elementor-widget-html" data-id="ecad2ce" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="basic_table center">

    <colgroup>
        <col width="5%" />
        <col width="55%" />
        <col width="40%" />

    </colgroup>
    <thead>
        <tr>
            <th scope="col">번호</th>
            <th scope="col">질문</th>
            <th scope="col">평가</th>

        </tr>
    </thead>
    <tbody>
        <tr>
            <td class='idnum'>1</td>
            <td>(기상/취침)어르신께서는 매일 일정한 시간에 기상/취침을 하고 계십니까?</td>

            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife1_1" name="rdo_slife1" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 규칙적
                </label>
                <br>
                <label> <input type="radio" id="rdo_slife1_2" name="rdo_slife1" onclick="updateSeniorScore('after')" />
                    때에 따라 </label>
                <br>
                <label> <input type="radio" id="rdo_slife1_3" name="rdo_slife1" onclick="updateSeniorScore('after')" />
                    일정 하지 않음 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>2</td>
            <td> (환기)어르신께서는 매일 환기를 하고 계십니까?</td>
            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife2_1" name="rdo_slife2" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 규칙적 </label>
                <br>
                <label> <input type="radio" id="rdo_slife2_2" name="rdo_slife2" onclick="updateSeniorScore('after')" />
                    가끔 필요시 </label>
                <br>
                <label> <input type="radio" id="rdo_slife2_3" name="rdo_slife2" onclick="updateSeniorScore('after')" />
                    거의 하지 않음 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>3</td>
            <td>(약 먹기)어르신께서는 매일 정확한 시간에 약을 복용하고 계십니까?</td>
            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife3_1" name="rdo_slife3" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 정확한 시간에 약을 복용하고 있음 </label>
                <br>
                <label> <input type="radio" id="rdo_slife3_2" name="rdo_slife3" onclick="updateSeniorScore('after')" />
                    가끔 약 먹는 것을 잊을 때가 있음 </label>
                <br>
                <label> <input type="radio" id="rdo_slife3_3" name="rdo_slife3" onclick="updateSeniorScore('after')" />
                    거의 매번 약 먹는 것을 잊음 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>4</td>
            <td>(식사)어르신께서는 매일 규칙적으로 세끼 식사를 하십니까?</td>
            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife4_1" name="rdo_slife4" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 규칙적 세끼 식사하고 있음 </label>
                <br>
                <label> <input type="radio" id="rdo_slife4_2" name="rdo_slife4" onclick="updateSeniorScore('after')" />
                    가끔 식사시간 놓침 </label>
                <br>
                <label> <input type="radio" id="rdo_slife4_3" name="rdo_slife4" onclick="updateSeniorScore('after')" />
                    거의 매번 식사시간 놓침 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>5</td>
            <td>(산책)어르신께서는 산책을 얼마나 자주 하십니까? </td>

            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife5_1" name="rdo_slife5" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 규칙적 </label>
                <br>
                <label> <input type="radio" id="rdo_slife5_2" name="rdo_slife5" onclick="updateSeniorScore('after')" />
                    가끔 필요시 </label>
                <br>
                <label> <input type="radio" id="rdo_slife5_3" name="rdo_slife5" onclick="updateSeniorScore('after')" />
                    거의 하지 않음 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>6</td>
            <td>(체조)어르신께서는 체조를 얼마나 자주 하십니까? (* 실내 운동도 포함)</td>
            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife6_1" name="rdo_slife6" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 규칙적 </label>
                <br>
                <label> <input type="radio" id="rdo_slife6_2" name="rdo_slife6" onclick="updateSeniorScore('after')" />
                    가끔 필요시 </label>
                <br>
                <label> <input type="radio" id="rdo_slife6_3" name="rdo_slife6" onclick="updateSeniorScore('after')" />
                    거의 하지 않음 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>7</td>
            <td>(긍정적사고) 어르신께서는 얼마나 자주 긍정적인 생각을 하십니까?</td>
            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife7_1" name="rdo_slife7" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 긍정적 </label>
                <br>
                <label> <input type="radio" id="rdo_slife7_2" name="rdo_slife7" onclick="updateSeniorScore('after')" />
                    가끔 부정적인 생각이 들 때가 있음 </label>
                <br>
                <label> <input type="radio" id="rdo_slife7_3" name="rdo_slife7" onclick="updateSeniorScore('after')" />
                    긍정적인 생각을 거의 하지 않음 </label>
            </td>
        </tr>
        <tr>
            <td class='idnum'>8</td>
            <td>(사회적 관계 맺기) 어르신께서는 얼마나 자주 다른 사람들과 접촉(전화, 만남 등)을 하고 싶은 생각이 드십니까?</td>

            <td style="line-height:24px;">
                <label> <input type="radio" id="rdo_slife8_1" name="rdo_slife8" checked="checked"
                        onclick="updateSeniorScore('after')" /> 매일 다른 사람들과 접촉하고 싶음 </label>
                <br>
                <label> <input type="radio" id="rdo_slife8_2" name="rdo_slife8" onclick="updateSeniorScore('after')" />
                    가끔 다른 사람들과 접촉하고 싶음 </label>
                <br>
                <label> <input type="radio" id="rdo_slife8_3" name="rdo_slife8" onclick="updateSeniorScore('after')" />
                    다른 사람들과 접촉하고 싶지 않음 </label>
            </td>
        </tr>
    </tbody>
</table>		</div>
				</div>
				<div class="elementor-element elementor-element-49da33b elementor-widget elementor-widget-html" data-id="49da33b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="score_table">
  <colgroup>
    <col width="20%" />
    <col width="40%" />
    <col width="40%" />
  </colgroup>
 
    
   <tbody>
        <tr>
            <td class='score_txt'>점수</td>
            <td><input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%;"
                    id="after_senior_score" type="text" value="-" disabled>
                    </td>
            <td>
               <input style="border: 0px solid rgb(0, 0, 0);text-align:center; background-color:white;width:100%;"
                    id="after_senior_rslt" type="text" value="-" disabled>
            </td>
        </tr>
   </tbody>
</table>
        		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-378564a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="378564a" data-element_type="section" id="hyodol_survey">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-8a6d2b6" data-id="8a6d2b6" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-171ac3f elementor-widget elementor-widget-heading" data-id="171ac3f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">1. 효돌(스마트 돌봄) 인형을 지속적으로 사용하실 의향이 있으십니까?</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-eed7ceb elementor-widget elementor-widget-html" data-id="eed7ceb" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="basic_table center">

    <colgroup>
        <col width="50%" />
        <col width="50%" />
    </colgroup>
    <thead>
        <tr>
            <th scope="col">예</th>
            <th scope="col">아니오</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class='yes_'><input type="radio" name="rdo_hyodol_question1" id="hyodol_q_1"
                   checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_question1" id="hyodol_q_2"/></td>
        </tr>
    </tbody>
</table>		</div>
				</div>
				<div class="elementor-element elementor-element-9cc87ec elementor-widget elementor-widget-heading" data-id="9cc87ec" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">2. 인형 사용 후 동의하는 항목에 체크해주세요.</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-d07dc94 elementor-widget elementor-widget-html" data-id="d07dc94" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="basic_table center">

    <colgroup>
        <col width="5%" />
        <col width="65%" />
        <col width="15%" />
        <col width="15%" />
    </colgroup>
    <thead>
        <tr>
            <th scope="col">번호</th>
            <th scope="col">문항</th>
            <th scope="col">예</th>
            <th scope="col">아니오</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class='idnum'>1</td>
            <td>인형이 있어 외롭거나 적적하지 않다</td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q1" id="hq1_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q1" id="hq1_no" /></td>
        </tr>
        <tr>
            <td class='idnum'>2</td>
            <td>인형이 있어서 생활의 활력이 된다</td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q2" id="hq2_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q2" id="hq2_no" /></td>
        </tr>
        <tr>
            <td class='idnum'>3</td>
            <td>전반적으로 인형이 없을 때와 비교하여 생활이 더욱 만족스럽다 </td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q3" id="hq3_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q3" id="hq3_no" /></td>
        </tr>
        <tr>
            <td class='idnum'>4</td>
            <td>인형의 귀에서 나오는 내용이 내 생활에 도움이 된다</td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q4" id="hq4_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q4" id="hq4_no" /></td>
        </tr>
        <tr>
            <td class='idnum'>5</td>
            <td>인형이 있어서 전반적으로 건강한 생활에 도움이 된다 </td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q5" id="hq5_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q5" id="hq5_no" /></td>
        </tr>
        <tr>
            <td class='idnum'>6</td>
            <td>인형이 하는 말을 실천하려고 노력한다</td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q6" id="hq6_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q6" id="hq6_no" /></td>
        </tr>
        <tr>
            <td class='idnum'>7</td>
            <td>인형이 만져 달라고 하면 만져 주려고 한다</td>
            <td class='yes_'><input type="radio" name="rdo_hyodol_q7" id="hq7_yes" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hyodol_q7" id="hq7_no" /></td>
        </tr>

    </tbody>
</table>		</div>
				</div>
				<div class="elementor-element elementor-element-8b585f8 elementor-widget elementor-widget-heading" data-id="8b585f8" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">3. 효돌 인형의 성능에 대한 만족도를 평가하여 주시기 바랍니다. </h4>		</div>
				</div>
				<div class="elementor-element elementor-element-4725203 elementor-widget elementor-widget-html" data-id="4725203" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<table class="basic_table center">

    <colgroup>
        <col width="5%" />
        <col width="50%" />
        <col width="13%" />
        <col width="13%" />
        <col width="13%" />
    </colgroup>
    <thead>
        <tr>
            <th scope="col">번호</th>
            <th scope="col">문항</th>
            <th scope="col">그렇지 않다</th>
            <th scope="col">보통</th>
            <th scope="col">그렇다</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class='idnum'>1</td>
            <td>인형이 사용하기에 편리하다 </td>
            <td class='yes_'><input type="radio" name="rdo_hd_q1" id="hdq1_no" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q1" id="hdq1_normal" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q1" id="hdq1_yes" /></td>
        </tr>
        <tr>
            <td class='idnum'>2</td>
            <td>인형의 생김새/사이즈가 마음에 든다 </td>
            <td class='yes_'><input type="radio" name="rdo_hd_q2" id="hdq2_no" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q2" id="hdq2_normal" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q2" id="hdq2_yes" /></td>
        </tr>
        <tr>
            <td class='idnum'>3</td>
            <td>인형이 말해주는 내용이 맘에 든다 </td>
            <td class='yes_'><input type="radio" name="rdo_hd_q3" id="hdq3_no" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q3" id="hdq3_normal" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q3" id="hdq3_yes" /></td>
        </tr>
        <tr>
            <td class='idnum'>4</td>
            <td>인형이 촉감이 맘에 든다 </td>
            <td class='yes_'><input type="radio" name="rdo_hd_q4" id="hdq4_no" checked="checked" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q4" id="hdq4_normal" /></td>
            <td class='no_'><input type="radio" name="rdo_hd_q4" id="hdq4_yes" /></td>
        </tr>

    </tbody>
</table>		</div>
				</div>
				<div class="elementor-element elementor-element-863cce9 elementor-widget elementor-widget-heading" data-id="863cce9" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title elementor-size-default">4. 효돌 인형이 더욱 좋아졌으면 하는 바는? </h4>		</div>
				</div>
				<div class="elementor-element elementor-element-36651be elementor-widget elementor-widget-html" data-id="36651be" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<textarea style="resize:vertical;width:100%;max-height:200px; min-height:30px" id="hyodol_request"
    placeholder="240글자까지 입력할 수 있습니다" maxlength="240"></textarea>		</div>
				</div>
				<div class="elementor-element elementor-element-f6e68a8 elementor-widget elementor-widget-spacer" data-id="f6e68a8" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-c1ff608 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="c1ff608" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2e0628b" data-id="2e0628b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-f0fb190 elementor-widget elementor-widget-html" data-id="f0fb190" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script type='text/javascript'>
elementVisible(false);

function elementVisible(state_){
    let vis = 'inline'
    if(!state_){
         vis = 'none'
    }
    let elem;
    elem = document.getElementById('person_info'); //개인정보
    elem.style.display = vis;
    elem = document.getElementById('depression_info'); //시니어 우울척도
    elem.style.display = vis;
    elem = document.getElementById('life_info'); //한국 시니어 생활관리 활동
    elem.style.display = vis;
    elem = document.getElementById('hyodol_survey'); //효돌사용도
    elem.style.display = vis;
    
}
</script>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3ad183a" data-id="3ad183a" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c7ee3ba" data-id="c7ee3ba" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-0a97cfe" data-id="0a97cfe" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6a2f054 elementor-widget elementor-widget-html" data-id="6a2f054" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<button class="editBtn" type="button" id="secondInfoSave">저장</button>
 
<script type='text/javascript'>
jQuery( '#secondInfoSave' ).on( 'click', function(){
    
    var afterSgdsScore = '';
    var afterSgdsRslt = '';
    var afterSeniorScore = '';
    var afterSeniorRslt = '';
    
    if((jQuery('#rdo_possible').is(':checked'))){
        afterSgdsScore = '0';
        afterSgdsRslt = '-';
        afterSeniorScore = '0';
        afterSeniorRslt = '-';
    }else{  
        afterSgdsScore = document.getElementById('after_sgds_score').value;
        afterSgdsRslt = document.getElementById('after_sgds_rslt').value;
        afterSeniorScore = document.getElementById('after_senior_score').value;
        afterSeniorRslt = document.getElementById('after_senior_rslt').value;
    }
    
    console.log((jQuery('#rdo_possible').is(':checked'))?0:1);
    console.log(afterSgdsScore);
    console.log(afterSgdsRslt);
    console.log(afterSeniorScore);
    console.log(afterSeniorRslt);
    
    
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'                : 'save_survey_sort_info',
            'doll_id'               : secondSurveyArray['id'],
            'reg_date'              : getMySQLDate("timestamp"),
            'survey_sort'           :2,
            'spouse'                :-1,
            'housing_cleanliness'   :-1,
            'having_children'       :-1,
            'son'                   :-1,
            'daughter'              :-1,
            'meal'                  :-1,
            'public_visit_support'  :-1,
            'taking_medicine'       :-1,
            'doll_gender':(jQuery('#toy_type1').is(':checked'))?0:1,
            'is_survey_possible':(jQuery('#rdo_possible').is(':checked'))?0:1,

            'dp_contents_1':(jQuery('#sgds_after_q1_yes').is(':checked'))?0:1,
            'dp_contents_2':(jQuery('#sgds_after_q2_yes').is(':checked'))?0:1,
            'dp_contents_3':(jQuery('#sgds_after_q3_yes').is(':checked'))?0:1,
            'dp_contents_4':(jQuery('#sgds_after_q4_yes').is(':checked'))?0:1,
            'dp_contents_5':(jQuery('#sgds_after_q5_yes').is(':checked'))?0:1,
            'dp_contents_6':(jQuery('#sgds_after_q6_yes').is(':checked'))?0:1,
            'dp_contents_7':(jQuery('#sgds_after_q7_yes').is(':checked'))?0:1,
            'dp_contents_8':(jQuery('#sgds_after_q8_yes').is(':checked'))?0:1,
            'dp_contents_9':(jQuery('#sgds_after_q9_yes').is(':checked'))?0:1,
            'dp_contents_10':(jQuery('#sgds_after_q10_yes').is(':checked'))?0:1,
            'dp_contents_11':(jQuery('#sgds_after_q11_yes').is(':checked'))?0:1,
            'dp_contents_12':(jQuery('#sgds_after_q12_yes').is(':checked'))?0:1,
            'dp_contents_13':(jQuery('#sgds_after_q13_yes').is(':checked'))?0:1,
            'dp_contents_14':(jQuery('#sgds_after_q14_yes').is(':checked'))?0:1,
            'dp_contents_15':(jQuery('#sgds_after_q15_yes').is(':checked'))?0:1,
            'dp_total_cnt':afterSgdsScore,
            'dp_depression_result':afterSgdsRslt,
            
            'mg_contents_1':getLifeCheckedState('#rdo_slife1'),
            'mg_contents_2':getLifeCheckedState('#rdo_slife2'),
            'mg_contents_3':getLifeCheckedState('#rdo_slife3'),
            'mg_contents_4':getLifeCheckedState('#rdo_slife4'),
            'mg_contents_5':getLifeCheckedState('#rdo_slife5'),
            'mg_contents_6':getLifeCheckedState('#rdo_slife6'),
            'mg_contents_7':getLifeCheckedState('#rdo_slife7'),
            'mg_contents_8':getLifeCheckedState('#rdo_slife8'),
            'mg_total_cnt': afterSeniorScore,
            'mg_life_result':afterSeniorRslt,
            
            'hd_contents_1':(jQuery('#hyodol_q_1').is(':checked'))?0:1,
            
            'hd_contents_2':(jQuery('#hq1_yes').is(':checked'))?0:1,
            'hd_contents_3':(jQuery('#hq2_yes').is(':checked'))?0:1,
            'hd_contents_4':(jQuery('#hq3_yes').is(':checked'))?0:1,
            'hd_contents_5':(jQuery('#hq4_yes').is(':checked'))?0:1,
            'hd_contents_6':(jQuery('#hq5_yes').is(':checked'))?0:1,
            'hd_contents_7':(jQuery('#hq6_yes').is(':checked'))?0:1,
            'hd_contents_8':(jQuery('#hq7_yes').is(':checked'))?0:1,
            
            'hd_contents_9':checkSatisfied(1),
            'hd_contents_10':checkSatisfied(2),
            'hd_contents_11':checkSatisfied(3),
            'hd_contents_12':checkSatisfied(4),
            'hd_request':document.getElementById('hyodol_request').value
        },
        success: function( response ){
           let elem = document.getElementById('secondInfoSave');
           elem.disabled = true;
           swal("저장 완료!", "설문조사의 저장을 완료하였습니다", "success");
        },
        error: function( response,status,error){
           swal("저장 실패", error, "error");
        }
    });
    return false;
});



//한국 시니어 생활관리 활동
function getLifeCheckedState(type_) {
    if(jQuery(type_ + '_1').is(':checked')) return 0;
    else if(jQuery(type_ + '_2').is(':checked')) return 1;
    else return 2;
}
    
//만족도 
function checkSatisfied(no){
    var rslt = 0;
    var vo1 = jQuery('#hdq'+no+'_no').is(':checked');       //그렇지 않다
    var vo2 = jQuery('#hdq'+no+'_normal').is(':checked');   //보통
    var vo3 = jQuery('#hdq'+no+'_yes').is(':checked');      //그렇다
    if(vo1 == true)rslt = 0;
    else if(vo2 == true)rslt = 1;
    else if(vo3 == true)rslt = 2;
    
    return rslt;
}
 
 

//날짜시각취득 20210624111923
function getMySQLDate(dtype) {
    var dt = new Date();
    
    var timestamp = dt.getFullYear()+
    (String(dt.getMonth()+101).substr(1,2))+
    (String(dt.getDate()+100).substr(1,2)+
    (String(dt.getHours()+100).substr(1,2))+
    (String(dt.getMinutes()+100).substr(1,2))+
    (String(dt.getSeconds()+100).substr(1,2)));
   
    if (dtype=="timestamp") return timestamp;
    timestamp.match(/(d{4})(d{2})(d{2})(d{2})(d{2})(d{2})/);
    var datetime = RegExp.$1+'-'+RegExp.$2+'-'+RegExp.$3+
    ' '+RegExp.$4+':'+RegExp.$5+':'+RegExp.$6;

    if (dtype=="datetime") return datetime;
}


/*
//테스트 방법 
//조회
select * from scc_survey_doll_info where doll_id ='133268' ;
select * from scc_survey_depression where doll_id ='133268' ;
select * from scc_survey_life_mgmt where doll_id ='133268' ;
select * from scc_survey_usability where doll_id ='133268' ;

// 삭제
delete from scc_survey_doll_info where doll_id = '133268';
delete from scc_survey_depression where doll_id = '133268';
delete from scc_survey_life_mgmt where doll_id = '133268';

*/
</script>


		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-dce23d7" data-id="dce23d7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dae53eb elementor-widget elementor-widget-html" data-id="dae53eb" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			

<script type='text/javascript'>
    var hdUsabilityArray;

    jQuery(function () {
        if (secondSurveyArray) {
            // console.log('secondSurveyArray:' + secondSurveyArray);
            updateUserInfo(secondSurveyArray, "second");            //사용자 정보 표시
           // updateSeniorDepressionInfo(secondSurveyArray, "after");  //시니어 우울척도
           // updateLifeManagement(secondSurveyArray, "after");        //한국 시니어 생활관리 활동
        }
        updateSGDSscore('after');      //점수표시
        updateSeniorScore('after');    //한국 시니어 생활관리 활동
        if (hdUsabilityArray) {
            updateHyodolUsability(hdUsabilityArray);               //효돌 사용도 조사
        }
    });

    function updateUserInfo(postArray, type_) {
           document.getElementById('att_title').innerHTML = "※ '"+postArray['name'] + "'님의 상태가 정신적 또는 육체적으로 설문조사가 가능한 상태인가요?";
 
            document.getElementById('user_name2').value = postArray['name']; //이름
            document.getElementById('user_phone2').value = phoneFormatter(postArray['phone_num']); //전화번호

            //작성일자
            if (typeof postArray['reg_date'] !== 'undefined') {
                var d = postArray['reg_date'];
                d = d.split(' ');
                document.getElementById('today2').value = d[0]; //년월일만 취득
            } else {
                document.getElementById('today2').value = getToday();
            }

            //인형성별
            if (typeof postArray['doll_gender'] !== 'undefined') {
                switch (postArray['doll_gender']) {
                    case '0':
                        document.getElementById("toy_type1").checked = true;
                        break;
                    case '1':
                        document.getElementById("toy_type2").checked = true;
                        break;
                }
            }
    }

    //시니어 우울척도
    function updateSeniorDepressionInfo(postArray, type_) {
/*
        for (let i = 1; i < 16; i++) {
            let namae = 'dp_contents_' + i;
            if (typeof postArray[namae] !== 'undefined') {
                //console.log('>'+namae+ ' , ' +postArray[namae] );
                switch (postArray[namae]) {
                    case '0':
                        // console.log("sgds_" + type_ + "_q" + i + "_yes");
                        document.getElementById("sgds_" + type_ + "_q" + i + "_yes").checked = true;
                        break;
                    case '1':
                        // console.log("sgds_" + type_ + "_q" + i + "_no");
                        document.getElementById("sgds_" + type_ + "_q" + i + "_no").checked = true;
                        break;
                }
            }
        }

        updateSGDSscore(type_); //점수표시
        */
    }

    //한국 시니어 생활관리 활동
    function updateLifeManagement(postArray, type_) {
        /*
        for (let i = 1; i < 9; i++) {
            let namae = 'mg_contents_' + i;
            if (typeof postArray[namae] !== 'undefined') {
                document.getElementById("senior_" + type_ + "_q" + i).selectedIndex = postArray[namae];
                // console.log("senior_" + type_ + "_q" + i);
            }
        }

        updateSeniorScore(type_);//점수표시
        */
    }

    //효돌 사용도 조사
    function updateHyodolUsability(postArray) {
        // console.log(postArray['continuous_use']);
        if (typeof postArray['continuous_use'] !== 'undefined') {
            switch (postArray['continuous_use']) {
                case '0':
                    document.getElementById("hyodol_q_1").checked = true;
                    break;
                case '1':
                    document.getElementById("hyodol_q_2").checked = true;
                    break;
            }
        }

        for (let i = 1; i < 8; i++) {
            let namae = 'contents_2_' + i;
            if (typeof postArray[namae] !== 'undefined') {
                //console.log('>'+namae+ ' , ' +postArray[namae] );
                switch (postArray[namae]) {
                    case '0':
                        document.getElementById("hq" + i + "_yes").checked = true;
                        break;
                    case '1':
                        document.getElementById("hq" + i + "_no").checked = true;
                        break;
                }
            }
        }

        for (let i = 1; i < 5; i++) {
            let namae = 'contents_3_' + i;
            if (typeof postArray[namae] !== 'undefined') {
                //console.log('>'+namae+ ' , ' +postArray[namae] );
                switch (postArray[namae]) {
                    case '0':
                        document.getElementById("hdq" + i + "_no").checked = true;
                        break;
                    case '1':
                        document.getElementById("hdq" + i + "_normal").checked = true;
                        break;
                    case '2':
                        document.getElementById("hdq" + i + "_yes").checked = true;
                        break;
                }
            }
        }

        if (typeof postArray['improvements'] !== 'undefined') {
            document.getElementById("hyodol_request").value = postArray['improvements'];
        }

    }

    //시니어 우울척도 점수표시
    function updateSGDSscore(type_) {
        let scores = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

        scores[0] = (jQuery('#sgds_' + type_ + '_q1_yes').is(':checked')) ? 0 : 1;
        scores[1] = (jQuery('#sgds_' + type_ + '_q2_yes').is(':checked')) ? 1 : 0;
        scores[2] = (jQuery('#sgds_' + type_ + '_q3_yes').is(':checked')) ? 1 : 0;
        scores[3] = (jQuery('#sgds_' + type_ + '_q4_yes').is(':checked')) ? 1 : 0;
        scores[4] = (jQuery('#sgds_' + type_ + '_q5_yes').is(':checked')) ? 0 : 1;
        scores[5] = (jQuery('#sgds_' + type_ + '_q6_yes').is(':checked')) ? 1 : 0;
        scores[6] = (jQuery('#sgds_' + type_ + '_q7_yes').is(':checked')) ? 0 : 1;
        scores[7] = (jQuery('#sgds_' + type_ + '_q8_yes').is(':checked')) ? 1 : 0;
        scores[8] = (jQuery('#sgds_' + type_ + '_q9_yes').is(':checked')) ? 1 : 0;
        scores[9] = (jQuery('#sgds_' + type_ + '_q10_yes').is(':checked')) ? 1 : 0;
        scores[10] = (jQuery('#sgds_' + type_ + '_q11_yes').is(':checked')) ? 0 : 1;
        scores[11] = (jQuery('#sgds_' + type_ + '_q12_yes').is(':checked')) ? 1 : 0;
        scores[12] = (jQuery('#sgds_' + type_ + '_q13_yes').is(':checked')) ? 0 : 1;
        scores[13] = (jQuery('#sgds_' + type_ + '_q14_yes').is(':checked')) ? 1 : 0;
        scores[14] = (jQuery('#sgds_' + type_ + '_q15_yes').is(':checked')) ? 1 : 0;

        var sum = 0;
        for (let i = 0; i < scores.length; i++) {
            sum += scores[i];
        }

        var elem = document.getElementById(type_ + '_sgds_score');
        elem.value = (sum + " 점");
        elem.style.color = 'red';
        elem.style.fontWeight = 'bold';

        elem = document.getElementById(type_ + '_sgds_rslt');
        if (sum >= 11) {
            elem.value = "고위험군";
            elem.style.color = 'red';
        } else {
            elem.value = "보통";
            elem.style.color = 'blue';
        }
        elem.style.fontWeight = 'bold';
    }

    //한국 시니어 생활관리 활동 
    function updateSeniorScore(type_) {
        let scores = [0, 0, 0, 0, 0, 0, 0, 0];
        type__ = '#rdo_slife';
        scores[0] = getSelectedScore(type__, 1);
        scores[1] = getSelectedScore(type__, 2);
        scores[2] = getSelectedScore(type__, 3);;
        scores[3] = getSelectedScore(type__, 4);;
        scores[4] = getSelectedScore(type__, 5);;
        scores[5] = getSelectedScore(type__, 6);;
        scores[6] = getSelectedScore(type__, 7);;
        scores[7] = getSelectedScore(type__, 8);;
 
        console.log('scores:' + scores);

        var sum = 0;
        for (let i = 0; i < scores.length; i++) {
            sum += scores[i];
        }

        var elem = document.getElementById(type_ + '_senior_score');
        elem.value = (sum + " 점");
        elem.style.color = 'red';
        elem.style.fontWeight = 'bold';

        elem = document.getElementById(type_ + '_senior_rslt');
        if (sum < 11) {
            elem.value = "관리필요";
            elem.style.color = 'red';
        } else if (sum >= 11 && sum <= 17) {
            elem.value = "보통";
            elem.style.color = 'blue';
        } else {
            elem.value = "양호";
            elem.style.color = 'blue';
        }
        elem.style.fontWeight = 'bold';

    }

    //rdo_slife1_1
    function getSelectedScore(type_, id_) {
        var elemName = type_ + id_;
        if(jQuery(elemName + '_1').is(':checked')) return 3;
        else if(jQuery(elemName + '_2').is(':checked')) return 2;
        else return 1;
        
        
        /* 풀다운메뉴용  
        
        let tmp = document.getElementById('senior_' + type_ + '_q' + id_).selectedIndex;
        if (tmp == 0) return 3;
        else if (tmp == 1) return 2;
        else return 1;*/
    }







    function getToday() {
        let today = new Date();
        let year = today.getFullYear(); // 년도
        let month = today.getMonth() + 1;  // 월
        let date = today.getDate();  // 날짜
        let day = today.getDay();  // 요일
        let tmp = year + '-' + month + '-' + date

        return tmp
    }

    /*
    전화번호 포맷 변경
    */
    function phoneFormatter(num, type) {
        var formatNum = '';
        try {
            if (num.length == 11) {
                if (type == 0) {
                    formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
                } else {
                    formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
                }
            } else if (num.length == 8) {
                formatNum = num.replace(/(\d{4})(\d{4})/, '$1-$2');
            } else {
                if (num.indexOf('02') == 0) {
                    if (type == 0) {
                        formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
                    } else {
                        formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
                    }
                } else {
                    if (type == 0) {
                        formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
                    } else {
                        formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
                    }
                }
            }
        } catch (e) {
            formatNum = num;
            console.log(e);
        }
        return formatNum;
    }
</script>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-33932d0 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="33932d0" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ee7b7a0" data-id="ee7b7a0" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-afbcf4e elementor-widget elementor-widget-spacer" data-id="afbcf4e" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		
	</main><!-- #main -->

	
	
	
		
	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a id="scroll-top" class="scroll-top-right" href="#"><span class="fa fa-angle-up" aria-label="Scroll to the top of the page"></span></a>




<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":12819,"title":"scc_survey_2st%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
</body>
</html>

<!-- Dynamic page generated in 0.147 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 15:06:04 -->
