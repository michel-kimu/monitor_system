<?php die(); ?><!DOCTYPE html>
<html class="html" lang="ko-KR">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>user_info &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-3701-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-3701.css?ver=1642486008' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/3701" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/user_info/" />
<link rel='shortlink' href='http://hyodolms.com/?p=3701' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_info%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_info%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style></head>

<body class="page-template-default page page-id-3701 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-kit-10 elementor-page elementor-page-3701" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
			
			<main id="main" class="site-main clr"  role="main">

				
	
	<div id="content-wrap" class="container clr">

		
		<div id="primary" class="content-area clr">

			
			<div id="content" class="site-content clr">

				
				
<article class="single-page-article clr">

	
<div class="entry clr" itemprop="text">

	
	<script>var postArray = {"id":"125351","host_user_id":"96","name":"\uc815\uc6a9\uc5fd 239","phone_num":"01045145964","battery":"5","active_monitor":"48","sex":"2","bday":"1940-04-07","calender":"1","religion":"2","wakeup":"05:00:00","breakfast":"07:00:00","lunch":"12:00:00","dinner":"18:00:00","sleep":"22:00:00","drug_option":"0000000","ventilation_walk":"3","is_edited":"1","activeSenceTime":"48","pic_file_name":"v2data\/bfab3ab4e8094579aabf5bf9177ea2e46078591253944685779.jpg","is_delete":"0","mac_id":"8982300618000141033F","regdate":"2019-04-10 12:55:28","connection_type":"1","serial_number":"02N190200239","charms_mode":"1","no_alarm":"1","religion_alarm":"1","custom_timer1":"","custom_timer2":"","custom_timer3":"","custom_timer4":"","custom_timer5":"","appellation":"10000","disease":"000","left_ear_function":"0000010","right_ear_function":"0000001","is_active_detect":"0","ams_service_enable":null,"ams_surgery_date":null,"ams_morning_timer":null,"ams_afternoon_timer":null,"ems_service_enable":null,"ems_morning_timer":null,"ems_afternoon_timer":null,"wms_workout_timer_enable":null,"wms_personal_workout":null,"wms_workout_timer1":null,"wms_workout_timer2":null,"wms_workout_timer3":null,"wms_workout_timer4":null,"wms_workout_timer5":null,"sdfv_firm_version":null,"ssbs_ache_service":null,"ssbs_emotion_service":null};</script>		<div data-elementor-type="wp-page" data-elementor-id="3701" class="elementor elementor-3701" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-5652d59 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="5652d59" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a6442cb" data-id="a6442cb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-02051bb elementor-widget elementor-widget-heading" data-id="02051bb" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎개인 정보</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-2e7cc97 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="2e7cc97" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-45ab59f" data-id="45ab59f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dd31076 elementor-widget elementor-widget-html" data-id="dd31076" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>이름</p>
    </div>
    
    <input class="panel_text_type" id="user_name" type="text" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-24d99b5 elementor-widget elementor-widget-html" data-id="24d99b5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>생년월일</p>
    </div>
    
    <input class="panel_text_type" id="user_birthday" type="date" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-d47b6d5" data-id="d47b6d5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-f936131 elementor-widget elementor-widget-html" data-id="f936131" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>성별</p>
    </div>
    
    <select class="panel_text_type" id='sex'>
     <option value = '남'>남</option>
     <option value = '여'>여</option>
    </select>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-d33a135 elementor-widget elementor-widget-html" data-id="d33a135" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>양력/음력</p>
    </div>
    
    <select class="panel_text_type" id='calender_type'>
     <option value = '양력'>양력</option>
     <option value = '음력'>음력</option>
    </select>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-8552a2e" data-id="8552a2e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a5a9d07 elementor-widget elementor-widget-html" data-id="a5a9d07" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교</p>
    </div>
    
   <select class="panel_text_type" id='user_religion'>
       <option>개신교</option>
       <option>불교</option>
       <option>무교</option>
       <option>천주교</option>
    </select>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-08704e4 elementor-widget elementor-widget-html" data-id="08704e4" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>전화번호</p>
    </div>
    
    <input class="panel_text_type" id="user_phone" type="text" value="-">
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-7867b06 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="7867b06" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-5a73889" data-id="5a73889" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-ab63dd1" data-id="ab63dd1" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-eb5d6a3" data-id="eb5d6a3" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-eb50c95" data-id="eb50c95" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-55d3b4a elementor-widget elementor-widget-html" data-id="55d3b4a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<button class="editBtn" type="button" id="userInfoEdit">수정</button>
 
<script type='text/javascript'>
jQuery( '#userInfoEdit' ).on( 'click', function(){
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action' : 'person_info_edit',
            'doll_id': postArray['id'],
            'name'   : document.getElementById('user_name').value,
            'sex'    :(document.getElementById('sex').value=='남')?1:2,
            'birthday':document.getElementById('user_birthday').value,
            'calender':(document.getElementById('calender_type').value=='음력')?1:0,
            'religion':checkReligion(document.getElementById('user_religion').value),
            'phone_num':replacePhoneNumber(document.getElementById('user_phone').value)
        },
        success: function( response ){
            //var obj =JSON.parse(response); //문자열을 JSON으로 분해
            //updateUserInfo(obj);
            //swal('수정 완료');
           swal("수정 완료", "개인정보의 수정을 완료하였습니다", "success");
        },
        error: function( response,status,error){
            swal("수정 실패", error, "error");
        }
    });
    return false;
});

/*
전화번호에서 숫자 이외의 문자를 삭제
*/
function replacePhoneNumber(tel_){
    var tel = (tel_).replace(/[^0-9]/g, '');
    return tel
}


function checkReligion(var_){
    switch(var_){
        case '천주교':
            return 4;
            break;
        case '기독교':
            return 1;
            break;
        case '불교':
            return 2;
            break;
        case '무교':
            return 3;
            break;            
    }
}

</script>



		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-403a77f elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="403a77f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a730a96" data-id="a730a96" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3c5c4bf elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="3c5c4bf" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-d952f1e elementor-widget elementor-widget-heading" data-id="d952f1e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎인형 정보</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-728efa0 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="728efa0" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-23af69f" data-id="23af69f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-248b00e elementor-widget elementor-widget-html" data-id="248b00e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>인형 ID</p>
    </div>
    
    <input class="panel_text_type_dim" id="dollId" type="text" value="-" disabled >
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3af2e87" data-id="3af2e87" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a6c46b7 elementor-widget elementor-widget-html" data-id="a6c46b7" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>베터리잔량</p>
    </div>
    
    <input class="panel_text_type_dim" id="battery" type="text" value="-" disabled >
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-a507407" data-id="a507407" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d442f1a elementor-widget elementor-widget-html" data-id="d442f1a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>상태</p>
    </div>
    
    <input class="panel_text_type_dim" id="states" type="text" value="-" disabled >
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-b9da8dc elementor-widget elementor-widget-spacer" data-id="b9da8dc" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-763e9b5 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="763e9b5" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-421a1bd elementor-widget elementor-widget-heading" data-id="421a1bd" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎알람</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-d2ac03a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="d2ac03a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-881e763" data-id="881e763" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6618c87 elementor-widget elementor-widget-html" data-id="6618c87" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>약복용기준정보</p>
   
      
  <input type='checkbox' id='drugCheckbox1'><label>아침식전</label> &nbsp;&nbsp;
  <input type='checkbox' id='drugCheckbox2'><label>아침식후</label> &nbsp;&nbsp;
  <input type='checkbox' id='drugCheckbox3'><label>점심식전</label> &nbsp;&nbsp;
  <input type='checkbox' id='drugCheckbox4'><label>점심식후</label>&nbsp;&nbsp;
  <input type='checkbox' id='drugCheckbox5'><label>저녁식전</label> &nbsp;&nbsp;
  <input type='checkbox' id='drugCheckbox6'><label>저녁식후</label>&nbsp;&nbsp;
  <input type='checkbox' id='drugCheckbox7'><label>취침전 </label> 
 </div>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-db483b3 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="db483b3" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4fcfe56" data-id="4fcfe56" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-7269dbc elementor-widget elementor-widget-html" data-id="7269dbc" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>기상시간</p>
    </div>
    
    <input class="panel_text_type" id="wakeup" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-16689a5 elementor-widget elementor-widget-html" data-id="16689a5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>저녁시간</p>
    </div>
    
    <input class="panel_text_type" id="dinner" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-1bf7f2f elementor-widget elementor-widget-html" data-id="1bf7f2f" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>환기/산책</p>
    
    
  <input type='checkbox' id='v_walk1'><label>환기</label> &nbsp;&nbsp;
  <input type='checkbox' id='v_walk2'><label>산책</label>
  </div>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-9bb7f32 elementor-widget elementor-widget-html" data-id="9bb7f32" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>활동감지시간</p>
    </div>

    <select class="panel_text_type" id="activetime">
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                          <option>5</option>
                          <option>6</option>
                          <option>7</option>
                          <option>8</option>
                          <option>9</option>
                          <option>10</option>
                          <option>11</option>
                          <option>12</option>
                          <option>13</option>
                          <option>14</option>
                          <option>15</option>
                          <option>16</option>
                          <option>17</option>
                          <option>18</option>
                          <option>19</option>
                          <option>20</option>
                          <option>21</option>
                          <option>22</option>
                          <option>23</option>
                          <option>24</option>
                          <option>25</option>
                          <option>26</option>
                          <option>27</option>
                          <option>28</option>
                          <option>29</option>
                          <option>30</option>
                          <option>31</option>
                          <option>32</option>
                          <option>33</option>
                          <option>34</option>
                          <option>35</option>
                          <option>36</option>
                          <option>37</option>
                          <option>38</option>
                          <option>39</option>
                          <option>40</option>
                          <option>41</option>
                          <option>42</option>
                          <option>43</option>
                          <option>44</option>
                          <option>45</option>
                          <option>46</option>
                          <option>47</option>
                          <option>48</option>
                        </select>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-e0ea56c elementor-widget elementor-widget-html" data-id="e0ea56c" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>방해금지모드</p>
    </div>
    
    <select class="panel_text_type" id='no_alarm'>
     <option>해제</option>
     <option>설정</option>
    </select>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7861c60" data-id="7861c60" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-99038a0 elementor-widget elementor-widget-html" data-id="99038a0" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>아침시간</p>
    </div>
    
    <input class="panel_text_type" id="breakfast" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-3fbfa1b elementor-widget elementor-widget-html" data-id="3fbfa1b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>취침시간</p>
    </div>
    
    <input class="panel_text_type" id="sleep" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-fdf93cb" data-id="fdf93cb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5fb7c73 elementor-widget elementor-widget-html" data-id="5fb7c73" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>점심시간</p>
    </div>
    
    <input class="panel_text_type" id="lunch" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-b74c771 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b74c771" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-c511283" data-id="c511283" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0fa9473 elementor-widget elementor-widget-html" data-id="0fa9473" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교말씀 타이머</p>
    </div>
    
    <select class="panel_text_type" id='religion_alarm'>
     <option>해제</option>
     <option>설정</option>
    </select>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-ed37de4 elementor-widget elementor-widget-html" data-id="ed37de4" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교말씀시간 3</p>
    </div>
    
    <input class="panel_text_type" id="custom_timer3" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-be8992e elementor-widget elementor-widget-html" data-id="be8992e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>호칭</p>
    </div>
    
    <select class="panel_text_type" id='appellation'>
     <option>할머니/할아버지</option>
     <option>어머니/아버지</option>
     <option>엄마/아빠</option>
    </select>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-d9d0ad1" data-id="d9d0ad1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-26c6f8a elementor-widget elementor-widget-html" data-id="26c6f8a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교말씀시간 1</p>
    </div>
    
    <input class="panel_text_type" id="custom_timer1" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-7382692 elementor-widget elementor-widget-html" data-id="7382692" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교말씀시간 4</p>
    </div>
    
    <input class="panel_text_type" id="custom_timer4" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-bf51219" data-id="bf51219" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0214935 elementor-widget elementor-widget-html" data-id="0214935" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교말씀시간 2</p>
    </div>
    
    <input class="panel_text_type" id="custom_timer2" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-764ebf5 elementor-widget elementor-widget-html" data-id="764ebf5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>종교말씀시간 5</p>
    </div>
    
    <input class="panel_text_type" id="custom_timer5" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-ada0c26 elementor-widget elementor-widget-spacer" data-id="ada0c26" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-5315e04 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="5315e04" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-22cfc50" data-id="22cfc50" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b0bc0f0 elementor-widget elementor-widget-html" data-id="b0bc0f0" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>질병</p>
    
    <div id="disease_digit3">
      <input type='checkbox' id='v_disease1'><label>고혈압</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease2'><label>고지혈증</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease3'><label>당뇨병</label>
    </div>
    
    <div id="disease_digit10">
      <input type='checkbox' id='v_disease11'><label>고혈압</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease12'><label>고지혈증</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease13'><label>당뇨병</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease14'><label>천식(호흡기계)</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease15'><label>알레르기</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease16'><label>무릎(퇴행성 관절염)</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease17'><label>허리(퇴행성 관절염)</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease18'><label>고관절(퇴행성 관절염)</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease19'><label>흡연</label> &nbsp;&nbsp;
      <input type='checkbox' id='v_disease20'><label>음주</label> &nbsp;&nbsp;
    </div>
    
  </div>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-ae93f48 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ae93f48" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-b4682f2" data-id="b4682f2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-256d5e7 elementor-widget elementor-widget-html" data-id="256d5e7" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>왼쪽 귀</p>
   
    <div id="left_digit7">
      <input type='checkbox' id='left_year1'><label>회상놀이</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year2'><label>영어교실</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year3'><label>음악</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year4'><label>종교말씀</label>&nbsp;&nbsp;
      <input type='checkbox' id='left_year5'><label>이야기</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year6'><label>퀴즈</label>&nbsp;&nbsp;
      <input type='checkbox' id='left_year7'><label>체조</label> 
    </div> 
    <div id="left_digit9">
      <input type='checkbox' id='left_year11'><label>영어교실</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year12'><label>이야기</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year13'><label>퀴즈</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year14'><label>종교말씀</label>&nbsp;&nbsp;
      <input type='checkbox' id='left_year15'><label>종교음악</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year16'><label>클래식</label>&nbsp;&nbsp;
      <input type='checkbox' id='left_year17'><label>트로트</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year18'><label>회상놀이</label> &nbsp;&nbsp;
      <input type='checkbox' id='left_year19'><label>체조</label>
    </div> 
 </div>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-78a7a41 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="78a7a41" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-d97dd30" data-id="d97dd30" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-05e6b94 elementor-widget elementor-widget-html" data-id="05e6b94" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>오른쪽 귀</p>
   
    <div id="right_digit7">
      <input type='checkbox' id='right_year1'><label>회상놀이</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year2'><label>영어교실</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year3'><label>음악</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year4'><label>종교말씀</label>&nbsp;&nbsp;
      <input type='checkbox' id='right_year5'><label>이야기</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year6'><label>퀴즈</label>&nbsp;&nbsp;
      <input type='checkbox' id='right_year7'><label>체조 </label> 
    </div>
    <div id="right_digit9">
      <input type='checkbox' id='right_year11'><label>영어교실</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year12'><label>이야기</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year13'><label>퀴즈</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year14'><label>종교말씀</label>&nbsp;&nbsp;
      <input type='checkbox' id='right_year15'><label>종교음악</label> &nbsp;&nbsp;
      <input type='checkbox' id='right_year16'><label>클래식</label>&nbsp;&nbsp;
      <input type='checkbox' id='right_year17'><label>트로트 </label>&nbsp;&nbsp;
      <input type='checkbox' id='right_year18'><label>회상놀이 </label>&nbsp;&nbsp;
      <input type='checkbox' id='right_year19'><label>체조 </label> 
    </div>
 </div>
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-a957d06 elementor-widget elementor-widget-spacer" data-id="a957d06" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-31c4bc4 elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="31c4bc4" data-element_type="section" id="p_workout_title">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-d5dcde2" data-id="d5dcde2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-03296a8 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="03296a8" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-cd9ab54 elementor-widget elementor-widget-heading" data-id="cd9ab54" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎맞춤형 운동관리</h2>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-9b93f51 elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="9b93f51" data-element_type="section" id="p_workout1">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-dfeefe8" data-id="dfeefe8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-cbdc8b1 elementor-widget elementor-widget-html" data-id="cbdc8b1" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>운동 종류</p>

        <div id="disease_digit3">
          <input type='checkbox' id='v_workout1'><label>전신운동</label> &nbsp;&nbsp;
          <input type='checkbox' id='v_workout2'><label>하체운동</label> &nbsp;&nbsp;
          <input type='checkbox' id='v_workout3'><label>상체운동</label> &nbsp;&nbsp;
          <input type='checkbox' id='v_workout4'><label>명상</label> &nbsp;&nbsp;
        </div>
    </div>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-72a51cc" data-id="72a51cc" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e64ccc6 elementor-widget elementor-widget-html" data-id="e64ccc6" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			
<div class="panel_container">
    <div id="panel_title">
        <p>운동타이머</p>
    </div>
        <label class="switch">
            <input type="checkbox" id="pwo_tgle_btn" onclick="workout_toggle_proc();">
            <span class="slider round"></span>
        </label>
</div>

<script type="text/javascript">
function workout_toggle_proc()
{
    if(document.getElementById("pwo_tgle_btn").checked == true){
        document.getElementById('p_workout2').style.display ='inline';
    }else{
        document.getElementById('p_workout2').style.display ='none';
    }
}

</script>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5eda80e" data-id="5eda80e" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-58bb97f elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="58bb97f" data-element_type="section" id="p_workout2">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2b99bac" data-id="2b99bac" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3bc724b elementor-widget elementor-widget-html" data-id="3bc724b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container" >
    <div id="panel_title">
        <p>운동시간1</p>
    </div>
    
    <input class="panel_text_type" id="workout_timer1" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-b84b7e9 elementor-widget elementor-widget-html" data-id="b84b7e9" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container" >
    <div id="panel_title">
        <p>운동시간4</p>
    </div>
    
    <input class="panel_text_type" id="workout_timer4" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4f8de13" data-id="4f8de13" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ddf9277 elementor-widget elementor-widget-html" data-id="ddf9277" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>운동시간2</p>
    </div>
    
    <input class="panel_text_type" id="workout_timer2" type="time" value="-">
</div>		</div>
				</div>
				<div class="elementor-element elementor-element-84d8e48 elementor-widget elementor-widget-html" data-id="84d8e48" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>운동시간5</p>
    </div>
    
    <input class="panel_text_type" id="workout_timer5" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7e4a731" data-id="7e4a731" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e114118 elementor-widget elementor-widget-html" data-id="e114118" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container" >
    <div id="panel_title">
        <p>운동시간3</p>
    </div>
    
    <input class="panel_text_type" id="workout_timer3" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-008f27c elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="008f27c" data-element_type="section" id="ache_service_title">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-352b68b" data-id="352b68b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ee57172 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="ee57172" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-15a0239 elementor-widget elementor-widget-heading" data-id="15a0239" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎통증 관리</h2>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-0740569 elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="0740569" data-element_type="section" id="ache_service">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-8350d97" data-id="8350d97" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-f21d90e elementor-widget elementor-widget-html" data-id="f21d90e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>수술일</p>
    </div>
    
    <input class="panel_text_type" id="surgery_date" type="date" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-e08f6f2" data-id="e08f6f2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e00ab7e elementor-widget elementor-widget-html" data-id="e00ab7e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			
<div class="panel_container">
    <div id="panel_title">
        <p>통증 관리</p>
    
       
    </div>

        <label class="switch">
            <input type="checkbox" id="ache_tgle_btn" onclick="ache_toggle_proc();">
            <span class="slider round"></span>
        </label>

</div>

<script type="text/javascript">
function ache_toggle_proc()
{
    if(document.getElementById("ache_tgle_btn").checked == true){
        document.getElementById('ache_time_am_frame').style.display ='inline';
        document.getElementById('ache_time_pm_frame').style.display ='inline';
    }else{
        document.getElementById('ache_time_am_frame').style.display ='none';
        document.getElementById('ache_time_pm_frame').style.display ='none';
    }
}

</script>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-102cfe2 hidden" data-id="102cfe2" data-element_type="column" id="ache_time_am_frame">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-76d7fd0 elementor-widget elementor-widget-html" data-id="76d7fd0" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container" >
    <div id="panel_title">
        <p>오전</p>
    </div>
    
    <input class="panel_text_type" id="surgery_time_am" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2227f68 hidden" data-id="2227f68" data-element_type="column" id="ache_time_pm_frame">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-53b3e80 elementor-widget elementor-widget-html" data-id="53b3e80" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>오후</p>
    </div>
    
    <input class="panel_text_type" id="surgery_time_pm" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-f31733c elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="f31733c" data-element_type="section" id="emotion_service_title">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-9187abb" data-id="9187abb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e4d8530 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="e4d8530" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-00edfce elementor-widget elementor-widget-heading" data-id="00edfce" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎정서 관리</h2>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-5cf95b2 elementor-section-full_width hidden elementor-section-height-default elementor-section-height-default" data-id="5cf95b2" data-element_type="section" id="emotion_service">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-c778c8e" data-id="c778c8e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dd1ed30 elementor-widget elementor-widget-html" data-id="dd1ed30" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container" >
    <div id="panel_title">
        <p>오전</p>
    </div>
    
    <input class="panel_text_type" id="emotion_time_am" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-bcd038e" data-id="bcd038e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-553d8cd elementor-widget elementor-widget-html" data-id="553d8cd" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>오후</p>
    </div>
    
    <input class="panel_text_type" id="emotion_time_pm" type="time" value="-">
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-e1f63ff" data-id="e1f63ff" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-ce89a74 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ce89a74" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b950721" data-id="b950721" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-ad67bb8 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ad67bb8" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-f758620" data-id="f758620" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d7e3951" data-id="d7e3951" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-fa4691a" data-id="fa4691a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4d66fd8 elementor-widget elementor-widget-html" data-id="4d66fd8" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<!--

[ 파라메터 정보 ]
id : 123759
host_user_id : 7531
name : 이복동
phone_num : 01050414075
battery : 100
active_monitor : 24
sex : 2
bday : 1939-12-10
religion : 3
wakeup : 06:00:00
breakfast : 07:30:00
lunch : 12:30:00
dinner : 19:30:00
sleep : 23:00:00
drug_option : 1001010
ventilation_walk : 1
is_edited : 0
activeSenceTime : 24
pic_file_name : v2data/2855d538c56f42ca964ca2de17e5df262785868493968427186.jpg
is_delete : 0
mac_id : 5c:cf:7f:b0:be:0d
regdate : 2018-11-12 14:54:14
connection_type : 0
serial_number : 01W180800006
charms_mode : 1
no_alarm : 0
custom_timer1 : 07:00:00
custom_timer2 : 
custom_timer3 : 
custom_timer4 : 
custom_timer5 : 
religion_alarm : 0
calender_type : 0
is_edited : 1
is_active_detect : 0
-->

<script>

if(postArray)updateUserInfo(postArray);
 
function updateUserInfo(postArray){
   /* console.log('name:?' + postArray);

    console.log('start!');
    for (let key in postArray) {
      console.log('key:' + key + ' value:' + postArray[key]);
    }
    console.log('end!');
    */
    

    if(typeof postArray['id'] !== 'undefined') {
        document.getElementById('user_name').value = postArray['name'];
        
        //성별
        var select_sex = document.getElementById('sex');
        if(postArray['sex']==1){
            select_sex.options[0].selected = true;
        }else{
            select_sex.options[1].selected = true;
        }
         
        //생년월일
        document.getElementById('user_birthday').value = postArray['bday'];
        
        //양/음력
        var calender = "양력";
        switch(postArray['calender']){
            case '0':
                calender = "양력";
                break;
            case '1':
                calender = "음력";
                break;
        }
        //console.log(postArray['calender']);
        document.getElementById('calender_type').value = calender;
        
        //종교
        var religstr = "천주교";
        switch(postArray['religion']){
            case '1':
                religstr = "기독교";
                break;
            case '2':
                religstr = "불교";
                break;
            case '3':
                religstr = "무교";
                break;
        }
        document.getElementById('user_religion').value = religstr;
        
        var syukyou = document.getElementById('user_religion');
        syukyou.addEventListener('change', inputChange); 
        
        
       //전화번호
       // document.getElementById('user_phone').value = postArray['phone_num'];
        document.getElementById('user_phone').value = phoneFormatter(postArray['phone_num'],1);
        
       /*
        * 인형정보 
        */
       document.getElementById('dollId').value = postArray['id'];
       document.getElementById('battery').value = postArray['battery'];
     
       
       var dstate =(postArray['is_edited'] > 0)?"인형 동기화 대기중": "인형정보 동기화 완료";
      document.getElementById('states').value = dstate;
      
      //약복용기준정보
      var drugOptions = postArray['drug_option'];
      if(drugOptions.substring(0,1) == 1)document.getElementById("drugCheckbox1").checked = true;
      if(drugOptions.substring(1,2) == 1)document.getElementById("drugCheckbox2").checked = true;
      if(drugOptions.substring(2,3) == 1)document.getElementById("drugCheckbox3").checked = true;
      if(drugOptions.substring(3,4) == 1)document.getElementById("drugCheckbox4").checked = true;
      if(drugOptions.substring(4,5) == 1)document.getElementById("drugCheckbox5").checked = true;
      if(drugOptions.substring(5,6) == 1)document.getElementById("drugCheckbox6").checked = true;
      if(drugOptions.substring(6,7) == 1)document.getElementById("drugCheckbox7").checked = true; 
      
      //기상시간
      document.getElementById('wakeup').value = postArray['wakeup'];
      //아침시간
      document.getElementById('breakfast').value = postArray['breakfast'];
      //점심시간
      document.getElementById('lunch').value = postArray['lunch'];  
      //저녁시간
       document.getElementById('dinner').value = postArray['dinner']; 
      //취침시간
       document.getElementById('sleep').value = postArray['sleep'];
        
      //환기/산책
      var ventOption = postArray['ventilation_walk'];
      if(ventOption == 1)
        document.getElementById("v_walk1").checked = true;
      else if(ventOption == 2)
        document.getElementById("v_walk2").checked = true;
      else if(ventOption == 3){
        document.getElementById("v_walk1").checked = true;
        document.getElementById("v_walk2").checked = true;
      }
      
      //활동감지시간
      document.getElementById('activetime').value = postArray['activeSenceTime'];
      //방해금지모드(1:설정, 0:해제)
      var noAlarm = "";
      switch(postArray['no_alarm']){
            case '0':
                noAlarm = "해제";
                break;
            case '1':
                noAlarm = "설정";
                break;
        }
         document.getElementById('no_alarm').value = noAlarm;

         //종교말씀 타이머 설정
        var religionAalarm ="";
        switch(postArray['religion_alarm']){
            case '0':
                religionAalarm = "해제";
                break;
            case '1':
                religionAalarm = "설정";
                break;
        }
         document.getElementById('religion_alarm').value = religionAalarm;
       
       //호칭 
        var appellation = "";
        switch(postArray['appellation']){
            case '10000':
                appellation = "할머니/할아버지";
                break;
            case '00100':
                appellation = "어머니/아버지";
                break;
            case '01000':
                appellation = "엄마/아빠";
                break;    
        }
        
         document.getElementById('appellation').value = appellation;

      //질병 정보 
      var diseaseOption = postArray['disease'];
      console.log('diseaseOption:'+diseaseOption);
      
    if(diseaseOption.length == 3){     
         //질병정보 3개 버전
      document.getElementById('disease_digit10').style.display ='none';
      document.getElementById("v_disease1").checked = (diseaseOption[0] == '1')?true:false;
      document.getElementById("v_disease2").checked = (diseaseOption[1] == '1')?true:false;
      document.getElementById("v_disease3").checked = (diseaseOption[2] == '1')?true:false;
    }else{
        //질병정보 10개 버전
    document.getElementById('disease_digit3').style.display ='none'; 
    document.getElementById("v_disease11").checked = (diseaseOption[0] == '1')?true:false;  //고혈압
    document.getElementById("v_disease12").checked = (diseaseOption[1] == '1')?true:false;  //고지혈증
    document.getElementById("v_disease13").checked = (diseaseOption[2] == '1')?true:false;  //당뇨병
    document.getElementById("v_disease14").checked = (diseaseOption[3] == '1')?true:false;  //천식(호흡기계)
    document.getElementById("v_disease15").checked = (diseaseOption[4] == '1')?true:false;  //알레르기
    document.getElementById("v_disease16").checked = (diseaseOption[5] == '1')?true:false;  //무릎(퇴행성 관절염)
    document.getElementById("v_disease17").checked = (diseaseOption[6] == '1')?true:false;  //허리(퇴행성 관절염)
    document.getElementById("v_disease18").checked = (diseaseOption[7] == '1')?true:false;  //고관절(퇴행성 관절염)
    document.getElementById("v_disease19").checked = (diseaseOption[8] == '1')?true:false;  //금연
    document.getElementById("v_disease20").checked = (diseaseOption[9] == '1')?true:false;  //절주
    }

      //종교말씀시간1
      document.getElementById('custom_timer1').value = postArray['custom_timer1'];
      //종교말씀시간2
      document.getElementById('custom_timer2').value = postArray['custom_timer2'];
      //종교말씀시간3
      document.getElementById('custom_timer3').value = postArray['custom_timer3'];
      //종교말씀시간4
      document.getElementById('custom_timer4').value = postArray['custom_timer4'];
      //종교말씀시간5
      document.getElementById('custom_timer5').value = postArray['custom_timer5'];
    }

//console.log("-->"+postArray['left_ear_function'].length);
  
    var left_ear = postArray['left_ear_function'];
    if(postArray['left_ear_function'].length == 7){ 
        //구버전 효돌
       document.getElementById('left_digit9').style.display ='none';
       //
        if(left_ear.substring(0,1) == 1)document.getElementById("left_year1").checked = true;
        if(left_ear.substring(1,2) == 1)document.getElementById("left_year2").checked = true;
        if(left_ear.substring(2,3) == 1)document.getElementById("left_year3").checked = true;
        if(left_ear.substring(3,4) == 1)document.getElementById("left_year4").checked = true;
        if(left_ear.substring(4,5) == 1)document.getElementById("left_year5").checked = true;
        if(left_ear.substring(5,6) == 1)document.getElementById("left_year6").checked = true;
        if(left_ear.substring(6,7) == 1)document.getElementById("left_year7").checked = true; 
       
    }else{
        document.getElementById('left_digit7').style.display ='none';
        
        //
        if(left_ear.substring(0,1) == 1)document.getElementById("left_year11").checked = true;
        if(left_ear.substring(1,2) == 1)document.getElementById("left_year12").checked = true;
        if(left_ear.substring(2,3) == 1)document.getElementById("left_year13").checked = true;
        if(left_ear.substring(3,4) == 1)document.getElementById("left_year14").checked = true;
        if(left_ear.substring(4,5) == 1)document.getElementById("left_year15").checked = true;
        if(left_ear.substring(5,6) == 1)document.getElementById("left_year16").checked = true;
        if(left_ear.substring(6,7) == 1)document.getElementById("left_year17").checked = true; 
        if(left_ear.substring(7,8) == 1)document.getElementById("left_year18").checked = true; 
        if(left_ear.substring(8,9) == 1)document.getElementById("left_year19").checked = true; 
    }
    
    
    var right_ear = postArray['right_ear_function'];
    if(postArray['right_ear_function'].length == 7){ 
        //구버전 효돌
       document.getElementById('right_digit9').style.display ='none';
       //
        if(right_ear.substring(0,1) == 1)document.getElementById("right_year1").checked = true;
        if(right_ear.substring(1,2) == 1)document.getElementById("right_year2").checked = true;
        if(right_ear.substring(2,3) == 1)document.getElementById("right_year3").checked = true;
        if(right_ear.substring(3,4) == 1)document.getElementById("right_year4").checked = true;
        if(right_ear.substring(4,5) == 1)document.getElementById("right_year5").checked = true;
        if(right_ear.substring(5,6) == 1)document.getElementById("right_year6").checked = true;
        if(right_ear.substring(6,7) == 1)document.getElementById("right_year7").checked = true; 
    }else{
       document.getElementById('right_digit7').style.display ='none';
        if(right_ear.substring(0,1) == 1)document.getElementById("right_year11").checked = true;
        if(right_ear.substring(1,2) == 1)document.getElementById("right_year12").checked = true;
        if(right_ear.substring(2,3) == 1)document.getElementById("right_year13").checked = true;
        if(right_ear.substring(3,4) == 1)document.getElementById("right_year14").checked = true;
        if(right_ear.substring(4,5) == 1)document.getElementById("right_year15").checked = true;
        if(right_ear.substring(5,6) == 1)document.getElementById("right_year16").checked = true;
        if(right_ear.substring(6,7) == 1)document.getElementById("right_year17").checked = true; 
       if(right_ear.substring(7,8) == 1)document.getElementById("right_year18").checked = true; 
       if(right_ear.substring(8,9) == 1)document.getElementById("right_year19").checked = true;
    }
  
   
   //맞춤형 운동관리 보이기 
   if(postArray['sdfv_firm_version']>=60) 
   {
       document.getElementById("p_workout_title").classList.remove("hidden");
       document.getElementById("p_workout1").classList.remove("hidden");
        //
        var pworkout = postArray['wms_personal_workout']; 
        if(pworkout.substring(0,1) == 1)document.getElementById("v_workout1").checked = true;
        if(pworkout.substring(1,2) == 1)document.getElementById("v_workout2").checked = true;
        if(pworkout.substring(2,3) == 1)document.getElementById("v_workout3").checked = true;
        if(pworkout.substring(3,4) == 1)document.getElementById("v_workout4").checked = true;
        //
       if(postArray['wms_workout_timer_enable']==1)
       document.getElementById('pwo_tgle_btn').checked = true
       workout_toggle_proc();//체크박스 상태 업데이트
       //
        document.getElementById('workout_timer1').value = postArray['wms_workout_timer1'];
        document.getElementById('workout_timer2').value = postArray['wms_workout_timer2'];
        document.getElementById('workout_timer3').value = postArray['wms_workout_timer3'];
        document.getElementById('workout_timer4').value = postArray['wms_workout_timer4'];
        document.getElementById('workout_timer5').value = postArray['wms_workout_timer5'];
   } 
   
   //통증 관리 보이기
   if(postArray['ssbs_ache_service'] == 1)
   {
    document.getElementById("ache_service_title").classList.remove("hidden");
    document.getElementById("ache_service").classList.remove("hidden");
    document.getElementById('surgery_date').value = postArray['ams_surgery_date'];
    if(postArray['ams_service_enable']==1)
    document.getElementById('ache_tgle_btn').checked = true
     ache_toggle_proc();//체크박스 상태 업데이트
     
    //오전
    document.getElementById('surgery_time_am').value = postArray['ams_morning_timer'];
    //오후
    document.getElementById('surgery_time_pm').value = postArray['ams_afternoon_timer']; 
   }
   
   //정서 관리 보이기
   if(postArray['ssbs_emotion_service'] == 1)
   {
    document.getElementById("emotion_service_title").classList.remove("hidden");
    document.getElementById("emotion_service").classList.remove("hidden");
    
    //오전
    document.getElementById('emotion_time_am').value = postArray['ems_morning_timer'];
    //오후
    document.getElementById('emotion_time_pm').value = postArray['ems_afternoon_timer'];
   }
}

function inputChange(event){
    console.log(event.currentTarget.value);
    if(event.currentTarget.value == '무교'){
        document.getElementById("left_year4").disabled = true; //귀설정 무효
        document.getElementById("left_year14").disabled  = true;
          document.getElementById("right_year4").disabled = true;
        document.getElementById("right_year14").disabled  = true;
    }else{
          document.getElementById("left_year4").disabled = false; //귀설정 선택가능
        document.getElementById("left_year14").disabled  = false;
        document.getElementById("right_year4").disabled = false;
        document.getElementById("right_year14").disabled  = false;
    }
}

/*
전화번호 포맷 변경
*/
function phoneFormatter(num, type) {
    var formatNum = '';
    try{
       if (num.length == 11) {
          if (type == 0) {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
          } else {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
          }
       } else if (num.length == 8) {
          formatNum = num.replace(/(\d{4})(\d{4})/, '$1-$2');
       } else {
          if (num.indexOf('02') == 0) {
             if (type == 0) {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
             } else {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
             }
          } else {
             if (type == 0) {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
             } else {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
             }
          }
       }
    } catch(e) {
       formatNum = num;
       console.log(e);
    }
    return formatNum;
}



</script>


		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-a09b02e" data-id="a09b02e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-33b6091 elementor-widget elementor-widget-html" data-id="33b6091" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<button class="editBtn" type="button" id="otherInfoEdit">수정</button>


<script type='text/javascript'>
jQuery( '#otherInfoEdit' ).on( 'click', function(){
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'        :'other_info_edit',
            'doll_id'       :postArray['id'],
            'drug_option'   :drugPhase(),
            'wakeup'        :string2timer(jQuery('#wakeup').val()),
            'breakfast'     :string2timer(jQuery('#breakfast').val()),
            'lunch'         :string2timer(jQuery('#lunch').val()),
            'dinner'        :string2timer(jQuery('#dinner').val()),
            'sleep'         :string2timer(jQuery('#sleep').val()),
            'ventilation_walk':ventilationWalk(),
            'activeSenceTime':jQuery('#activetime').val(),
            
            'no_alarm'      :noAlarm(),
            'custom_timer1' :string2timer(jQuery('#custom_timer1').val()),
            'custom_timer2' :string2timer(jQuery('#custom_timer2').val()),
            'custom_timer3' :string2timer(jQuery('#custom_timer3').val()),
            'custom_timer4' :string2timer(jQuery('#custom_timer4').val()),
            'custom_timer5' :string2timer(jQuery('#custom_timer5').val()),
            'religion_alarm':getReligionAlarm(),
            'appellation'   :getAppellation(),     //호칭
            'disease'       :getDisease(),          //보유질환
            'left_ear'      :getLeftEarInfo(),
            'right_ear'     :getRightEarInfo(),
            
            //맞춤형 운동관리
            'pwo_visible': document.getElementById("p_workout_title").classList.contains('hidden'), //조건에 따라 표시가 정해지는 메뉴의 판단함. hidden 이 들어있으면 감춰진 메뉴(true)
            'personal_workout':getPersonalWorkout(),
            'workout_timer_enable':checkSlideCheck(jQuery('#pwo_tgle_btn')),
            'workout_timer1':string2timer2(jQuery('#workout_timer1').val()),
            'workout_timer2':string2timer2(jQuery('#workout_timer2').val()),
            'workout_timer3':string2timer2(jQuery('#workout_timer3').val()),
            'workout_timer4':string2timer2(jQuery('#workout_timer4').val()),
            'workout_timer5':string2timer2(jQuery('#workout_timer5').val()),
            
            //통증관리
            'ams_visible': document.getElementById("ache_service_title").classList.contains('hidden'), 
            'surgery_date'  :string2date(jQuery('#surgery_date').val()),
            'ams_service_enable':checkSlideCheck(jQuery('#ache_tgle_btn')),
            'ams_morning_timer'     :string2timer2(jQuery('#surgery_time_am').val()),
            'ams_afternoon_timer'   :string2timer2(jQuery('#surgery_time_pm').val()),
            
            //정서관리
            'ems_visible': document.getElementById("emotion_service_title").classList.contains('hidden'), 
            'ems_morning_timer'     :string2timer2(jQuery('#emotion_time_am').val()),
            'ems_afternoon_timer'   :string2timer2(jQuery('#emotion_time_pm').val())
        },
        success: function( response ){
          swal("수정 완료", "수정을 완료하였습니다", "success");
        },
        error: function( response,status,error){
          swal("수정 실패", error, "error");
        }
    });
    return false; 
});


//약복용기준정보
function drugPhase(){
    var drugOption = "";
   if(jQuery('#drugCheckbox1').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //아침식전
    if(jQuery('#drugCheckbox2').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //아침식후
    if(jQuery('#drugCheckbox3').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //점심식전 
    if(jQuery('#drugCheckbox4').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //점심식후
    if(jQuery('#drugCheckbox5').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //저녁식전
    if(jQuery('#drugCheckbox6').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //저녁식후
    if(jQuery('#drugCheckbox7').is(':checked'))drugOption = drugOption + "1";
   else drugOption = drugOption + "0"; //취침전
   // console.log('>>>>>> drugPhase():'+drugOption);
    return drugOption;
}


//Date 포멧 체크
function string2date(val_){
    if(val_.indexOf('-')<0)return -999;
    return val_;
}


//슬라이더가 켜져있으면(on)1, 꺼져있으면(off)0
function checkSlideCheck(val_){
   return val_.is(':checked')?"1":"0";
}

/*

시:분:초 의형식으로 되돌림
오전,오후, 시,분,초를 수정한뒤 값을 취득하면 '초' 값이 생략되는 문제용 
예)07:00 -> 07:00:00
*/

function string2timer(val_){
    //console.log('------>time:'+val_.indexOf(':'));
    if(val_.indexOf(':')<0)return -999;
 
    var tmp = val_.split(':');
   
    var t1,t2,t3;
   // console.log(tmp.length);
    if(tmp.length == 3){
        t1 = tmp[0];
        t2 = tmp[1];
        t3 = tmp[2];
    }else if(tmp.length == 2){
        t1 = tmp[0];
        t2 = tmp[1];
        t3 = '00';
    }else{
        t1 = tmp[0];
        t2 = '00';
        t3 = '00';
    }

    return (t1+':'+t2+":"+t3);
}


//통증관리 정서관리 전용. '시:분'만 전송
function string2timer2(val_){
    //console.log('------>time:'+val_.indexOf(':'));
    if(val_.indexOf(':')<0)return -999;
 
    var tmp = val_.split(':');
   
    var t1,t2,t3;
   // console.log(tmp.length);
    if(tmp.length == 3){
        t1 = tmp[0];
        t2 = tmp[1];
        t3 = tmp[2];
    }else if(tmp.length == 2){
        t1 = tmp[0];
        t2 = tmp[1];
        t3 = '00';
    }else{
        t1 = tmp[0];
        t2 = '00';
        t3 = '00';
    }
    return (t1+':'+t2); //시:분만

}

//환기/산책
function ventilationWalk(){
    var value = 0;
    var vo1 = jQuery('#v_walk1').is(':checked'); //환기
    var vo2 = jQuery('#v_walk2').is(':checked'); //산책
    if(vo1 == true && vo2 == true) {
        value = 3;
    } else if(vo2 == true) {
        value = 2;
    } else if(vo1 == true) {
        value = 1;
    }
    return value;
}

//방해금지모드
function noAlarm(){
    if(jQuery('#no_alarm').val() == '해제') return 0;
    else return 1;
}

//종교말씀타이머설정
function getReligionAlarm(){
    if(jQuery('#religion_alarm').val() == '해제') return 0;
    else return 1;
}

//호칭
function getAppellation(){
    var value = '00000';
    switch(jQuery('#appellation').val()){
        case '할머니/할아버지':
            value ='10000';
            break;
        case '어머니/아버지':
            value ='00100';
            break;
        case '엄마/아빠':
            value ='01000';
            break;
    }
    return value;
}

//맞춤형 운동관리
function getPersonalWorkout(){
    var value = '';
    value += (jQuery('#v_workout1').is(':checked'))?"1":"0"; //전신운동    
    value += (jQuery('#v_workout2').is(':checked'))?"1":"0"; //하체운동    
    value += (jQuery('#v_workout3').is(':checked'))?"1":"0"; //상체운동    
    value += (jQuery('#v_workout4').is(':checked'))?"1":"0"; //명상  
   // console.log('getPersonalWorkout:'+value);
    return value;
}


//보유질환
function getDisease(){
    var value = '';

    if( document.getElementById('disease_digit10').style.display =='none'){ 
        value += (jQuery('#v_disease1').is(':checked'))?"1":"0"; //고혈압
        value += (jQuery('#v_disease2').is(':checked'))?"1":"0"; //고지혈증
        value += (jQuery('#v_disease3').is(':checked'))?"1":"0"; //당뇨병
    }else{
        value += (jQuery('#v_disease11').is(':checked'))?"1":"0"; //고혈압
        value += (jQuery('#v_disease12').is(':checked'))?"1":"0"; //고지혈증
        value += (jQuery('#v_disease13').is(':checked'))?"1":"0"; //당뇨병
        value += (jQuery('#v_disease14').is(':checked'))?"1":"0"; //천식(호흡기계)
        value += (jQuery('#v_disease15').is(':checked'))?"1":"0"; //알레르기
        value += (jQuery('#v_disease16').is(':checked'))?"1":"0"; //무릎(퇴행성 관절염)
        value += (jQuery('#v_disease17').is(':checked'))?"1":"0"; //허리(퇴행성 관절염)
        value += (jQuery('#v_disease18').is(':checked'))?"1":"0"; //고관절(퇴행성 관절염)
        value += (jQuery('#v_disease19').is(':checked'))?"1":"0"; //금연
        value += (jQuery('#v_disease20').is(':checked'))?"1":"0"; //절주
    }
   // console.log('보유질환:'+value);
    return value;
}


//인형 신버전
//체조,회상놀이,트로트,클래식,종교음악,종교말씀,퀴즈,이야기,영어교실
//왼쪽 귀
function getLeftEarInfo(){
    var leftEar = "";
 
 if( document.getElementById('left_digit7').style.display =='none'){
    leftEar +=(jQuery('#left_year11').is(':checked'))?"1":"0";//영어교실
    leftEar +=(jQuery('#left_year12').is(':checked'))?"1":"0";//이야기
    leftEar +=(jQuery('#left_year13').is(':checked'))?"1":"0";//퀴즈
    leftEar +=(jQuery('#left_year14').is(':checked'))?"1":"0";//종교말씀
    leftEar +=(jQuery('#left_year15').is(':checked'))?"1":"0";//종교음악 
    leftEar +=(jQuery('#left_year16').is(':checked'))?"1":"0";//클래식
    leftEar +=(jQuery('#left_year17').is(':checked'))?"1":"0";//트로트
    leftEar +=(jQuery('#left_year18').is(':checked'))?"1":"0";//회상놀이
    leftEar +=(jQuery('#left_year19').is(':checked'))?"1":"0";//체조
 }else{
    leftEar +=(jQuery('#left_year1').is(':checked'))?"1":"0";//화상놀이
    leftEar +=(jQuery('#left_year2').is(':checked'))?"1":"0";//영어교실
    leftEar +=(jQuery('#left_year3').is(':checked'))?"1":"0";//음악
    leftEar +=(jQuery('#left_year4').is(':checked'))?"1":"0";//종교말씀
    leftEar +=(jQuery('#left_year5').is(':checked'))?"1":"0";//이야기
    leftEar +=(jQuery('#left_year6').is(':checked'))?"1":"0";//퀴즈
    leftEar +=(jQuery('#left_year7').is(':checked'))?"1":"0";//체조
 }
    return leftEar;
}

//왼쪽 귀
function getRightEarInfo(){
    var rightEar = "";
 if(document.getElementById('right_digit7').style.display =='none'){
    rightEar +=(jQuery('#right_year11').is(':checked'))?"1":"0";//영어교실
    rightEar +=(jQuery('#right_year12').is(':checked'))?"1":"0";//이야기
    rightEar +=(jQuery('#right_year13').is(':checked'))?"1":"0";//퀴즈
    rightEar +=(jQuery('#right_year14').is(':checked'))?"1":"0";//종교말씀
    rightEar +=(jQuery('#right_year15').is(':checked'))?"1":"0";//종교음악
    rightEar +=(jQuery('#right_year16').is(':checked'))?"1":"0";//클래식
    rightEar +=(jQuery('#right_year17').is(':checked'))?"1":"0";//트로트 
    rightEar +=(jQuery('#right_year18').is(':checked'))?"1":"0";//회상놀이 
    rightEar +=(jQuery('#right_year19').is(':checked'))?"1":"0";//체조 
 }else{
    rightEar +=(jQuery('#right_year1').is(':checked'))?"1":"0";//화상놀이
    rightEar +=(jQuery('#right_year2').is(':checked'))?"1":"0";//영어교실
    rightEar +=(jQuery('#right_year3').is(':checked'))?"1":"0";//음악
    rightEar +=(jQuery('#right_year4').is(':checked'))?"1":"0";//종교말씀
    rightEar +=(jQuery('#right_year5').is(':checked'))?"1":"0";//이야기
    rightEar +=(jQuery('#right_year6').is(':checked'))?"1":"0";//퀴즈
    rightEar +=(jQuery('#right_year7').is(':checked'))?"1":"0";//체조
 }

    return rightEar;
}
</script>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-8b55cf6 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="8b55cf6" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b701138" data-id="b701138" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3f32100 elementor-widget elementor-widget-spacer" data-id="3f32100" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		
	
</div>

</article>

				
			</div><!-- #content -->

			
		</div><!-- #primary -->

		
	</div><!-- #content-wrap -->

	

	</main><!-- #main -->

	
	
	
		
	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a id="scroll-top" class="scroll-top-right" href="#"><span class="fa fa-angle-up" aria-label="Scroll to the top of the page"></span></a>




<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":3701,"title":"user_info%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
</body>
</html>

<!-- Dynamic page generated in 0.296 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 15:10:19 -->
