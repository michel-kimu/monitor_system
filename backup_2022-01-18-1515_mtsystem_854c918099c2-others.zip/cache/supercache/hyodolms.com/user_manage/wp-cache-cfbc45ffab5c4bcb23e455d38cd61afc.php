<?php die(); ?><!DOCTYPE html>
<html lang="ko-KR">
<head>
	<meta charset="UTF-8">
		<title>user_manage &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-12843-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-12843.css?ver=1625620809' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/12843" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/user_manage/" />
<link rel='shortlink' href='http://hyodolms.com/?p=12843' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_manage%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_manage%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style>	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body class="page-template page-template-elementor_canvas page page-id-12843 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-template-canvas elementor-kit-10 elementor-page elementor-page-12843">
	<script>var emergencyState = 0;</script><script>var userId = 137517;</script>		<div data-elementor-type="wp-page" data-elementor-id="12843" class="elementor elementor-12843" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-3f1373d elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="3f1373d" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d2fb63c" data-id="d2fb63c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-59178d6 elementor-widget elementor-widget-heading" data-id="59178d6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎안부 확인</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-f43468f elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="f43468f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-eddf988" data-id="eddf988" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d5ca8b9 elementor-widget elementor-widget-html" data-id="d5ca8b9" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_egc_title">
        -
    </div>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-998863f" data-id="998863f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0104aa4 elementor-widget elementor-widget-html" data-id="0104aa4" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<button class="editBtn" type="button" id="userInfoEdit1">안부 확인</button>
 
 


<script type='text/javascript'>


updateEmergencyState(emergencyState);
console.log('>>>emergencyState:'+emergencyState);

function updateEmergencyState(emergencyState_){
    var btn = document.getElementById('userInfoEdit1');
    btn.disabled = (emergencyState_==1)?false:true; //1:연락필요 
    
    let emgcTxtElem = document.getElementById('panel_egc_title');
    
    if(emergencyState_==1){
        emgcTxtElem.innerHTML = '인형의 안부확인을 체크 할 수 있습니다';
        emgcTxtElem.style.color = 'red';
    }else{
        emgcTxtElem.innerHTML = '선택하신 인형은 안부확인이 필요없는 상태입니다';
        emgcTxtElem.style.color = 'blue';
    } 
}

/*
WorkBench등에서 다음과 같이 입력하여 '연락필요'상태로 전환한 후 테스트함
※2021-07-06 14:06:00 기준
※133268 :효돌아빠1

update scc_doll_state set last_none_action_time='2021-07-03 17:12:34'  where doll_id = '133268';
update scc_doll_state set date='2021-07-06 14:00:00'  where doll_id = '133268';
*/
jQuery( '#userInfoEdit1' ).on( 'click', function(){
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action' : 'emergency_btn_proc',
            'doll_id': userId,
        },
        success: function( response ){
            //var obj =JSON.parse(response); //문자열을 JSON으로 분해
            //updateUserInfo(obj);
            //swal('수정 완료');
           swal("확인 완료", "안부확인을 완료하였습니다", "success");
           updateEmergencyState(2);
        },
        error: function( response,status,error){
            swal("수정 실패", error, "error");
            updateEmergencyState(1);
        }
    });
    return false;
});
</script>



		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-a48f3e3 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="a48f3e3" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-087c816 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="087c816" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-f288e1f" data-id="f288e1f" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c01ea87" data-id="c01ea87" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-08503c7" data-id="08503c7" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2d5ea7c" data-id="2d5ea7c" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":12843,"title":"user_manage%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
	</body>
</html>

<!-- Dynamic page generated in 0.145 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 14:46:15 -->
