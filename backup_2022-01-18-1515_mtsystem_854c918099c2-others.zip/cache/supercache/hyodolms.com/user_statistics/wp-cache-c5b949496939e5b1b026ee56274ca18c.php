<?php die(); ?><!DOCTYPE html>
<html lang="ko-KR">
<head>
	<meta charset="UTF-8">
		<title>user_statistics &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-3709-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-3709.css?ver=1642048695' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/3709" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/user_statistics/" />
<link rel='shortlink' href='http://hyodolms.com/?p=3709' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_statistics%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_statistics%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style>	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body class="page-template page-template-elementor_canvas page page-id-3709 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-template-canvas elementor-kit-10 elementor-page elementor-page-3709">
			<div data-elementor-type="wp-page" data-elementor-id="3709" class="elementor elementor-3709" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-706db12 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="706db12" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2d6b8b0" data-id="2d6b8b0" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-ceef2c5 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ceef2c5" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d933572" data-id="d933572" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-733fc04 elementor-widget elementor-widget-html" data-id="733fc04" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char2_title">
        성명
    </div>
          
    <div id="user_name">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-0108202" data-id="0108202" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-96e057b elementor-widget elementor-widget-html" data-id="96e057b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char2_title">
        성별
    </div>
          
    <div id="sex">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-28d278d" data-id="28d278d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-630dff8 elementor-widget elementor-widget-html" data-id="630dff8" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char4_title">
        생년월일
    </div>
          
    <div id="birthday">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7b3d4ae" data-id="7b3d4ae" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b435ccf elementor-widget elementor-widget-html" data-id="b435ccf" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char4_title">
        전화번호
    </div>
          
    <div id="phone">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-0cf67c2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0cf67c2" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-1d1d533" data-id="1d1d533" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3fcbde5 elementor-widget elementor-widget-html" data-id="3fcbde5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class='search_table'>
<label class="label-disp" for="name">시작일</label><input class="input_search" id="fromDate" type="date">
<label class="label-disp" for="name">종료일</label><input class="input_search" id="toDate" type="date">
<button class="searchBtn" type="button" onclick="pageUpdate()">조회</button>

<div class="form_radio_group">
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_1" autocomplete="off"
                onclick="dayago('1')">
            <label for="radio_1">7일</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_2" autocomplete="off"
                onclick="dayago('2')">
            <label for="radio_2">15일</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_3" autocomplete="off"
                onclick="dayago('3')">
            <label for="radio_3">1개월</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_4" autocomplete="off"
                onclick="dayago('4')"> 
            <label for="radio_4">3개월</label>
        </div>
        <div class="form_radio_group-item">
           <input type="radio" name="options" id="radio_5" autocomplete="off"
                onclick="dayago('5')">
            <label for="radio_5">6개월</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_6" autocomplete="off"
                onclick="dayago('6')">
            <label for="radio_6">1년</label>
        </div>
    </div>
</div>



<script type='text/javascript'>
 
jQuery(function () {
    document.title = "개인 통계" ;
    
    document.getElementById('fromDate').value   = fromDate;
    document.getElementById('toDate').value     = toDate;
    
    //----------------------------------------
    document.getElementById('user_name').innerHTML  = userName; //성명
    sex = (sex=='1')?'남':'여';
	document.getElementById('sex').innerHTML        = sex;      //성별
	document.getElementById('birthday').innerHTML   = birthday;  //생년월일
	document.getElementById('phone').innerHTML      = phoneFormatter(phoneNum,1); //전화번호
    //----------------------------------------

    var radio_id = dateRange; //default value
    document.getElementById('radio_'+radio_id).checked=true;
    
    //-------------------------------------------
    drawGraph('00',12); //인형 사용자 인지강화 프로그램 수행
    
    drawGraph('01',4); //인지강화 프로그램 수행 트랜드
    
    drawGraph('02',10); //인형 사용자 배터리 변화
    
    drawGraph('03',8); //인형 사용자 인터렉션
    
    drawGraph('04',6); //인형 사용자 활동 감지
    
    drawGraph('05',2); //인형 사용자 약 복용 횟수
   
});


function drawGraph(elemId_, panelId_){
    /*var dt = new Date();
    var to = Date.parse(dt);
    dt.setDate(dt.getDate() - 7);
    var from = Date.parse(dt);
    */
    var fromDate = 	document.getElementById('fromDate').value;
    var from = Date.parse(fromDate);
    var toDate = 	document.getElementById('toDate').value;
    //var to = Date.parse(toDate);
    
     //-------------------------------------------
    //검색할 때만 종료일+1을 한 파라메터를 보내기로 수정(21.12.23)
    var date = new Date(toDate);
    date.setDate(date.getDate() + 1);
    var tmpYear = date.getFullYear()
    var tmpMonth= date.getMonth()+1;//월만 +1
    var tmpDate = date.getDate();
    
    var tmpEndDate = tmpYear+'-'+tmpMonth+'-'+tmpDate;
    to = Date.parse(tmpEndDate);
   // console.log('=신규종료일:'+tmpEndDate);
    //-------------------------------------------
    
    var iframe = document.getElementById("grafanaGraphArea"+elemId_);
    
    var url = '//15.164.89.157:3000/d-solo/grAHG4eGz/hyodol-personal?orgId=1&var-doll_id='+userId+'&panelId='+panelId_+'&from='+from+"&to="+to;
    
    //var url = '//106.254.228.130:23001/d-solo/7xGM9meMk/hydol-personal-dashboard-copy?orgId=1&var-doll_id='+userId+'&panelId='+panelId_+'&from='+from+"&to="+to;
    
iframe.contentDocument.location.replace(url); 
}

function dayago(id) {
     
  var dd;
     console.log('r>adio_id:'+id);
    switch(id){
        case '1':
            dd = 7;  //7일전 
            break;
        case '2':
            dd = 15; //15일전 
            break;    
        case '3':
            dd = 30; //한달전
            break;
        case '4':
            dd = 90; //두달전 
            break;
        case '5':
            dd = 180; //3달전 
            break;
        case '6':
            dd = 365; //일년전 
            break;
    }
    
    dateRange = id;

    var d = new Date();
    d.setDate(d.getDate() - dd);
    var nowday = new Date();
    // nowday = d.getDate()+1;//종료일을 내일로
    document.getElementById('fromDate').valueAsDate = d;
    document.getElementById('toDate').valueAsDate = nowday;
}
  
function pageUpdate(){
    var fromDate = 	document.getElementById('fromDate').value;
    var toDate = 	document.getElementById('toDate').value;
    
    console.log('id:'+userId + " , date_range:" + dateRange);
    window.location.href =  '/user_statistics?id='+userId+
                            '&date_range='+dateRange+
                            '&from='+fromDate+
                            '&to='+toDate;
                            
   
}



/*
전화번호 포맷 변경
*/
function phoneFormatter(num, type) {
    var formatNum = '';
    try{
       if (num.length == 11) {
          if (type == 0) {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
          } else {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
          }
       } else if (num.length == 8) {
          formatNum = num.replace(/(\d{4})(\d{4})/, '$1-$2');
       } else {
          if (num.indexOf('02') == 0) {
             if (type == 0) {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
             } else {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
             }
          } else {
             if (type == 0) {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
             } else {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
             }
          }
       }
    } catch(e) {
       formatNum = num;
       console.log(e);
    }
    return formatNum;
}  
</script>




       		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-37fe7f6 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="37fe7f6" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1a5f55d" data-id="1a5f55d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-934cf48 elementor-widget elementor-widget-heading" data-id="934cf48" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎개인 통계</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-32184e2 elementor-widget elementor-widget-text-editor" data-id="32184e2" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<script>	var userId 	  = '139579'; 
						var userName  = '통증test'; 
						var birthday  = '1940-06-05'; 
						var sex		  = '2'; 
						var phoneNum  = '01074801011'; 
						var dateRange = '3';
						var fromDate  = '2021-12-19';
						var toDate    = '2022-01-18';
			  </script>
<div class="wpdt-c wdt-skin-light">
    
<input type="hidden" id="wdtNonceFrontendEdit_5" name="wdtNonceFrontendEdit_5" value="2d948c6b2d" /><input type="hidden" name="_wp_http_referer" value="/user_statistics/?id=139579&amp;dmy=20220118145525" />    <input type="hidden" id="table_1_desc" value='{"tableId":"table_1","tableType":"mysql","selector":"#table_1","responsive":false,"editable":false,"inlineEditing":false,"infoBlock":true,"pagination":1,"paginationAlign":"right","paginationLayout":"full_numbers","tableSkin":"light","globalSearch":true,"showRowsPerPage":true,"popoverTools":false,"hideBeforeLoad":true,"number_format":2,"decimalPlaces":2,"spinnerSrc":"http:\/\/hyodolms.com\/wp-content\/plugins\/wpdatatables\/assets\/\/img\/spinner.gif","groupingEnabled":false,"tableWpId":"5","dataTableParams":{"sDom":"BT\u003C\u0027clear\u0027\u003Elftip","bSortCellsTop":false,"bFilter":true,"bPaginate":true,"sPaginationType":"full_numbers","aLengthMenu":[[1,5,10,25,50,100,-1],[1,5,10,25,50,100,"All"]],"iDisplayLength":50,"columnDefs":[{"sType":"date-custom","wdtType":"date","bVisible":true,"orderable":true,"searchable":true,"InputType":"none","name":"ref_date","origHeader":"ref_date","notNull":false,"conditionalFormattingRules":[],"className":" column-ref_date","aTargets":[0]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"drugcnt","origHeader":"drugcnt","notNull":false,"conditionalFormattingRules":[],"className":" column-drugcnt","aTargets":[1]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"meal_confirm","origHeader":"meal_confirm","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-meal_confirm","aTargets":[2]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"none","name":"strok","origHeader":"strok","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-strok","aTargets":[3]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"none","name":"hand_hold","origHeader":"hand_hold","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-hand_hold","aTargets":[4]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"none","name":"knock","origHeader":"knock","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-knock","aTargets":[5]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"none","name":"gymnastics","origHeader":"gymnastics","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-gymnastics","aTargets":[6]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"remembrance","origHeader":"remembrance","notNull":false,"conditionalFormattingRules":[],"className":" column-remembrance","aTargets":[7]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"music","origHeader":"music","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-music","aTargets":[8]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"classic_music","origHeader":"classic_music","notNull":false,"conditionalFormattingRules":[],"className":" column-classic_music","aTargets":[9]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"religion_music","origHeader":"religion_music","notNull":false,"conditionalFormattingRules":[],"className":" column-religion_music","aTargets":[10]},{"sType":"formatted-num","wdtType":"int","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"religion","origHeader":"religion","notNull":false,"conditionalFormattingRules":[],"className":"numdata integer  column-religion","aTargets":[11]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"quiz","origHeader":"quiz","notNull":false,"conditionalFormattingRules":[],"className":" column-quiz","aTargets":[12]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"story","origHeader":"story","notNull":false,"conditionalFormattingRules":[],"className":" column-story","aTargets":[13]},{"sType":"string","wdtType":"string","bVisible":true,"orderable":true,"searchable":true,"InputType":"text","name":"english","origHeader":"english","notNull":false,"conditionalFormattingRules":[],"className":" column-english","aTargets":[14]}],"bAutoWidth":false,"order":[[0,"asc"]],"ordering":true,"buttons":[{"extend":"excelHtml5","exportOptions":{"columns":":visible"},"className":"DTTT_button DTTT_button_xls","title":"\u258e\uac1c\uc778\ud1b5\uacc4","text":"Excel"}],"oLanguage":{"sSearchPlaceholder":""},"bProcessing":false,"oSearch":{"bSmart":false,"bRegex":false,"sSearch":""}},"tabletWidth":"1024","mobileWidth":"480","advancedFilterEnabled":false,"serverSide":false,"columnsFixed":0,"sumFunctionsLabel":"\ud569\uacc4","avgFunctionsLabel":"","minFunctionsLabel":"","maxFunctionsLabel":"","columnsDecimalPlaces":{"ref_date":-1,"drugcnt":-1,"meal_confirm":-1,"strok":-1,"hand_hold":-1,"knock":-1,"gymnastics":-1,"remembrance":-1,"music":-1,"classic_music":-1,"religion_music":-1,"religion":-1,"quiz":-1,"story":-1,"english":-1},"columnsThousandsSeparator":{"meal_confirm":1,"strok":1,"hand_hold":1,"knock":1,"gymnastics":1,"music":1,"religion":1},"sumColumns":[],"avgColumns":[],"sumAvgColumns":[],"timeFormat":"h:i A","datepickFormat":"yy\/mm\/dd"}'/>

    <table id="table_1"
           class="  display nowrap data-t data-t wpDataTable wpDataTableID-5"
           style="display: none; "
           data-described-by='table_1_desc'
           data-wpdatatable_id="5">

        <!-- Table header -->
        
<thead>
<tr>
                    <th
        data-class="expand"                class=" wdtheader sort "
        style="">등록일</th>        <th
                        class=" wdtheader sort "
        style="">복약횟수</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">식사확인</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">쓰다듬기</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">손잡기</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">토닥이기</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">체조</th>        <th
                        class=" wdtheader sort "
        style="">회상놀이</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">음악</th>        <th
                        class=" wdtheader sort "
        style="">클래식</th>        <th
                        class=" wdtheader sort "
        style="">종교음악</th>        <th
                        class=" wdtheader sort numdata integer "
        style="">종교</th>        <th
                        class=" wdtheader sort "
        style="">퀴즈</th>        <th
                        class=" wdtheader sort "
        style="">이야기</th>        <th
                        class=" wdtheader sort "
        style="">영어교실</th>    </tr>
</thead>
        <!-- /Table header -->

        <!-- Table body -->
        
<tbody>
            <tr id="table_5_row_0">
                            <td style="">2021/12/19</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_1">
                            <td style="">2021/12/20</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_2">
                            <td style="">2021/12/21</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">3</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_3">
                            <td style="">2021/12/22</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">16</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_4">
                            <td style="">2021/12/23</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">2</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_5">
                            <td style="">2021/12/24</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_6">
                            <td style="">2021/12/25</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_7">
                            <td style="">2021/12/26</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_8">
                            <td style="">2021/12/27</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">3</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_9">
                            <td style="">2021/12/28</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">6</td>
                            <td style="">7</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_10">
                            <td style="">2021/12/29</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">2</td>
                            <td style="">7</td>
                            <td style="">5</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_11">
                            <td style="">2021/12/30</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_12">
                            <td style="">2021/12/31</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_13">
                            <td style="">2022/01/01</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_14">
                            <td style="">2022/01/02</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_15">
                            <td style="">2022/01/03</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">2</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_16">
                            <td style="">2022/01/04</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_17">
                            <td style="">2022/01/05</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">3</td>
                            <td style="">1</td>
                            <td style="">12</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_18">
                            <td style="">2022/01/06</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">2</td>
                            <td style="">6</td>
                            <td style="">28</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_19">
                            <td style="">2022/01/07</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_20">
                            <td style="">2022/01/08</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_21">
                            <td style="">2022/01/09</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_22">
                            <td style="">2022/01/10</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">3</td>
                            <td style="">1</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">1</td>
                            <td style="">1</td>
                            <td style="">3</td>
                            <td style="">1</td>
                            <td style="">2</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_23">
                            <td style="">2022/01/11</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">145</td>
                            <td style="">4</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">116</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_24">
                            <td style="">2022/01/12</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">19</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_25">
                            <td style="">2022/01/13</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">7</td>
                            <td style="">4</td>
                            <td style="">11</td>
                            <td style="">1</td>
                            <td style="">1</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">3</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_26">
                            <td style="">2022/01/14</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_27">
                            <td style="">2022/01/15</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_28">
                            <td style="">2022/01/16</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">3</td>
                            <td style="">3</td>
                            <td style="">9</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_29">
                            <td style="">2022/01/17</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
                <tr id="table_5_row_30">
                            <td style="">2022/01/18</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">2</td>
                            <td style="">1</td>
                            <td style="">4</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">1</td>
                            <td style="">1</td>
                            <td style="">0</td>
                            <td style="">0</td>
                            <td style="">0</td>
                    </tr>
    </tbody>        <!-- /Table body -->

        <!-- Table footer -->
        
        <!-- /Table footer -->

    </table>

</div><style>
table.wpDataTable { table-layout: fixed !important; }
.md_button{
    width:100%;
    background  : rgb(58, 58, 58)  !important;
   line-height:0.0!important;
    
    border: 1px solid #666!important;
    color :#fff !important;
    /*padding:.5rem 2rem;*/
    font-size:18px;
    border-radius:5px; 
    /*box-shadow:0 2px 6px 0 rgba(122,122,122,.5);
    text-transform:none;*/
  
    transition:all .3s ease;

}
.md_button:hover{
    border: 1px solid #666;
    cursor:point; 
    color:#000 !important;
    background:#FFBF24 !important;
}



/*wpDataTable의 문자의 중앙정렬 */
.wpDataTablesWrapper table.wpDataTable td, 
.wpDataTablesWrapper table.wpDataTable th,
.wpDataTablesWrapper table.wpDataTable td.numdata, 
.wpDataTablesWrapper table.wpDataTable th.numdata
{ text-align: center !important; }


.wpDataTablesWrapper table.wpDataTable td.column-note{
    text-align: left !important;
}


.DTTT_button_csv{
    border:1px solid #7f7f7f !important;
    border-radius:5px !important;
    background  : #d6d8da  !important;
}table.wpDataTable td.numdata { text-align: right !important; }
</style>

<style>

.wpdt-c .wpDataTablesWrapper table.wpDataTable thead tr:nth-child(2) th {
	overflow: visible;
}

</style>
<style>
.DTTT_button_xls{
    border:1px solid #7f7f7f !important;
    border-radius:5px !important;
    background  : #d6d8da  !important;
}table.wpDataTable td.numdata { text-align: right !important; }</style>
		<div class="elementor-text-editor elementor-clearfix"><p></p></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-3f85f72 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="3f85f72" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-b8eae54 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b8eae54" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4f20060" data-id="4f20060" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e274989 elementor-widget elementor-widget-heading" data-id="e274989" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎인지강화 프로그램 수행</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d35bfec elementor-widget elementor-widget-html" data-id="d35bfec" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea00"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-0875b1f" data-id="0875b1f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c69e785 elementor-widget elementor-widget-heading" data-id="c69e785" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎인지강화 프로그램 수행 트랜드</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-3cde21c elementor-widget elementor-widget-html" data-id="3cde21c" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea01"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-34f6a09 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="34f6a09" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-54bd8ab" data-id="54bd8ab" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5a167c7 elementor-widget elementor-widget-spacer" data-id="5a167c7" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-1fce342 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="1fce342" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-0d5b609" data-id="0d5b609" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ec3ad82 elementor-widget elementor-widget-heading" data-id="ec3ad82" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎배터리 변화</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-ecb50ad elementor-widget elementor-widget-html" data-id="ecb50ad" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea02"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-606340e" data-id="606340e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d04ce2a elementor-widget elementor-widget-heading" data-id="d04ce2a" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎개인 인터렉션</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-12b4167 elementor-widget elementor-widget-html" data-id="12b4167" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea03"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-7d8457c elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="7d8457c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0036296" data-id="0036296" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5f03904 elementor-widget elementor-widget-spacer" data-id="5f03904" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-93d5800 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="93d5800" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-6babe53" data-id="6babe53" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ab840aa elementor-widget elementor-widget-heading" data-id="ab840aa" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎활동 감지</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-9395e4a elementor-widget elementor-widget-html" data-id="9395e4a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea04"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-a87abd2" data-id="a87abd2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-8477617 elementor-widget elementor-widget-heading" data-id="8477617" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎약 복용 횟수</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-1085927 elementor-widget elementor-widget-html" data-id="1085927" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea05"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-7a22524 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="7a22524" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d4c3270" data-id="d4c3270" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a70cca1 elementor-widget elementor-widget-spacer" data-id="a70cca1" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		
<!-- .wpdt-c -->
<div class="wpdt-c">
    <!-- .wdt-frontend-modal -->
    <div id="wdt-frontend-modal" class="modal fade wdt-frontend-modal" style="display: none" data-backdrop="static"
         data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">

        <!-- .modal-dialog -->
        <div class="modal-dialog">

            <!-- Preloader -->
            
<div class="overlayed wdt-preload-layer">
    <div class="preloader pl-lg">
        <svg class="pl-circular" viewBox="25 25 50 50">
            <circle class="plc-path" cx="50" cy="50" r="20"></circle>
        </svg>
    </div>
</div>            <!-- /Preloader -->

            <!-- .modal-content -->
            <div class="modal-content">

                <!-- .modal-header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Dynamic title for modals</h4>
                </div>
                <!--/ .modal-header -->

                <!-- .modal-body -->
                <div class="modal-body">
                </div>
                <!--/ .modal-body -->

                <!-- .modal-footer -->
                <div class="modal-footer">
                </div>
                <!--/ .modal-footer -->
            </div>
            <!--/ .modal-content -->
        </div>
        <!--/ .modal-dialog -->
    </div>
    <!--/ .wdt-frontend-modal -->
</div>
<!--/ .wpdt-c -->
<!-- .wpdt-c -->
<div class="wpdt-c">
    <!-- #wdt-delete-modal -->
    <div class="modal fade in" id="wdt-delete-modal" style="display: none" data-backdrop="static" data-keyboard="false"
         tabindex="-1" role="dialog" aria-hidden="true">

        <!-- .modal-dialog -->
        <div class="modal-dialog">

            <!-- .modal-content -->
            <div class="modal-content">

                <!-- .modal-header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true"> <i class="wpdt-icon-times-full"></i></span></button>
                    <h4 class="modal-title">Are you sure?</h4>
                </div>
                <!--/ .modal-header -->

                <!-- .modal-body -->
                <div class="modal-body">
                    <!-- .row -->
                    <div class="row">
                        <div class="col-sm-12">
                            <small>Please confirm deletion. There is no undo!</small>
                        </div>
                    </div>
                    <!--/ .row -->
                </div>
                <!--/ .modal-body -->

                <!-- .modal-footer -->
                <div class="modal-footer">
                    <hr>
                    <button type="button" class="btn btn-icon-text wdt-cancel-delete-button" data-dismiss="modal">
                        Cancel</button>
                    <button type="button" class="btn btn-danger btn-icon-text wdt-browse-delete-button"
                            id="wdt-browse-delete-button"><i
                                class="wpdt-icon-trash"></i> Delete</button>
                </div>
                <!--/ .modal-footer -->
            </div>
            <!--/ .modal-content -->
        </div>
        <!--/ .modal-dialog -->
    </div>
    <!--/ #wdt-delete-modal -->
</div>
<!--/ .wpdt-c --><link rel='stylesheet' id='wdt-bootstrap-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/wpdatatables-bootstrap.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-bootstrap-select-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/bootstrap-select/bootstrap-select.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-bootstrap-tagsinput-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/bootstrap-tagsinput/bootstrap-tagsinput.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-bootstrap-datetimepicker-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-bootstrap-nouislider-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/bootstrap-nouislider/bootstrap-nouislider.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-wp-bootstrap-datetimepicker-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/bootstrap-datetimepicker/wdt-bootstrap-datetimepicker.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-bootstrap-colorpicker-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/bootstrap/bootstrap-colorpicker/bootstrap-colorpicker.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-wpdt-icons-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/style.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-animate-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/animate/animate.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-uikit-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/uikit/uikit.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-wpdatatables-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/wdt.frontend.min.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wdt-skin-light-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/wdt-skins/light.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://hyodolms.com/wp-includes/css/dashicons.min.css?ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-select/bootstrap-select.min.js?ver=3.4.2' id='wdt-bootstrap-select-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap.min.js?ver=3.4.2' id='wdt-bootstrap-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-select/ajax-bootstrap-select.min.js?ver=3.4.2' id='wdt-bootstrap-ajax-select-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-tagsinput/bootstrap-tagsinput.js?ver=3.4.2' id='wdt-bootstrap-tagsinput-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/moment/moment.js?ver=3.4.2' id='wdt-moment-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js?ver=3.4.2' id='wdt-bootstrap-datetimepicker-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-nouislider/bootstrap-nouislider.min.js?ver=3.4.2' id='wdt-bootstrap-nouislider-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-nouislider/wNumb.min.js?ver=3.4.2' id='wdt-wNumb-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-colorpicker/bootstrap-colorpicker.min.js?ver=3.4.2' id='wdt-bootstrap-colorpicker-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/bootstrap/bootstrap-growl/bootstrap-growl.min.js?ver=3.4.2' id='wdt-bootstrap-growl-js'></script>
<script type='text/javascript' id='wdt-common-js-extra'>
/* <![CDATA[ */
var wpdatatables_edit_strings = {"add_new_entry":"Add new entry","back_to_date":"Back to date","browse_file":"Browse","cancel":"Cancel","cannot_be_empty":" field cannot be empty!","cannot_be_edit":"You can't edit this field","changeFileAttachment":"Change","choose_file":"Use selected file","chooseFile":"Choose file","close":"Close","columnAdded":"Column has been added!","columnHeaderEmpty":"Column header cannot be empty!","columnRemoveConfirm":"Please confirm column deletion!","columnRemoved":"Column has been removed!","columnsEmpty":"Please select columns that you want to use in table","copy":"Copy","currentlySelected":"Currently selected","databaseInsertError":"There was an error trying to insert a new row!","databaseDeleteError":"There was an error trying to delete a row!","dataSaved":"Data has been saved!","delete":"Delete","deleteSelected":"Delete selected","detach_file":"detach","edit_entry":"Edit entry","error":"Error!","errorText":"Unable to retrieve results","fileUploadEmptyFile":"Please upload or choose a file from Media Library!","from":"From","invalid_email":"Please provide a valid e-mail address for field","invalid_link":"Please provide a valid URL link for field","invalid_value":"You have entered invalid value. Press ESC to cancel.","lengthMenu":"Show _MENU_ entries","merge":"Merge","modalTitle":"Row details","newColumnName":"New column","nothingSelected":"Nothing selected","numberOfColumnsError":"Number of columns can not be empty or 0","numberOfRowsError":"Number of rows can not be empty or 0","oAria":{"sSortAscending":": activate to sort column ascending","sSortDescending":": activate to sort column descending"},"ok":"Ok","oPaginate":{"sFirst":"First","sLast":"Last","sNext":"Next","sPrevious":"Previous"},"previousFilter":"Choose an option in previous filters","replace":"Replace","removeFileAttachment":"Remove","rowDeleted":"Row has been deleted!","saveFileAttachment":"Save","select_upload_file":"Select a file to use in table","selectFileAttachment":"Select file","selectExcelCsv":"Select an Excel or CSV file","sEmptyTable":"No data available in table","settings_saved_successful":"Plugin settings saved successfully","settings_saved_error":"Unable to save settings of plugin. Please try again or contact us over Support page.","shortcodeSaved":"Shortcode has been copied to the clipboard.","sInfo":"Showing _START_ to _END_ of _TOTAL_ entries","sInfoEmpty":"Showing 0 to 0 of 0 entries","sInfoFiltered":"(filtered from _MAX_ total entries)","sInfoPostFix":"","sInfoThousands":",","sLengthMenu":"Show _MENU_ entries","sLoadingRecords":"Loading...","sProcessing":"Processing...","sqlError":"SQL error","sSearch":"Search: ","statusInitialized":"Start typing a search query","statusNoResults":"No Results","statusTooShort":"Please enter more characters","search":"Search...","success":"Success!","sZeroRecords":"No matching records found","systemInfoSaved":"System info data has been copied to the clipboard. You can now paste it in file or in support ticket.","tableSaved":"Table saved successfully!","tableNameEmpty":"Table name can not be empty! Please provide a name for your table.","to":"To","purchaseCodeInvalid":"The purchase code is invalid or it has expired","activation_domains_limit":"You have reached maximum number of registered domains","activation_envato_failed":"It seems you don't have a valid purchase of wpDataTables","envato_failed_powerful":"It seems you don't have a valid purchase of Powerful Filters for wpDataTables","envato_failed_report":"It seems you don't have a valid purchase of Report Builder for wpDataTables","envato_failed_gravity":"It seems you don't have a valid purchase of Gravity Forms integration for wpDataTables","envato_failed_formidable":"It seems you don't have a valid purchase of Formidable Forms integration for wpDataTables","pluginActivated":"Plugin has been activated","pluginDeactivated":"Plugin has been deactivated","envato_api_activated":"Activated with Envato","activateWithEnvato":"Activate with Envato","unable_to_deactivate_plugin":"Unable to deactivate plugin. Please try again later."};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/wpdatatables/admin/common.js?ver=3.4.2' id='wdt-common-js'></script>
<script type='text/javascript' id='wdt-wpdatatables-js-extra'>
/* <![CDATA[ */
var wdt_ajax_object = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
var wpdatatables_settings = {"wdtDateFormat":"Y\/m\/d","wdtTimeFormat":"h:i A","wdtNumberFormat":"2"};
var wpdatatables_frontend_strings = {"add_new_entry":"Add new entry","back_to_date":"Back to date","browse_file":"Browse","cancel":"Cancel","cannot_be_empty":" field cannot be empty!","cannot_be_edit":"You can't edit this field","changeFileAttachment":"Change","choose_file":"Use selected file","chooseFile":"Choose file","close":"Close","columnAdded":"Column has been added!","columnHeaderEmpty":"Column header cannot be empty!","columnRemoveConfirm":"Please confirm column deletion!","columnRemoved":"Column has been removed!","columnsEmpty":"Please select columns that you want to use in table","copy":"Copy","currentlySelected":"Currently selected","databaseInsertError":"There was an error trying to insert a new row!","databaseDeleteError":"There was an error trying to delete a row!","dataSaved":"Data has been saved!","delete":"Delete","deleteSelected":"Delete selected","detach_file":"detach","edit_entry":"Edit entry","error":"Error!","errorText":"Unable to retrieve results","fileUploadEmptyFile":"Please upload or choose a file from Media Library!","from":"From","invalid_email":"Please provide a valid e-mail address for field","invalid_link":"Please provide a valid URL link for field","invalid_value":"You have entered invalid value. Press ESC to cancel.","lengthMenu":"Show _MENU_ entries","merge":"Merge","modalTitle":"Row details","newColumnName":"New column","nothingSelected":"Nothing selected","numberOfColumnsError":"Number of columns can not be empty or 0","numberOfRowsError":"Number of rows can not be empty or 0","oAria":{"sSortAscending":": activate to sort column ascending","sSortDescending":": activate to sort column descending"},"ok":"Ok","oPaginate":{"sFirst":"First","sLast":"Last","sNext":"Next","sPrevious":"Previous"},"previousFilter":"Choose an option in previous filters","replace":"Replace","removeFileAttachment":"Remove","rowDeleted":"Row has been deleted!","saveFileAttachment":"Save","select_upload_file":"Select a file to use in table","selectFileAttachment":"Select file","selectExcelCsv":"Select an Excel or CSV file","sEmptyTable":"No data available in table","settings_saved_successful":"Plugin settings saved successfully","settings_saved_error":"Unable to save settings of plugin. Please try again or contact us over Support page.","shortcodeSaved":"Shortcode has been copied to the clipboard.","sInfo":"Showing _START_ to _END_ of _TOTAL_ entries","sInfoEmpty":"Showing 0 to 0 of 0 entries","sInfoFiltered":"(filtered from _MAX_ total entries)","sInfoPostFix":"","sInfoThousands":",","sLengthMenu":"Show _MENU_ entries","sLoadingRecords":"Loading...","sProcessing":"Processing...","sqlError":"SQL error","sSearch":"Search: ","statusInitialized":"Start typing a search query","statusNoResults":"No Results","statusTooShort":"Please enter more characters","search":"Search...","success":"Success!","sZeroRecords":"No matching records found","systemInfoSaved":"System info data has been copied to the clipboard. You can now paste it in file or in support ticket.","tableSaved":"Table saved successfully!","tableNameEmpty":"Table name can not be empty! Please provide a name for your table.","to":"To","purchaseCodeInvalid":"The purchase code is invalid or it has expired","activation_domains_limit":"You have reached maximum number of registered domains","activation_envato_failed":"It seems you don't have a valid purchase of wpDataTables","envato_failed_powerful":"It seems you don't have a valid purchase of Powerful Filters for wpDataTables","envato_failed_report":"It seems you don't have a valid purchase of Report Builder for wpDataTables","envato_failed_gravity":"It seems you don't have a valid purchase of Gravity Forms integration for wpDataTables","envato_failed_formidable":"It seems you don't have a valid purchase of Formidable Forms integration for wpDataTables","pluginActivated":"Plugin has been activated","pluginDeactivated":"Plugin has been deactivated","envato_api_activated":"Activated with Envato","activateWithEnvato":"Activate with Envato","unable_to_deactivate_plugin":"Unable to deactivate plugin. Please try again later."};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/wpdatatables/wdt.frontend.min.js?ver=3.4.2' id='wdt-wpdatatables-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/underscore.min.js?ver=1.13.1' id='underscore-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/js/export-tools/jszip.min.js?ver=3.4.2' id='wdt-js-zip-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":3709,"title":"user_statistics%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
	</body>
</html>

<!-- Dynamic page generated in 0.186 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 14:55:26 -->
