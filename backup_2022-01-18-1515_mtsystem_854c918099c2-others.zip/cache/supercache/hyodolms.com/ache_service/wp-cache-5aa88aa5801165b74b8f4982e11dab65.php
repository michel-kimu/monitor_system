<?php die(); ?><!DOCTYPE html>
<html class="html" lang="ko-KR">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>ache_service &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-15827-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-15827.css?ver=1641442830' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/15827" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/ache_service/" />
<link rel='shortlink' href='http://hyodolms.com/?p=15827' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fache_service%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fache_service%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style></head>

<body class="page-template-default page page-id-15827 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-kit-10 elementor-page elementor-page-15827" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
			
			<main id="main" class="site-main clr"  role="main">

				
	
	<div id="content-wrap" class="container clr">

		
		<div id="primary" class="content-area clr">

			
			<div id="content" class="site-content clr">

				
				
<article class="single-page-article clr">

	
<div class="entry clr" itemprop="text">

	
	<script>var userInfo = [{"reg_date":"2021-12-21 20:12","project_type":"3","reg_ampm":"20","type_status":"\ud1b5\uc99d\uc788\uc74c","stt":"\ub2e4\ub9ac\uac00 \ub108\ubb34 \uc544\ud30c","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1640084490160.mp3"},{"reg_date":"2021-12-22 14:12","project_type":"3","reg_ampm":"14","type_status":"\ud1b5\uc99d\uc788\uc74c","stt":"0 6 7 8 90 11 12 13 14 15 16","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1640150969504.mp3"},{"reg_date":"2021-12-24 11:12","project_type":"3","reg_ampm":"11","type_status":"\ud1b5\uc99d\uc5c6\uc74c","stt":"\ubab8\uc774 \ub108\ubb34 \uac1c\uc6b4\ud558\uace0 \ud558\ub098\ub3c4 \uc548\uc544\ud30c","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1640312312117.mp3"},{"reg_date":"2021-12-28 11:12","project_type":"3","reg_ampm":"11","type_status":"\ud1b5\uc99d\uc5c6\uc74c","stt":"\ub179\uc74c\uc774 \uc548\ub418\ub294 \uac70\uc57c","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1640657914479.mp3"},{"reg_date":"2021-12-28 19:12","project_type":"3","reg_ampm":"19","type_status":"\ud1b5\uc99d\uc5c6\uc74c","stt":"\ubc97\uc5b4\ub0a0\uc218\uac00 \uc5c6\uc5b4 \ubab8\uc774 \uc880 \ub450\ubc30 \uac00\uae4c\uc774 \uc0ac\ub9ac\uc554\uc5d0\uc11c \uc774\ubd88\ub3c4 \ub36e\uace0 \uc790\uc57c \ub420 \uac70 \uac19\uc560","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1640688101226.mp3"},{"reg_date":"2021-12-29 11:12","project_type":"3","reg_ampm":"11","type_status":"\ud1b5\uc99d\uc788\uc74c","stt":"\ub2e4\ub9ac \uc544\ud30c \ubc1c\uc774 \ubc1c\uc774 \ub9ce\uc774 \uc544\ud504\uace0 \ud5c8\ub9ac\ub3c4 \uc880 \uc544\ud504\uace0 \uadf8\ub0e5 \uadf8\ub807\ub124\uc694 \ub9c8\uc74c\ub3c4 \uc544\ud504\uace0 \uadf8\ub0e5 \uadf8\ub798","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1640744619371.mp3"},{"reg_date":"2022-1-12 19:01","project_type":"3","reg_ampm":"19","type_status":"\ud1b5\uc99d\uc788\uc74c","stt":"","file_url":"http:\/\/13.124.11.248:7920\/data\/doll_voice\/139579\/1641984396190.mp3"}];</script><script>	var userId 	  = '139579'; 
						var userName  = '통증test'; 
						var birthday  = '1940-06-05'; 
						var sex		  = '2'; 
						var phoneNum  = '01074801011'; 
						var dateRange = '4';
						var fromDate  = '2021-10-20';
						var toDate    = '2022-01-18';
			  </script>		<div data-elementor-type="wp-page" data-elementor-id="15827" class="elementor elementor-15827" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-0fabac4 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="0fabac4" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d05d719" data-id="d05d719" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-4490a53 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="4490a53" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-26e89f6" data-id="26e89f6" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-8f2a57d elementor-widget elementor-widget-html" data-id="8f2a57d" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char2_title">
        성명
    </div>
          
    <div id="user_name">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-e082949" data-id="e082949" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d2cf9b7 elementor-widget elementor-widget-html" data-id="d2cf9b7" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char2_title">
        성별
    </div>
          
    <div id="sex">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2e3d3c3" data-id="2e3d3c3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-30a2b79 elementor-widget elementor-widget-html" data-id="30a2b79" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char4_title">
        생년월일
    </div>
          
    <div id="birthday">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-56f7ee9" data-id="56f7ee9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-16729ee elementor-widget elementor-widget-html" data-id="16729ee" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char4_title">
        전화번호
    </div>
          
    <div id="phone">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-120290a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="120290a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-28d4345" data-id="28d4345" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4d0620e elementor-widget elementor-widget-html" data-id="4d0620e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class='search_table'>
<label class="label-disp" for="name">시작일</label><input class="input_search" id="fromDate" type="date">
<label class="label-disp" for="name">종료일</label><input class="input_search" id="toDate" type="date">
<button class="searchBtn" type="button" onclick="pageUpdate()">조회</button>

<div class="form_radio_group">
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_1" autocomplete="off"
                onclick="dayago('1')">
            <label for="radio_1">7일</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_2" autocomplete="off"
                onclick="dayago('2')">
            <label for="radio_2">15일</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_3" autocomplete="off"
                onclick="dayago('3')">
            <label for="radio_3">1개월</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_4" autocomplete="off"
                onclick="dayago('4')"> 
            <label for="radio_4">3개월</label>
        </div>
        <div class="form_radio_group-item">
           <input type="radio" name="options" id="radio_5" autocomplete="off"
                onclick="dayago('5')">
            <label for="radio_5">6개월</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_6" autocomplete="off"
                onclick="dayago('6')">
            <label for="radio_6">1년</label>
        </div>
    </div>
</div>



<script type='text/javascript'>
 
jQuery(function () {
    document.title = "통증관리" ;
    
    document.getElementById('fromDate').value   = fromDate;
    document.getElementById('toDate').value     = toDate;
    
    //----------------------------------------
    document.getElementById('user_name').innerHTML  = userName; //성명
    sex = (sex=='1')?'남':'여';
	document.getElementById('sex').innerHTML        = sex;      //성별
	document.getElementById('birthday').innerHTML   = birthday;  //생년월일
	document.getElementById('phone').innerHTML      = phoneFormatter(phoneNum,1); //전화번호
    //----------------------------------------

    var radio_id = dateRange; //default value
    document.getElementById('radio_'+radio_id).checked=true;
    
    //-------------------------------------------
    drawGraph('00',22);     //응답 충실도
    drawGraph('01',24);     //통증 상태 응답률
    drawGraph('02',14);     //키워드 분석
    drawGraph('03',16);     //감정 분석(지수 그래프)
    drawGraph('04',18);     //키워드 랭킹
    drawGraph('05',20);     //감성 비율(도넛 그래프)
   
});


function drawGraph(elemId_, panelId_){
    /*var dt = new Date();
    var to = Date.parse(dt);
    dt.setDate(dt.getDate() - 7);
    var from = Date.parse(dt);
    */
    var fromDate = 	document.getElementById('fromDate').value;
    var from = Date.parse(fromDate);
    var toDate = 	document.getElementById('toDate').value;
    //var to = Date.parse(toDate);

    //-------------------------------------------
    //검색할 때만 종료일+1을 한 파라메터를 보내기로 수정(21.12.23)
    var date = new Date(toDate);
    date.setDate(date.getDate() + 1);
    var tmpYear = date.getFullYear()
    var tmpMonth= date.getMonth()+1;//월만 +1
    var tmpDate = date.getDate();
    
    var tmpEndDate = tmpYear+'-'+tmpMonth+'-'+tmpDate;
    to = Date.parse(tmpEndDate);
   // console.log('=신규종료일:'+tmpEndDate);
    //-------------------------------------------

    var iframe = document.getElementById("grafanaGraphArea"+elemId_);
    
    var url = '//15.164.89.157:3000/d-solo/grAHG4eGz/hyodol-personal?orgId=1&var-doll_id='+userId+'&var-project_type=3&from='+from+'&to='+to+'&panelId='+panelId_;

    iframe.contentDocument.location.replace(url); 
}

function dayago(id) {
     
  var dd;
     console.log('r>adio_id:'+id);
    switch(id){
        case '1':
            dd = 7;  //7일전 
            break;
        case '2':
            dd = 15; //15일전 
            break;    
        case '3':
            dd = 30; //한달전
            break;
        case '4':
            dd = 90; //두달전 
            break;
        case '5':
            dd = 180; //3달전 
            break;
        case '6':
            dd = 365; //일년전 
            break;
    }
    
    dateRange = id;

    var d = new Date();
    d.setDate(d.getDate() - dd);
    var nowday = new Date();
   // nowday = d.getDate()+1;//종료일을 내일로
    
    document.getElementById('fromDate').valueAsDate = d;
    document.getElementById('toDate').valueAsDate = nowday;
}
  
function pageUpdate(){
    var fromDate = 	document.getElementById('fromDate').value;
    var toDate = 	document.getElementById('toDate').value;
    
    //console.log('id:'+userId + " , date_range:" + dateRange);
    window.location.href =  '/ache_service?id='+userId+
                            '&date_range='+dateRange+
                            '&from='+fromDate+
                            '&to='+toDate;
}



/*
전화번호 포맷 변경
*/
function phoneFormatter(num, type) {
    var formatNum = '';
    try{
       if (num.length == 11) {
          if (type == 0) {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
          } else {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
          }
       } else if (num.length == 8) {
          formatNum = num.replace(/(\d{4})(\d{4})/, '$1-$2');
       } else {
          if (num.indexOf('02') == 0) {
             if (type == 0) {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
             } else {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
             }
          } else {
             if (type == 0) {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
             } else {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
             }
          }
       }
    } catch(e) {
       formatNum = num;
       console.log(e);
    }
    return formatNum;
}  
</script>




       		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-6e6f747 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="6e6f747" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-546000f" data-id="546000f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6d2514a elementor-widget elementor-widget-heading" data-id="6d2514a" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎응답 충실도</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-0dab2c6 elementor-widget elementor-widget-html" data-id="0dab2c6" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea00"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4432d44" data-id="4432d44" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-fa05816 elementor-widget elementor-widget-heading" data-id="fa05816" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎통증상태 유무비율</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-6d3af9a elementor-widget elementor-widget-html" data-id="6d3af9a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea01"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-69e724a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="69e724a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d4359b9" data-id="d4359b9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2e540f5 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="2e540f5" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-b24e401 elementor-widget elementor-widget-heading" data-id="b24e401" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎음성 내용</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d605d54 elementor-widget elementor-widget-html" data-id="d605d54" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			


<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.jqueryui.min.css">

<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/1.11.3/js/dataTables.jqueryui.min.js"></script>


<!--CSV출력 -->

<script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
<div>
<table id="table" class="display"></table>    
</div>

<script type='text/javascript'>

jQuery(function () {
    
//console.log('userInfo:'+JSON.stringify(userInfo));
//console.log('user>>'+userInfo[0].reg_date);

    var jsonData = {
        "data":userInfo
    }

//console.log('jsonData:'+JSON.stringify(jsonData));

    var table = jQuery("#table").DataTable(
                {
                    dom: 'Blfrtip', //버튼군을 추가했을때 lengthchange가 사라지지 않게 하기 위함 https://datatables.net/forums/discussion/29866/datatables-buttons-removes-the-length-menu
                   //dom: 'Bl<"col-sm-6"f>rtip',
             
                    buttons: [
                        {
                            extend: 'excel',
                            text: 'Excel',
                            filename: '정서관리표내용',
                            messageTop: null,           //'메시지 탑'
                            title: null,                //'타이틀'
                            messageBottom: null,        //'메시지끝'
                        }
                    ],

                    data: jsonData.data,
                   // columns: col_kor, 
                    columns: [
                        { targets: 0, data: 'reg_date'      , title: '등록일시' },
                        { targets: 1, data: 'project_type'  , title: 'project_type' },
                        { targets: 2, data: 'reg_ampm'      , title: '등록시점' },
                        { targets: 3, data: 'type_status'   , title: '상태' },
                        { targets: 4, data: 'stt'           , title: 'STT' },
                        { targets: 5, data: 'file_url'      , title: '음성듣기' }
                    ],

                    language: lang_kor,     //인터페이스 한글화
                    paging: true,           //페이지기능  true:사용, false:사용않함
                    searching: true,        //검색 기능 
                    ordering: true,         //정렬 기능
                    info: true,             //1 - 10 (총 17 명)이런거..
                    lengthChange: true,     //개씩 표시
                    lengthMenu: [5, 10, 20, 30, 40, 50],  //개씩 표시용 리스트  
                    //pageLength:5,
                    //displayLength: 2,     //개씩 표시의 디폴트 값
                    scrollX: true,          //x방향 스크롤 표시 (scrollX는true/false로 설정)
                    //scrollY: 200          //y방향 스크롤 표시 (scrollY는200, "200px"등, 최대의 높이로 지정)


                    // 열 설정
                    columnDefs: [
                        {
                            targets:0,
                            width:"12%",
                            className: "my-class"
                        },
                        {
                            targets:1,
                            visible:false
                            
                        },
                        {
                            targets:2,
                            className: "ampm-class",
                            width: "7%",
                            render: function (data, type, row, meta) {
                                if (type === 'display') {
                                    if(data < 12){
                                        data = '<div>오전</div> '
                                    }else{
                                        data = '<div>오후</div> '
                                    }
                                }
                                return data;
                            }
                        },
                        {
                            targets: 3,
                            width:"7%",
                            className: "red-class"
                        }, 
                        {
                            targets: 5, //3번째 열에 audio controller 추가
                            visible: true,
                            width: "7%",
  
                           render: function (data, type, row, meta) {
                                if (type === 'display') {
                                    data = '<audio controls  class="audioStyle"> <source src="' + data + '" type="audio/ogg" 　> </audio>'
                                }
                                return data;
                            }
                        },
                    ],
                    rowCallback: function (row, data) { //셀의 컬러가 자동으로 바뀜
                         if (data.type_status == "통증있음") {
                            jQuery('td.red-class', row).css('background', '#FFBBBB');
                        }else{
                            jQuery('td.red-class', row).css('background', '#BBFFC4');
                        }
                        
                        if (data.reg_ampm < 12) { //am
                            jQuery('td.ampm-class', row).css('background', '#BEF3FF');
                        }else{
                            jQuery('td.ampm-class', row).css('background', '#FFDDB2'); //pm
                        }
                    },
                    select: {
                        style: 'multi'
                    },
                    order: [[0, 'asc']]
                }
            ); 
       
        
});
         // Korean
        var lang_kor = {
            "decimal": "",
            "emptyTable": "데이터가 없습니다.",
            "info": "_START_ - _END_ (총 _TOTAL_ 건)",
            "infoEmpty": "0건",
            "infoFiltered": "(전체 _MAX_ 명 중 검색결과)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "_MENU_ 개씩 보이기",
            "loadingRecords": "로딩중...",
            "processing": "처리중...",
            "search": "검색 : ",
            "zeroRecords": "검색된 데이터가 없습니다.",
            "paginate": {
                "first": "첫 페이지",
                "last": "마지막 페이지",
                "next": "다음",
                "previous": "이전"
            },
            "aria": {
                "sortAscending": " :  오름차순 정렬",
                "sortDescending": " :  내림차순 정렬"
            }
        };
</script>		</div>
				</div>
				<div class="elementor-element elementor-element-87f68cb elementor-widget elementor-widget-html" data-id="87f68cb" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
					</div>
				</div>
				<div class="elementor-element elementor-element-a1ace50 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="a1ace50" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-f879297 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="f879297" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-b991a15" data-id="b991a15" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-b68a8de elementor-widget elementor-widget-heading" data-id="b68a8de" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎키워드 분석</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-0e10b20 elementor-widget elementor-widget-html" data-id="0e10b20" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea02"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-0671a17" data-id="0671a17" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-85716b1 elementor-widget elementor-widget-heading" data-id="85716b1" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎감정 분석</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-49ae299 elementor-widget elementor-widget-html" data-id="49ae299" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea03"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4e0a26f elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="4e0a26f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8c45557" data-id="8c45557" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a3bca4c elementor-widget elementor-widget-spacer" data-id="a3bca4c" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-1cae90b elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="1cae90b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7e10790" data-id="7e10790" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c3b0eb4 elementor-widget elementor-widget-heading" data-id="c3b0eb4" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎키워드 랭킹</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-41bd6bf elementor-widget elementor-widget-html" data-id="41bd6bf" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea04"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-0f1f931" data-id="0f1f931" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-47e0341 elementor-widget elementor-widget-heading" data-id="47e0341" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎감성 비율</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-e3dd255 elementor-widget elementor-widget-html" data-id="e3dd255" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<iframe id="grafanaGraphArea05"
    
    width="100%"
    height="400"
    >
</iframe>

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-abb4832 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="abb4832" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-abfedfb" data-id="abfedfb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2297fe4 elementor-widget elementor-widget-spacer" data-id="2297fe4" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		
	
</div>

</article>

				
			</div><!-- #content -->

			
		</div><!-- #primary -->

		
	</div><!-- #content-wrap -->

	

	</main><!-- #main -->

	
	
	
		
	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a id="scroll-top" class="scroll-top-right" href="#"><span class="fa fa-angle-up" aria-label="Scroll to the top of the page"></span></a>




<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":15827,"title":"ache_service%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
</body>
</html>

<!-- Dynamic page generated in 0.163 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 15:12:42 -->
