<?php die(); ?><!DOCTYPE html>
<html lang="ko-KR">
<head>
	<meta charset="UTF-8">
		<title>user_note &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-5051-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-5051.css?ver=1640245088' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/5051" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/user_note/" />
<link rel='shortlink' href='http://hyodolms.com/?p=5051' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_note%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fuser_note%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style>	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body class="page-template page-template-elementor_canvas page page-id-5051 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-template-canvas elementor-kit-10 elementor-page elementor-page-5051">
	<script>	var userId 	  = '140082'; 
						var userName  = '임금녀'; 
						var birthday  = '1930-07-12'; 
						var sex		  = '2'; 
						var phoneNum  = '0613327307'; 
						var dateRange = '3';
						var fromDate  = '2021-12-19';
						var toDate    = '2022-01-18';
			  </script><script>var userNote = [];</script>		<div data-elementor-type="wp-page" data-elementor-id="5051" class="elementor elementor-5051" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-f8ac768 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="f8ac768" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9c493fc" data-id="9c493fc" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-21ab928 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="21ab928" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-2f38532" data-id="2f38532" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-df433bb elementor-widget elementor-widget-html" data-id="df433bb" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char2_title">
        성명
    </div>
          
    <div id="user_name">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-6c75fec" data-id="6c75fec" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e57dc9a elementor-widget elementor-widget-html" data-id="e57dc9a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char2_title">
        성별
    </div>
          
    <div id="sex">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-7f63c2a" data-id="7f63c2a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3b9e832 elementor-widget elementor-widget-html" data-id="3b9e832" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char4_title">
        생년월일
    </div>
          
    <div id="birthday">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-b0cef8c" data-id="b0cef8c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-871650e elementor-widget elementor-widget-html" data-id="871650e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "user_info_tab">
    <div class="char4_title">
        전화번호
    </div>
          
    <div id="phone">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-f7f15c5" data-id="f7f15c5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0b6e76b elementor-widget elementor-widget-html" data-id="0b6e76b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<button class="sendSmsBtn" type="button" onclick="sendSms()">SMS연락하기</button>


<div id="smsModal" class="sms-modal">
  <div class="sms-modal-content">
    <div class="sms-modal-title">SMS전송</div>
       <button class="sms-modal-close-btn" id = "closeBtn" onclick="closeSmsModalWindow()">&times;</button>
        <div class="sms-modal-phone-title">
            <p>수신자</p>
         </div>    
            <input class="sms-modal-phone-area" id="sms-phone-number" placeholder="전화번호를 '-' 없이 입력하세요"  type="tel" pattern="[0-9]{2,3}[0-9]{3,4}[0-9]{3,4}" maxlength="11" >
         <div class="sms-modal-message-title">
            <p>메시지</p>    
        </div>
            <textarea class="sms-modal-message-area" id="sms_message" maxlength="40" placeholder="40글자까지 입력이 가능합니다"></textarea>
    
        <button class="sms-modal-cancel-btn" id = "sms_cancelBtn" onclick="closeSmsModalWindow()">취소</button>
        <button class="sms-modal-save-btn" id = "sms_saveBtn" onclick="sendSMS()">전송</button>
  </div>
</div>


<script>
function telValidator(phoneNum) {
   var regExp =/(01[016789])([1-9]{1}[0-9]{2,3})([0-9]{4})$/; 
   var myArray; 
   if(regExp.test(phoneNum)){ 
       myArray = regExp.exec(phoneNum); 
       // console.log(myArray[1]); // console.log(myArray[2]); // console.log(myArray[3]); 
       return true; } 
    return false; 
}

function sendSMS(){
    var phone  = document.getElementById('sms-phone-number');
    var msg    = document.getElementById('sms_message');
    
    if(phone.value ==''){
        swal("입력오류", "전화번호를 '-' 없이 입력하세요", "warning");
        return;
    }else if(!telValidator(phone.value)){
        swal("입력오류", "유효하지 않은 전화번호입니다", "warning");
        return;
    }   
    
    var phoneNumber = phone.value;
    var message = (msg.value);//.replace(/(\r\n\t|\n|\r\t)/gm,""); //안짤라도 가네
   
    if(msg.value ==''){
        swal("입력오류", "전송하실 메시지를 입력하세요", "warning");
        return;
    }    

     jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'        :'send_sms',
            'phone'         : phoneNumber,
            'message'       : message
        },
        success: function( response ){
           swal("메시지 전송 완료", "", "success");
        },
        error: function( response,status,error){
           swal("메시지 전송 실패", error, "error");
        }
    });
    
    document.getElementById('sms-phone-number').value = '';
    document.getElementById('sms_message').value = '';
    
    closeSmsModalWindow();
    return false; 
}



var sms_modal = document.getElementById("smsModal");

function closeSmsModalWindow(){
    document.getElementById("sms-phone-number").value ='';
    document.getElementById("sms_message").value ='';

    sms_modal.style.display = "none";
}


function sendSms(){
    var txt = document.getElementById('user_note');
    //txt.innerHTML  = "Fuck?";
    sms_modal.style.display = "block";
}


</script>
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-1bed8fe elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1bed8fe" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-ff7bd89" data-id="ff7bd89" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e8977fd elementor-widget elementor-widget-html" data-id="e8977fd" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class='search_table'>
<label class="label-disp" for="name">시작일</label><input class="input_search" id="fromDate" type="date">
<label class="label-disp" for="name">종료일</label><input class="input_search" id="toDate" type="date">
<button class="searchBtn" type="button" onclick="pageUpdate()">조회</button>

<div class="form_radio_group">
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_1" autocomplete="off"
                onclick="dayago('1')">
            <label for="radio_1">7일</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_2" autocomplete="off"
                onclick="dayago('2')">
            <label for="radio_2">15일</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_3" autocomplete="off"
                onclick="dayago('3')">
            <label for="radio_3">1개월</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_4" autocomplete="off"
                onclick="dayago('4')"> 
            <label for="radio_4">3개월</label>
        </div>
        <div class="form_radio_group-item">
           <input type="radio" name="options" id="radio_5" autocomplete="off"
                onclick="dayago('5')">
            <label for="radio_5">6개월</label>
        </div>
        <div class="form_radio_group-item">
            <input type="radio" name="options" id="radio_6" autocomplete="off"
                onclick="dayago('6')">
            <label for="radio_6">1년</label>
        </div>
    </div>
</div>

<script type='text/javascript'>

jQuery(function () {
    document.title = "개인 노트" ;
    
    document.getElementById('fromDate').value   = fromDate;
    document.getElementById('toDate').value     = toDate;
    
    //----------------------------------------
    document.getElementById('user_name').innerHTML  = userName; //성명
    sex = (sex=='1')?'남':'여';
	document.getElementById('sex').innerHTML        = sex;      //성별
	document.getElementById('birthday').innerHTML   = birthday;  //생년월일
	document.getElementById('phone').innerHTML      = phoneFormatter(phoneNum,1); //전화번호
    //----------------------------------------

    var radio_id = dateRange; //default value
    document.getElementById('radio_'+radio_id).checked=true;
});


function dayago(id) {
     
    var dd;
    switch(id){
        case '1':
            dd = 7;  //7일전 
            break;
        case '2':
            dd = 15; //15일전 
            break;    
        case '3':
            dd = 30; //한달전
            break;
        case '4':
            dd = 90; //두달전 
            break;
        case '5':
            dd = 180; //3달전 
            break;
        case '6':
            dd = 365; //일년전 
            break;
        }
    
    dateRange = id;
    
    var d = new Date();
    d.setDate(d.getDate() - dd);
    var nowday = new Date();
    //nowday.setDate(nowday.getDate()+1);
    document.getElementById('fromDate').valueAsDate = d;
    document.getElementById('toDate').valueAsDate = nowday;
}
  
function pageUpdate(){
    var fromDate = 	document.getElementById('fromDate').value;
    var toDate = 	document.getElementById('toDate').value;
    
    console.log('id:'+userId + " , date_range:" + dateRange);
    window.location.href =  '/user_note?id='+userId+
                            '&date_range='+dateRange+
                            '&from='+fromDate+
                            '&to='+toDate+
                            '&dmy='+getCurrentTime();
                            //서버 갱신을 위해서 더미(현재시간)를 추가
}


/*
전화번호 포맷 변경
*/
function phoneFormatter(num, type) {
    var formatNum = '';
    try{
       if (num.length == 11) {
          if (type == 0) {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
          } else {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
          }
       } else if (num.length == 8) {
          formatNum = num.replace(/(\d{4})(\d{4})/, '$1-$2');
       } else {
          if (num.indexOf('02') == 0) {
             if (type == 0) {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
             } else {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
             }
          } else {
             if (type == 0) {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
             } else {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
             }
          }
       }
    } catch(e) {
       formatNum = num;
       console.log(e);
    }
    return formatNum;
}  
</script> 




       		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-ce85a48 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ce85a48" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5b52a3e" data-id="5b52a3e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-320d0db elementor-widget elementor-widget-heading" data-id="320d0db" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎노트 작성</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-5477a9a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="5477a9a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-c2ec914" data-id="c2ec914" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-fd640e4 elementor-widget elementor-widget-html" data-id="fd640e4" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>현황</p>
    </div>
    
   <select class="panel_text_type" id='user_state'>
       <option>연락필요</option>
       <option>연락끊김</option>
       <option>안부</option>
       <option>문의/답변</option>
       <option>기타</option>
    </select>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-c57994a" data-id="c57994a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-348f29d elementor-widget elementor-widget-html" data-id="348f29d" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>사유</p>
    </div>
    
   <select class="panel_text_type" id='user_reason'>
       <option>여행/친척/지인집 방문</option>
       <option>병원/수술</option>
       <option>전원OFF</option>
       <option>기타</option>
    </select>
</div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4502908" data-id="4502908" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-04c7fc6 elementor-widget elementor-widget-html" data-id="04c7fc6" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_container">
    <div id="panel_title">
        <p>작성자</p>
    </div>
    
    <input maxlength='8' class="panel_text_type" id="writer" type="text" >
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-4a19061 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="4a19061" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-448071a" data-id="448071a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2550140 elementor-widget elementor-widget-html" data-id="2550140" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class="panel_note_container">
    <div id="panel_title">
        <p>노트</p>
    </div>
    
    <textarea class="panel_note_input" id="user_note" placeholder="400글자까지 입력할 수 있습니다" maxlength="400" ></textarea>
</div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-7a1081e elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="7a1081e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-acac192" data-id="acac192" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3af7cfd" data-id="3af7cfd" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-1419c70" data-id="1419c70" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-153e2a7" data-id="153e2a7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-67befec elementor-widget elementor-widget-html" data-id="67befec" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>


<button class="editBtn" type="button" id="insertUserNote">등록</button>
 
<script type='text/javascript'>
jQuery( '#insertUserNote' ).on( 'click', function(){
    
    console.log(userId);
    console.log(document.getElementById('user_state').value);
    console.log(document.getElementById('user_reason').value);
 
    console.log('->'+document.getElementById('user_note').value);
    console.log(document.getElementById('writer').value);
    
    if(document.getElementById('writer').value ==''){
        swal("입력오류", "작성자 이름을 넣어주세요", "warning");
        return;
    }    
        
    if(document.getElementById('user_note').value ==''){
        swal("입력오류", "노트를 입력해 주세요", "warning");
        return;
    }    

    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'    : 'insert_user_note',
            'id'        : userId,
            'state'     : document.getElementById('user_state').value,
            'reason'    : document.getElementById('user_reason').value,
            'note'      : document.getElementById('user_note').value,
            'writer'    : document.getElementById('writer').value
        },
        success: function( response ){
            //var obj =JSON.parse(response); //문자열을 JSON으로 분해
            //updateUserInfo(obj);
           // alert(response);
            swal({
                title:"노트 입력 완료", 
                text:"노트 입력을 완료하였습니다", 
                icon:"success"
                }).then(function(){
                    pageUpdate();
                });
           
        },
        error: function( response,status,error){
            swal("노트 입력 실패", error, "error");
        }
    });
    return false;
});


//현재시간취득（yyyymmddhhmmss）
function getCurrentTime() {
    var now = new Date();
    var res = "" + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) + 
        padZero(now.getMinutes()) + padZero(now.getSeconds());
    return res;
}

//선두 제로 붙힘
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}


function checkReligion(var_){
    switch(var_){
        case '천주교':
            return 0;
            break;
        case '기독교':
            return 1;
            break;
        case '불교':
            return 2;
            break;
        case '무교':
            return 3;
            break;            
    }
}

</script>



		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-b23eb23 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b23eb23" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7638e31" data-id="7638e31" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9f492e7 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="9f492e7" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-61a4980 elementor-widget elementor-widget-heading" data-id="61a4980" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">▎노트 이력</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d3bc659 elementor-widget elementor-widget-html" data-id="d3bc659" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			
 

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
    google.charts.load('current', {packages: ['charteditor']});
  </script>

<div id="table_div" ></div>
  <!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-title">노트관리 </div>
    <button class="modal-close-btn" id = "closeBtn" onclick="closeModalWindow()">&times;</button>
    <div class="modal-note-title">날짜</div><br><input class="modal-datearea" id="editDate" type="date">
   
    <div class="modal-note-title">
        <p>내용</p>
    </div>
    <textarea class="modal-textarea" id="note" placeholder="" maxlength="400"></textarea>

    <button class="modal-cancel-btn" id = "cancelBtn" onclick="closeModalWindow()">취소</button>
    <button class="modal-save-btn" id = "saveNoteBtn" onclick="saveDollNote()">수정</button>
    <button class="modal-confirm-btn" id = "confirmNoteBtn" onclick="confirmNote()">확인</button>
  </div>
</div>

 
<script type="text/javascript">
 
google.charts.setOnLoadCallback(loadUserNote);

function loadUserNote() {
    if(!userNote)return;
    
    console.log("START!!");
    var cssClassNames = {
    'headerRow':'',
    'tableRow': '',
    'oddTableRow': '',
    'selectedTableRow': '',
    'hoverTableRow': '',
    'headerCell': '',
    'tableCell': '',
    'rowNumberCell': ''};
    
    var options = {
        'showRowNumber': false, 
        'width': '100%', 
        'height': '100%',
        'allowHtml': true, 
        'cssClassNames': cssClassNames
    };
     
    var datatb = new google.visualization.DataTable();
    datatb.addColumn('string', '날짜');
    datatb.addColumn('string', '현황');
    datatb.addColumn('string', '사유');
    datatb.addColumn('string', '노트');
    datatb.addColumn('string', '작성자');
    datatb.addColumn('string', '상태');
    datatb.addColumn('string', '관리');
    datatb.addColumn('string', '삭제');
           
          
    console.log("userNote>:"+userNote.length);
    
    datatb.addRows(userNote.length);
    
    jQuery.each(userNote, function (index, item) {
        /*
        console.log('index:'+index);
        console.log('fdate:'+item.fdate);
        console.log('state:'+item.state);
        console.log('reason:'+item.reason);
        console.log('note:'+item.note);
        console.log('writer:'+item.writer);
        console.log('iscomplete :'+item.iscomplete );
        */
        datatb.setProperty(0, 0, 'style', 'width:100px'); 
        datatb.setProperty(0, 1, 'style', 'width:60px');   
        datatb.setProperty(0, 2, 'style', 'width:120px');   
        datatb.setProperty(0, 3, 'style', 'width:600px');  
        datatb.setProperty(0, 4, 'style', 'width:40px');  
        datatb.setProperty(0, 5, 'style', 'width:50px');  
        datatb.setProperty(0, 6, 'style', 'width:2px');  
        datatb.setProperty(0, 7, 'style', 'width:2px');  
        
        datatb.setCell(index, 0, item.fdate);
        datatb.setCell(index, 1, item.state);
        datatb.setCell(index, 2, item.reason);
        
        var notestr = '<div class="col-xs-6 pull-left"><p class="text-left">'+ item.note +'</p></div>';
        var noterp = notestr.replace(/(?:\r\n|\r|\n)/g, '<br />');
                    
        datatb.setCell(index, 3, notestr);
        datatb.setCell(index, 4, item.writer);
        datatb.setCell(index, 5, item.iscomplete == 0 ? "등록됨" :  "완료됨" );
       var udpbuttons = '<button type="button" class="editDeleteBtn" onclick=\"editNote('+item.id+','+index+');\">수정</button> '; 

         datatb.setCell(index, 6, udpbuttons);
         var delbutton = "<button type='button' class='editDeleteBtn' onclick=\"deleteNote("+item.id+");\" >삭제</button> "
         datatb.setCell(index, 7, delbutton );
    });
  
    var view = new google.visualization.DataView(datatb);
    var table = new google.visualization.Table(document.getElementById('table_div'));
 table.draw(view, {showRowNumber: false, width: '100%', allowHtml: true,'cssClassNames': cssClassNames});
 
    /*
    google.visualization.events.addListener(table, 'select', function() {
        var row = table.getSelection()[0].row;
        alert('You selected ' + datatb.getValue(row, 0));
      });
    */
    
    
    //오늘 이후의 날짜는 선택하지 못하도록
    var today = new Date();
    today.setDate(today.getDate());
    var yyyy = today.getFullYear();
    var mm = ("0"+(today.getMonth()+1)).slice(-2);
    var dd = ("0"+today.getDate()).slice(-2);
    document.getElementById('editDate').max =yyyy+'-'+mm+'-'+dd;
    
}

//노트 삭제
function deleteNote(id_){
    console.log('delete:' +id_);  
    
    swal({
            title:"노트를 삭제할까요?", 
            text:"삭제 후 복원이 불가능합니다.", 
            icon:"warning",

             buttons: {
                cancel: "취소",
                ok: "삭제"
              }
            }).then(function(val) {
                if (val) {
                  // 삭제버튼 클릭시 처리
                   deleteConfirm(id_);
                } else {
                  // 취소버튼 클릭시 처리(val =null)
                 /*
                  swal({
                    text: "취소버튼 클릭시 처리",
                    icon: "warning",
                    buttons: false,
                    timer: 2500 // 2.5초후에 자동으로 닫음
                  });
                  */
                }
            });
}

//삭제 결정
function deleteConfirm(id_){
    
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action' : 'delete_user_note',
            'noteId' : id_,
        },
        success: function( response ){
            swal({
                title:"노트 삭제 완료", 
                text:"노트 삭제를 완료하였습니다", 
                icon:"success"
                }).then(function(){
                    // window.location.reload(true);
                     location.href = window.location.href+"?dmy="+ getCurrentTime();
                });
           
        },
        error: function( response,status,error){
            swal("노트 삭제 실패", error, "error");
        }
    });
    return false;
}



//---------------------------------------------
// 모달윈도우
function closeModalWindow(){
    modal.style.display = "none";
}
// 
var modal = document.getElementById("myModal");

// 모달윈도우 밖을 클릭했을때
window.onclick = function(event) {
  if (event.target == modal) {
   closeModalWindow();
  }
  if (event.target == sms_modal) {
   closeSmsModalWindow();
  }
}
//---------------------------------------------


/*
 * 노트 수정
*/
var currentNoteId = -1;
function editNote(id_, index_){
    currentNoteId = id_;
//  console.log('edit:' +id_ + ', ' +index_ +','+userNote[index_][6]); 

//console.log('edit:' +id_ + ', ' +index_ +','+userNote[index_][5]); 
//console.log('edit:' +id_ + ', ' +index_ +','+userNote[index_][6]); 


    var date_ = userNote[index_][5];
    date_= date_.split(' ');
 
    document.getElementById('editDate').value = date_[0];// //날짜
    document.getElementById('note').value = userNote[index_][6];
    modal.style.display = "block";
}

/*
 * 상태 변경 (등록됨->완료됨)
*/
function confirmNote(){
    console.log("currentNoteId:"+currentNoteId);
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'    : 'update_complete_doll_note',
            'noteId'    : currentNoteId
        },
        success: function( response ){
            swal({
                title:"상태변경 완료", 
                text:"상태설정이 완료되었습니다", 
                icon:"success"
                }).then(function(){
                    // window.location.reload(true);
                     location.href = window.location.href+"?dmy="+ getCurrentTime();
                });
           
        },
        error: function( response,status,error){
            swal("상태변경 실패", error, "error");
        }
    });
    return false;
}


/*
 * 노트 수정
*/
function saveDollNote(){
    var now = new Date();
    console.log("currentNoteId:"+currentNoteId);
    console.log("currentNoteId:"+document.getElementById('note').value);
    console.log( getCurrentTime());
    var editDate_ = document.getElementById('editDate').value;
    editDate_ = editDate_.replace(/-/g ,'')+padZero(now.getHours()) + padZero(now.getMinutes()) + padZero(now.getSeconds());  //노트작성일을 수정해 달라고 해서 
    console.log(editDate_ );

    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        data: {
            'action'    : 'save_doll_note',
            'noteId'    : currentNoteId,
            'editDate'  : editDate_,
            'note'      : document.getElementById('note').value 
        },
        success: function( response ){
            swal({
                title:"노트 저장 완료", 
                text:"노트 저장이 완료되었습니다", 
                icon:"success"
                }).then(function(){
                    // window.location.reload(true); //edge에서는 반영이 안됨
                    location.href = window.location.href+"?dmy="+ getCurrentTime();
                });
           
        },
        error: function( response,status,error){
            swal("노트 저장 실패", error, "error");
        }
    });
    return false;
}



//현재시간취득（yyyymmddhhmmss）
function getCurrentTime() {
    var now = new Date();
    var res = "" + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) + 
        padZero(now.getMinutes()) + padZero(now.getSeconds());
    return res;
}

//선두 제로 붙힘
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}

</script>





		</div>
				</div>
				<div class="elementor-element elementor-element-323d077 elementor-widget elementor-widget-spacer" data-id="323d077" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":5051,"title":"user_note%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
	</body>
</html>

<!-- Dynamic page generated in 0.143 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 15:07:04 -->
