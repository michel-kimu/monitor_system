<?php die(); ?><!DOCTYPE html>
<html lang="ko-KR">
<head>
	<meta charset="UTF-8">
		<title>main &#8211; mtsystem</title>
<meta name='robots' content='noindex, nofollow' />
<meta name="viewport" content="width=device-width, initial-scale=1">    <script>
        var ajaxurl = 'http://hyodolms.com/wp-admin/admin-ajax.php';
    </script>
	<link rel='dns-prefetch' href='//cdn.datatables.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 피드" href="http://hyodolms.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="mtsystem &raquo; 댓글 피드" href="http://hyodolms.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/hyodolms.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://hyodolms.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='http://hyodolms.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=2.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-datatables-css-css'  href='//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='http://hyodolms.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-10-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-10.css?ver=1619679755' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='wpdt-elementor-widget-font-css'  href='http://hyodolms.com/wp-content/plugins/wpdatatables/assets/css/elementor/style.css?ver=3.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/global.css?ver=1619683697' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-4180-css'  href='http://hyodolms.com/wp-content/uploads/elementor/css/post-4180.css?ver=1639461335' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='http://hyodolms.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.8.3' type='text/css' media='all' />
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js?ver=5.8.3' id='jquery-datatables-js-js'></script>
<link rel="https://api.w.org/" href="http://hyodolms.com/wp-json/" /><link rel="alternate" type="application/json" href="http://hyodolms.com/wp-json/wp/v2/pages/4180" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://hyodolms.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://hyodolms.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<link rel="canonical" href="http://hyodolms.com/main/" />
<link rel='shortlink' href='http://hyodolms.com/?p=4180' />
<link rel="alternate" type="application/json+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fmain%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://hyodolms.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fhyodolms.com%2Fmain%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header,.has-transparent-header .is-sticky #site-header,.has-vh-transparent .is-sticky #site-header.vertical-header,#searchform-header-replace{background-color:#333333}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-navigation-wrap .dropdown-menu >li >a{padding:0 40px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#dddddd}
</style>	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body class="page-template page-template-elementor_canvas page page-id-4180 wp-custom-logo wp-embed-responsive oceanwp-theme dropdown-mobile no-header-border default-breakpoint content-full-screen page-header-disabled elementor-default elementor-template-canvas elementor-kit-10 elementor-page elementor-page-4180">
	<script>var agencyInfos = {"agency":"024623001901","agencyName":"\uad11\uc591\uc2dc \uc7ac\uac00","agencyNum":"024623001901","femaleCnt":"241 \uba85","maleCnt":"23 \uba85","avgAge":"79.8 \uc138","ageArg":"46~95 \uc138","score01":"264","score02":"86","score03":"17","score04":"16","score05":"12","score06":"133"};</script>		<div data-elementor-type="wp-page" data-elementor-id="4180" class="elementor elementor-4180" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-93b641d elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="93b641d" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e7cf24b" data-id="e7cf24b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-ab4a9b4 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ab4a9b4" data-element_type="section">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6715bc4" data-id="6715bc4" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3a3805e elementor-widget elementor-widget-html" data-id="3a3805e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "agent_nametab">
    <div class="agent_txt">
        기관명
    </div>
          
    <div id="agent_name">
         -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-adb3dde" data-id="adb3dde" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d38b1e8 elementor-widget elementor-widget-html" data-id="d38b1e8" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "agent_number_tab">
    <div class="agent_txt">
        기관 코드
    </div>
          
    <div id="agent_num">
       -
    </div>
</div> 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5b3ac84" data-id="5b3ac84" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-7a39d1e elementor-widget elementor-widget-html" data-id="7a39d1e" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<script type='text/javascript'>


function sendPost(event) {
  event.preventDefault();
 
  var form = document.createElement('form');
  form.action = '/agency_page';//event.target.href;
  form.method = 'post';
  
  var p1 = document.createElement('input');
  p1.type='text';
  p1.name = 'agcname';
  p1.value = agencyInfos['agencyName'];
  form.appendChild(p1);
  
  var p2 = document.createElement('input');
  p2.type='text';
  p2.name = 'agcnum';
  p2.value = agencyInfos['agencyNum'];
  form.appendChild(p2);
   
  form.target ='_blank'; //새창에서 열기
  document.body.appendChild(form);
 
  form.submit();
 
}

</script>

<button class="ststicsBtn" type="button"  onclick="sendPost(event)">통계/리포팅</button>
 
 

		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-d371794 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="d371794" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6055238" data-id="6055238" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-1f58d75 elementor-widget elementor-widget-html" data-id="1f58d75" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "sex_tab">
    <div id="sex_female">
        여자
    </div>
          
    <div id="female_total_count">
        -
    </div>
</div> 
 
		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-9a38f1c" data-id="9a38f1c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5a2855b elementor-widget elementor-widget-html" data-id="5a2855b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "sex_tab">
    <div id="sex_male">
        남자
    </div>
          
    <div id="male_total_count">
        -
    </div>
</div> 

 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-79641f7" data-id="79641f7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-beeb6f3 elementor-widget elementor-widget-html" data-id="beeb6f3" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "sex_detailtab">
    <div id ="age_info">
        평균연령
    </div>
          
    <div id="ave_rage_age">
        -
    </div>
</div> 
		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7db7797" data-id="7db7797" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2b6f39d elementor-widget elementor-widget-html" data-id="2b6f39d" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div class = "sex_detailtab">
    <div id="age_info">
        연령범위 
    </div>
          
    <div id="arngage">
        -
    </div>
</div> 
		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-b430975 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b430975" data-element_type="section">
						<div class="elementor-container elementor-column-gap-narrow">
					<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-860dedb" data-id="860dedb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9da81bc elementor-widget elementor-widget-html" data-id="9da81bc" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div id="score_card1">
    <div id="score_title1_bg">
        <div id="score_title1_txt">
            전체
        </div>
    </div>
    <div id="score01">
        -
    </div>
</div>


 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-e4fd35a" data-id="e4fd35a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-269d75b elementor-widget elementor-widget-html" data-id="269d75b" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div id="score_card2">
    <div id="score_title2_bg">
        <div id="score_title2_txt">
            감지중
        </div>
    </div>
    <div id="score02">
        -
    </div>
</div>


 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-7b9cb23" data-id="7b9cb23" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6b4c677 elementor-widget elementor-widget-html" data-id="6b4c677" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div id="score_card3">
    <div id="score_title3_bg">
        <div id="score_title3_txt">
            연락필요
        </div>
    </div>
    <div id="score03">
        -
    </div>
</div>


 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-0395df3" data-id="0395df3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-89d76a5 elementor-widget elementor-widget-html" data-id="89d76a5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div id="score_card4">
    <div id="score_title4_bg">
        <div id="score_title4_txt">
            연결끊김
        </div>
    </div>
    <div id="score04">
        -
    </div>
    <div id="score04_range">
       (~7일)
    </div>
</div>


 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-b9ce4ad" data-id="b9ce4ad" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0434a8a elementor-widget elementor-widget-html" data-id="0434a8a" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div id="score_card5">
    <div id="score_title5_bg">
        <div id="score_title5_txt">
            연결끊김
        </div>
    </div>
    <div id="score05">
        -
    </div>
    <div id="score05_range">
       (8일~ 30일 미만)
    </div>
</div>


 		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-d19b655" data-id="d19b655" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-26e94d0 elementor-widget elementor-widget-html" data-id="26e94d0" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<div id="score_card6">
    <div id="score_title6_bg">
        <div id="score_title6_txt">
            연결끊김
        </div>
    </div>
    <div id="score06">
        -
    </div>
    <div id="score06_range">
       (30일 이상)
    </div>
</div>


 		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-a96acbc elementor-widget elementor-widget-html" data-id="a96acbc" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
			

<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>


<div id="csvBtnArea" style="float:right"></div>
<table id="mainTable" class = "display" style="width:100%">
    <thead>
        <tr>
            <th>상태</th>
            <th>이름</th>
            <th>시리얼넘버</th>
            <th>전화번호</th>
            <th>성별</th>
            <th>생년월일</th>
            <th>소속기관</th>
            <th>담당자 연락처</th>
            <th>설정(h)</th>
            <th>베터리(%)</th>
            <th>등록일</th>
            <th>최종 접속일</th>
            <th>관리</th>
        </tr>
    </thead>
</table>
<input type='hidden' id='agencyCode'/>



<script>
var lang_kor = {
        "decimal" : "",
        "emptyTable" : "데이터가 없습니다.",
        "info" : "_START_ - _END_ (총 _TOTAL_ 명)",
        "infoEmpty" : "0명",
        "infoFiltered" : "(전체 _MAX_ 명 중 검색결과)",
        "infoPostFix" : "",
        "thousands" : ",",
        "lengthMenu" : "_MENU_ 개씩 보기　",
        "loadingRecords" : "로딩중...",
        "processing" : "처리중...",
        "search" : "검색 : ",
        "zeroRecords" : "검색된 데이터가 없습니다.",
        "paginate" : {
            "first" : "첫 페이지",
            "last" : "마지막 페이지",
            "next" : "다음",
            "previous" : "이전"
        },
        "aria" : {
            "sortAscending" : " :  오름차순 정렬",
            "sortDescending" : " :  내림차순 정렬"
        }
    };


var dt;


function drawDataTable($){
    jQuery('#agent_name').html(agencyInfos['agencyName']);      //전체
    jQuery('#agent_num').html(agencyInfos['agencyNum']);        //기관번호
    jQuery('#female_total_count').html(agencyInfos['femaleCnt']);//여자
    jQuery('#male_total_count').html(agencyInfos['maleCnt']);   //남자
    jQuery('#ave_rage_age').html(agencyInfos['avgAge']);        //평균연령
    jQuery('#arngage').html(agencyInfos['ageArg']);             //연령범위
    jQuery('#score01').html(agencyInfos['score01']);            //전체수
    jQuery('#score02').html(agencyInfos['score02']);            //감지중
    jQuery('#score03').html(agencyInfos['score03']);            //연락필요
    jQuery('#score04').html(agencyInfos['score04']);            //연결끊김(>=15day)
    jQuery('#score05').html(agencyInfos['score05']);            //연결끊김(>=7day)
    jQuery('#score06').html(agencyInfos['score06']);            //연결끊김(>=1day)

    var agency = agencyInfos['agency'];
    document.getElementById('agencyCode').value = agency;
    let agency_id = $("#agencyCode").val();   
    dt= $('#mainTable').DataTable({   
        //dom: '<"top"Bf>rt<"bottom"lip><"clear">',
        //dom: 'lBfrtip',
        //fixedHeader: true,
        //serverSide: false,
        //processing: true,
        pageLength: 50,
        dom: 'lBfrtip',
        paging: true,
        searching: true,
        ordering: true,
        lengthChange: true, 
        serverMethod: 'post',
        select:'single',
        language : lang_kor,
        scrollX : true,
       ajax: {
            url: "/wp-admin/admin-ajax.php?action=datatables_endpoint", //데이터 끌고오기
        　　data:function(d){
        　　d.id = $("#agencyCode").val();
            },
            cache:false,
        },
        columns: [
           
            {data:'connection_state',
                  render:function(data,type,row){
                      if(data == "0") data = "🟢";
                      if(data == "1") data = "🔴";
                      if(data == "2") data = "⚫";     
                      if(data == "3") data = "⬛"; 
                      if(data == "4") data = "🔲";
                      return data;
                 }, width:'30px'
            },
            { data: 'name'              ,width:'70px'   },
            { data: 'snum'              ,width:'80px'   },
            { data: 'phone_num'         ,width:'80px',
                render:function(data,type,row){
                    data =phoneFormatter(data,1);
                    return data;
                }
                
            },
            { data: 'sex',
                 render:function(data,type,row){
                             data =(data == "1")?'남':'여';
                            return data;
                 },width:'30px'
            },        
            { data: 'birthday'          ,width:'60px'   }, 
            { data: 'agcname'           ,width:'180px'  },
            { data: 'phoneNum'          ,width:'90px',
                render:function(data,type,row){
                    data =phoneFormatter(data,1);
                    return data;
                }
            },
            { data: 'activeSenceTime'   ,width:'50px'   },
            { data: 'battery'           ,width:'70px'   },  
            { data: 'regstday'          ,width:'60px'   },
            { data: 'lctime'            ,width:'100px'  },
            { data: '',width:'35px',
    	    	render: function(data,type,row){
	    			return "<button id='ststicsBtn' type='button' class='detailButton' onClick='openUserDetail("+row.id+")'>상세</button>";
	    		}
            },
           /* { data: 'id'                    ,visible:false},   
            { data: 'host_user_id'          ,visible:false}, 
            { data: 'last_none_action_time' ,visible:false}, 
            //CSV출력이 되므로 커멘트아웃
            */
        ],

        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        buttons: [
            {
               text : '<i class="fas fa-file-csv"></i> CSV',
               extend: 'csv',
               charset: 'UTF-8',
               fieldSeparator: ',',
               bom: true,
                
               filename: '모니터링_리스트_일람',
               title: '모니터링_리스트_일람',
               exportOptions:{
                   columns: [ 1,2,3,4,5,6,7,8,9,10,11],
                   modifier: {
                       selected: null //행의선택과는 상관없이 모두 출력
                    }
               }
            }
		]
    }); 
    dt.buttons().container().appendTo($('#csvBtnArea'));
}
 
jQuery(document).ready(function($){
    drawDataTable($); //이 타이밍에 로딩
     dt.column(0).order('desc').draw(); //사용중인 사람 순으로 보이기(21.12.14)
    $('#score_card1')
     .click(
        function(){
            initBgColor();
            $('#score_card1').css('background','#EBF0FE');
         dt.column(0).search("").draw();  //전체
        }
    )
    $('#score_card2')
     .click(
        function(){
            initBgColor();
            $('#score_card2').css('background','#E6FBF5');
         dt.column(0).search("🟢").draw();  //감지중
        }
    )
    $('#score_card3')
     .click(
        function(){
            initBgColor();
            $('#score_card3').css('background','#FFE3E5');
         dt.column(0).search("🔴").draw();  //연락필
        }
    )
    $('#score_card4')
      .click(
        function(){
            initBgColor();
            $('#score_card4').css('background','#EDF0F3');
         dt.column(0).search("⚫").draw(); //연결끊김
        }
    )
    
    $('#score_card5')
      .click(
        function(){
            initBgColor();
            $('#score_card5').css('background','#EDF0F3');
            dt.column(0).search("⬛").draw(); //연결끊김(8~30)  
        }
    )
    $('#score_card6')
      .click(
        function(){
            initBgColor();
            $('#score_card6').css('background','#EDF0F3');
            dt.column(0).search("🔲").draw(); //연결끊김(30~)    	
        }
    )
    
    function initBgColor(){
        $('#score_card1').css('background','#ffffff');
        $('#score_card2').css('background','#ffffff');
        $('#score_card3').css('background','#ffffff');
    
        $('#score_card4').css('background','#ffffff');
        $('#score_card5').css('background','#ffffff');
        $('#score_card6').css('background','#ffffff');
    }
    
});

//테이블 안의 '상세' 버튼 클릭시
function openUserDetail(id_) {

  // Table 에서 받은 user_id 출력
  console.log('id:'+id_);
	
  var form      = document.createElement('form');
  form.action   = '/user_page'; 
  form.method   = 'post';
  
  var p1    = document.createElement('input');
  p1.id     = 'form1';
  p1.type   = 'hidden';
  p1.name   = 'user_id';
  p1.value  = id_;
  form.appendChild(p1);
  
  form.target ='_blank'; //새창에서 열기
  document.body.appendChild(form);
 
  form.submit();
  
  //요소삭제
  var form = document.getElementById("form1");
  if (form.hasChildNodes()){
	form.removeChild(form.firstChild);
  }
   console.log('element 삭제'); 
}

//검색테스트용
function functest(){
    dt.column(3).search( '남' ).draw(); 
}

/*
전화번호 포맷 변경
*/
function phoneFormatter(num, type) {
    var formatNum = '';
    try{
       if (num.length == 11) {
          if (type == 0) {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
          } else {
             formatNum = num.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
          }
       } else if (num.length == 8) {
          formatNum = num.replace(/(\d{4})(\d{4})/, '$1-$2');
       } else {
          if (num.indexOf('02') == 0) {
             if (type == 0) {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
             } else {
                formatNum = num.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
             }
          } else {
             if (type == 0) {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
             } else {
                formatNum = num.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
             }
          }
       }
    } catch(e) {
       formatNum = num;
       console.log(e);
    }
    return formatNum;
}



</script>		</div>
				</div>
				<div class="elementor-element elementor-element-159445f elementor-widget elementor-widget-spacer" data-id="159445f" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/magnific-popup.min.js?ver=2.0.6' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/lightbox.min.js?ver=2.0.6' id='oceanwp-lightbox-js'></script>
<script type='text/javascript' id='oceanwp-main-js-extra'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","ajax_url":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/main.min.js?ver=2.0.6' id='oceanwp-main-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://hyodolms.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=2.0.6' id='html5shiv-js'></script>
<![endif]-->
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.6' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"http:\/\/hyodolms.com\/wp-admin\/admin-ajax.php","nonce":"be9fe94427","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ko_KR","app_id":""},"lottie":{"defaultAnimationUrl":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.6' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.1.4' id='share-link-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"\ud398\uc774\uc2a4\ubd81 \uacf5\uc720","shareOnTwitter":"\ud2b8\uc704\ud130 \uacf5\uc720","pinIt":"\uace0\uc815\ud558\uae30","download":"Download","downloadImage":"\uc774\ubbf8\uc9c0 \ub2e4\uc6b4\ub85c\ub4dc","fullscreen":"\uc804\uccb4\ud654\uba74","zoom":"\uc90c","share":"\uacf5\uc720","playVideo":"\ube44\ub514\uc624 \uc7ac\uc0dd","previous":"\uc774\uc804","next":"\ub2e4\uc74c","close":"\ub2eb\uae30"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"http:\/\/hyodolms.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":4180,"title":"main%20%E2%80%93%20mtsystem","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='http://hyodolms.com/wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.min.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
	</body>
</html>

<!-- Dynamic page generated in 0.508 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2022-01-18 14:48:08 -->
